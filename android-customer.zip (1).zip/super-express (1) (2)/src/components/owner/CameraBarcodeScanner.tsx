import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  X,
  AlertCircle,
  Zap,
  ZapOff,
  SwitchCamera,
  CheckCircle2,
  ScanLine,
  Loader2,
  Image as ImageIcon,
} from 'lucide-react';
import { BrowserMultiFormatReader, IScannerControls } from '@zxing/browser';
import { BarcodeFormat, DecodeHintType } from '@zxing/library';

interface CameraBarcodeScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onDetected: (barcode: string, format?: string) => void;
  continuous?: boolean;
  title?: string;
}

const SUPPORTED_ZXING_FORMATS = [
  BarcodeFormat.EAN_13,
  BarcodeFormat.EAN_8,
  BarcodeFormat.UPC_A,
  BarcodeFormat.UPC_E,
  BarcodeFormat.CODE_128,
];

const SUPPORTED_DETECTOR_FORMATS = [
  'ean_13',
  'ean_8',
  'upc_a',
  'upc_e',
  'code_128',
];

export const CameraBarcodeScanner: React.FC<CameraBarcodeScannerProps> = ({
  isOpen,
  onClose,
  onDetected,
  continuous = true,
  title = 'Mobile Camera Barcode Scanner',
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const photoInputRef = useRef<HTMLInputElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const controlsRef = useRef<IScannerControls | null>(null);
  const rafRef = useRef<number | null>(null);

  const lastDetectedRef = useRef<{ code: string; time: number }>({ code: '', time: 0 });
  const onDetectedRef = useRef(onDetected);
  onDetectedRef.current = onDetected;

  const [status, setStatus] = useState<'requesting' | 'active' | 'error'>('requesting');
  const [errorMsg, setErrorMsg] = useState('');
  const [photoError, setPhotoError] = useState('');
  const [isDecodingPhoto, setIsDecodingPhoto] = useState(false);
  const [engineLabel, setEngineLabel] = useState('Initializing camera...');
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceIndex, setSelectedDeviceIndex] = useState(0);
  const [retryToken, setRetryToken] = useState(0);
  const [torchSupported, setTorchSupported] = useState(false);
  const [torchOn, setTorchOn] = useState(false);
  const [lastScannedBanner, setLastScannedBanner] = useState<string>('');

  const stopCamera = () => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (controlsRef.current) {
      try {
        controlsRef.current.stop();
      } catch {
        // ignore
      }
      controlsRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {
          // ignore
        }
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setTorchOn(false);
    setTorchSupported(false);
  };

  const handleDecodeHit = (rawCode: string, formatName?: string) => {
    const code = rawCode.trim();
    if (!code) return;

    const now = Date.now();
    // Duplicate scan prevention (1.5s cooldown on identical code, 350ms global frame lock)
    if (
      (lastDetectedRef.current.code === code && now - lastDetectedRef.current.time < 1500) ||
      now - lastDetectedRef.current.time < 350
    ) {
      return;
    }

    lastDetectedRef.current = { code, time: now };
    setLastScannedBanner(`${code}${formatName ? ` (${formatName})` : ''}`);
    onDetectedRef.current(code, formatName);

    if (!continuous) {
      stopCamera();
      onClose();
    }
  };

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      return;
    }

    let cancelled = false;

    const startScanner = async () => {
      setStatus('requesting');
      setErrorMsg('');
      setPhotoError('');
      setLastScannedBanner('');

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setStatus('error');
        setErrorMsg(
          'Live camera API is unavailable in this browser context. Use "Scan Photo" below or a USB/Bluetooth HID scanner.'
        );
        return;
      }

      try {
        const videoConstraint: MediaTrackConstraints =
          devices.length > 0 && devices[selectedDeviceIndex]?.deviceId
            ? {
                deviceId: { exact: devices[selectedDeviceIndex].deviceId },
                width: { ideal: 1280 },
                height: { ideal: 720 },
              }
            : {
                facingMode: { ideal: 'environment' },
                width: { ideal: 1280 },
                height: { ideal: 720 },
              };

        // 1. Explicitly request camera permission (with basic fallback if constraints are unsupported)
        let stream: MediaStream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: videoConstraint,
            audio: false,
          });
        } catch (constraintErr: any) {
          if (
            constraintErr?.name === 'OverconstrainedError' ||
            constraintErr?.name === 'ConstraintNotSatisfiedError'
          ) {
            stream = await navigator.mediaDevices.getUserMedia({
              video: true,
              audio: false,
            });
          } else {
            throw constraintErr;
          }
        }

        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        streamRef.current = stream;

        // Check available cameras for camera switching
        try {
          const allDevices = await navigator.mediaDevices.enumerateDevices();
          const videoInputs = allDevices.filter((d) => d.kind === 'videoinput');
          if (videoInputs.length > 0 && devices.length === 0) {
            setDevices(videoInputs);
          }
        } catch {
          // ignore
        }

        // Check torch capability
        const videoTrack = stream.getVideoTracks()[0];
        if (videoTrack && typeof videoTrack.getCapabilities === 'function') {
          const caps = videoTrack.getCapabilities() as any;
          if (caps && caps.torch) {
            setTorchSupported(true);
          }
        }

        const videoEl = videoRef.current;
        if (!videoEl) return;

        videoEl.srcObject = stream;
        videoEl.setAttribute('playsinline', 'true');
        await videoEl.play();

        if (cancelled) return;
        setStatus('active');

        // 2. Try native BarcodeDetector first when supported, otherwise use ZXing fallback
        let useNativeDetector = false;
        const BarcodeDetectorCtor = (window as any).BarcodeDetector;
        if (typeof BarcodeDetectorCtor === 'function') {
          try {
            const availableFormats: string[] =
              typeof BarcodeDetectorCtor.getSupportedFormats === 'function'
                ? await BarcodeDetectorCtor.getSupportedFormats()
                : [];
            const supportedSubset = SUPPORTED_DETECTOR_FORMATS.filter((f) =>
              availableFormats.includes(f)
            );
            if (supportedSubset.length > 0) {
              useNativeDetector = true;
              const detector = new BarcodeDetectorCtor({ formats: supportedSubset });
              setEngineLabel('Hardware BarcodeDetector + ZXing Ready');

              let lastCheckTime = 0;
              const scanLoop = async (timestamp: number) => {
                if (cancelled) return;
                if (
                  videoEl.readyState >= 2 &&
                  !videoEl.paused &&
                  timestamp - lastCheckTime >= 160
                ) {
                  lastCheckTime = timestamp;
                  try {
                    const barcodes = await detector.detect(videoEl);
                    if (barcodes && barcodes.length > 0 && barcodes[0].rawValue) {
                      handleDecodeHit(barcodes[0].rawValue, barcodes[0].format);
                    }
                  } catch {
                    // ignore transient frame read error
                  }
                }
                rafRef.current = requestAnimationFrame(scanLoop);
              };
              rafRef.current = requestAnimationFrame(scanLoop);
            }
          } catch {
            useNativeDetector = false;
          }
        }

        // 3. Reliable ZXing Multi-Format fallback (EAN-13, EAN-8, UPC-A, UPC-E, Code 128)
        if (!useNativeDetector) {
          setEngineLabel('ZXing Multi-Format Scanner Active');
          const hints = new Map();
          hints.set(DecodeHintType.POSSIBLE_FORMATS, SUPPORTED_ZXING_FORMATS);
          hints.set(DecodeHintType.TRY_HARDER, true);

          const reader = new BrowserMultiFormatReader(hints, {
            delayBetweenScanAttempts: 180,
            delayBetweenScanSuccess: 1200,
          });

          const controls = await reader.decodeFromStream(stream, videoEl, (result) => {
            if (cancelled) return;
            if (result) {
              handleDecodeHit(
                result.getText(),
                BarcodeFormat[result.getBarcodeFormat()] || 'BARCODE'
              );
            }
          });
          controlsRef.current = controls;
        }
      } catch (err: any) {
        if (cancelled) return;
        console.warn('Camera permission / stream notice:', err?.name || err?.message);
        setStatus('error');
        if (
          err?.name === 'NotAllowedError' ||
          err?.name === 'PermissionDeniedError' ||
          (typeof err?.message === 'string' && err.message.toLowerCase().includes('permission'))
        ) {
          setErrorMsg(
            'Camera permission was denied or blocked by browser settings. Allow camera access and tap Retry, or use "Scan Photo / Camera Snapshot" below.'
          );
        } else if (err?.name === 'NotFoundError' || err?.name === 'DevicesNotFoundError') {
          setErrorMsg(
            'No camera device found. Use "Scan Photo" below or connect a USB/Bluetooth HID scanner.'
          );
        } else {
          setErrorMsg(err?.message || 'Unable to access live camera stream.');
        }
      }
    };

    startScanner();

    return () => {
      cancelled = true;
      stopCamera();
    };
  }, [isOpen, selectedDeviceIndex, retryToken]);

  // Photo/Snapshot fallback using native camera capture or gallery image
  const handlePhotoBarcodeUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoError('');
    setIsDecodingPhoto(true);
    const objectUrl = URL.createObjectURL(file);

    try {
      const hints = new Map();
      hints.set(DecodeHintType.POSSIBLE_FORMATS, SUPPORTED_ZXING_FORMATS);
      hints.set(DecodeHintType.TRY_HARDER, true);
      const reader = new BrowserMultiFormatReader(hints);
      const result = await reader.decodeFromImageUrl(objectUrl);
      if (result && result.getText()) {
        handleDecodeHit(
          result.getText(),
          BarcodeFormat[result.getBarcodeFormat()] || 'IMAGE'
        );
      } else {
        setPhotoError('No barcode detected in image. Try a clearer, well-lit photo.');
      }
    } catch {
      setPhotoError(
        'Could not detect an EAN-13, EAN-8, UPC-A, UPC-E, or Code 128 barcode in that photo.'
      );
    } finally {
      URL.revokeObjectURL(objectUrl);
      setIsDecodingPhoto(false);
      if (photoInputRef.current) photoInputRef.current.value = '';
    }
  };

  const toggleTorch = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    try {
      const next = !torchOn;
      await track.applyConstraints({ advanced: [{ torch: next } as any] });
      setTorchOn(next);
    } catch {
      // ignore if unsupported by hardware
    }
  };

  const handleSwitchCamera = () => {
    if (devices.length <= 1) return;
    stopCamera();
    setSelectedDeviceIndex((prev) => (prev + 1) % devices.length);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-slate-900 text-white rounded-3xl max-w-lg w-full overflow-hidden border border-slate-700 shadow-2xl animate-in zoom-in-95 duration-150">
        {/* Hidden photo/camera snapshot input for restricted browsers */}
        <input
          ref={photoInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handlePhotoBarcodeUpload}
          className="hidden"
        />

        {/* Header */}
        <div className="px-4 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
              <Camera className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="font-black text-sm text-white truncate">{title}</h3>
              <p className="text-[10px] text-emerald-400 font-semibold truncate">
                EAN-13 • EAN-8 • UPC-A • UPC-E • Code 128
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shrink-0 transition"
          >
            <X className="w-4 h-4" />
            <span>Close Camera</span>
          </button>
        </div>

        {/* Live Video Preview & Scanning Guide */}
        <div className="relative bg-black aspect-[4/3] w-full overflow-hidden flex items-center justify-center">
          <video
            ref={videoRef}
            muted
            playsInline
            autoPlay
            className="w-full h-full object-cover"
          />

          {/* Viewfinder Overlay Guide */}
          {status === 'active' && (
            <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center p-6">
              <div className="w-full max-w-[290px] h-40 relative rounded-2xl border-2 border-white/30 shadow-[0_0_0_9999px_rgba(0,0,0,0.45)]">
                {/* Corner Brackets */}
                <span className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-emerald-400 rounded-tl-xl" />
                <span className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-emerald-400 rounded-tr-xl" />
                <span className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-emerald-400 rounded-bl-xl" />
                <span className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-emerald-400 rounded-br-xl" />

                {/* Laser Guide Line */}
                <div className="absolute left-3 right-3 top-1/2 -translate-y-1/2 h-0.5 bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.95)] animate-pulse" />
              </div>

              <div className="mt-4 px-3 py-1 rounded-full bg-slate-950/80 border border-slate-700 text-[11px] font-bold text-slate-200 flex items-center gap-1.5">
                <ScanLine className="w-3.5 h-3.5 text-emerald-400" />
                <span>Align barcode inside the frame</span>
              </div>
            </div>
          )}

          {/* Requesting Permission Overlay */}
          {status === 'requesting' && (
            <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center p-6 text-center space-y-3">
              <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
              <div className="text-sm font-bold text-white">Requesting Camera Access...</div>
              <p className="text-xs text-slate-400 max-w-xs">
                Please tap &quot;Allow&quot; when your browser prompts for camera permission.
              </p>
            </div>
          )}

          {/* Error Overlay with Retry + Photo Snapshot Fallback */}
          {status === 'error' && (
            <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center space-y-3">
              <AlertCircle className="w-10 h-10 text-rose-400" />
              <div className="text-sm font-bold text-rose-200">Camera Permission Needed</div>
              <p className="text-xs text-slate-300 max-w-sm leading-relaxed">{errorMsg}</p>
              {photoError && (
                <p className="text-[11px] text-amber-300 font-semibold max-w-sm">{photoError}</p>
              )}
              <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setRetryToken((t) => t + 1)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer"
                >
                  Retry Camera Permission
                </button>
                <button
                  type="button"
                  disabled={isDecodingPhoto}
                  onClick={() => photoInputRef.current?.click()}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{isDecodingPhoto ? 'Reading Barcode...' : 'Scan Photo / Snapshot'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Last Scanned Toast */}
          {lastScannedBanner && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 px-3.5 py-1.5 rounded-full bg-emerald-600 text-white text-xs font-black shadow-lg flex items-center gap-1.5 animate-in fade-in-50 duration-150">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Scanned: {lastScannedBanner}</span>
            </div>
          )}
        </div>

        {/* Footer Controls */}
        <div className="px-4 py-3 bg-slate-950 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="text-[11px] text-slate-400 font-medium">{engineLabel}</span>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={isDecodingPhoto}
              onClick={() => photoInputRef.current?.click()}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isDecodingPhoto ? 'Scanning...' : 'Scan Photo'}</span>
            </button>

            {torchSupported && (
              <button
                type="button"
                onClick={toggleTorch}
                className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 cursor-pointer transition ${
                  torchOn
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                }`}
              >
                {torchOn ? <Zap className="w-3.5 h-3.5" /> : <ZapOff className="w-3.5 h-3.5" />}
                <span>{torchOn ? 'Flash On' : 'Flash'}</span>
              </button>
            )}

            {devices.length > 1 && (
              <button
                type="button"
                onClick={handleSwitchCamera}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <SwitchCamera className="w-3.5 h-3.5" />
                <span>Switch Camera</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
