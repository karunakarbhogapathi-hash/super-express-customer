import React from 'react';
import { Zap, ShoppingBag } from 'lucide-react';

export const CustomerSplash: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-emerald-900 to-slate-950 text-white flex flex-col items-center justify-center p-6 text-center">
      <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-emerald-500 to-green-400 text-slate-950 flex items-center justify-center shadow-2xl shadow-emerald-500/30 mb-6 animate-pulse">
        <div className="relative">
          <ShoppingBag className="w-11 h-11 stroke-[2.3]" />
          <Zap className="w-5 h-5 fill-amber-300 text-amber-300 absolute -top-2 -right-2" />
        </div>
      </div>

      <h1 className="text-3xl font-black tracking-tight">
        SUPER<span className="text-emerald-400">EXPRESS</span>
      </h1>
      <p className="text-xs font-bold uppercase tracking-[0.2em] text-emerald-300 mt-1.5">
        Customer Grocery App
      </p>
      <p className="text-xs text-slate-300 mt-4 max-w-xs">
        10–15 minute grocery delivery exclusively from your apartment supermarket
      </p>

      <div className="mt-8 flex items-center gap-2 text-xs text-emerald-300 font-semibold">
        <span className="w-4 h-4 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
        <span>Connecting securely...</span>
      </div>
    </div>
  );
};
