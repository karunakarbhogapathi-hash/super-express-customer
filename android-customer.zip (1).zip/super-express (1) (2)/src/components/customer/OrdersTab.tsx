import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Package,
  Clock,
  CheckCircle2,
  Bike,
  Store,
  Phone,
  RotateCcw,
  ShieldCheck,
  ChevronRight,
  AlertCircle,
} from 'lucide-react';
import { Order, OrderStatus } from '../../types';

interface OrdersTabProps {
  onReorder: () => void;
}

export const OrdersTab: React.FC<OrdersTabProps> = ({ onReorder }) => {
  const { orders, currentUser, activeApartment, addToCart, products } = useApp();

  // Filter orders for the current customer
  const customerOrders = orders.filter((o) => o.customerId === currentUser.id);

  const getStatusStep = (status: OrderStatus): number => {
    switch (status) {
      case 'placed':
        return 1;
      case 'accepted':
        return 2;
      case 'packing':
        return 3;
      case 'out_for_delivery':
        return 4;
      case 'delivered':
        return 5;
      case 'rejected':
      case 'cancelled':
        return 0;
      default:
        return 1;
    }
  };

  const handleReorder = (order: Order) => {
    if (!order.items) return;
    order.items.forEach((item) => {
      const prod = products.find((p) => p.id === item.productId);
      if (prod) {
        addToCart(prod);
      }
    });
    onReorder();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Package className="w-6 h-6 text-emerald-600" />
            My Orders
          </h2>
          <p className="text-xs text-slate-500">
            Society orders for {activeApartment?.name}
          </p>
        </div>
        <span className="text-xs font-bold bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full">
          {customerOrders.length} Total Orders
        </span>
      </div>

      {customerOrders.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-6">
          <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
            <Package className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-base text-slate-800">No orders placed yet</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Order fresh daily essentials and groceries from your apartment supermarket with 10-15 min delivery!
          </p>
        </div>
      ) : (
        <div className="space-y-5">
          {customerOrders.map((order) => {
            const step = getStatusStep(order.status);
            const isCompleted = order.status === 'delivered';
            const isRejected = order.status === 'rejected' || order.status === 'cancelled';

            return (
              <div
                key={order.id}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:border-emerald-300 transition-all"
              >
                {/* Order Card Header */}
                <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-sm text-slate-900">
                        Order #{order.id}
                      </span>
                      <span className="text-xs text-slate-400">•</span>
                      <span className="text-xs text-slate-600 font-medium">
                        {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })},{' '}
                        {new Date(order.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-emerald-800 font-semibold mt-0.5">
                      <Store className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{order.storeName}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-black text-sm text-slate-900">
                      ₹{order.totalAmount}
                    </span>
                    <span
                      className={`text-[11px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                        isCompleted
                          ? 'bg-emerald-100 text-emerald-800'
                          : isRejected
                          ? 'bg-red-100 text-red-800'
                          : 'bg-amber-100 text-amber-800 animate-pulse'
                      }`}
                    >
                      {order.status.replace(/_/g, ' ')}
                    </span>
                  </div>
                </div>

                <div className="p-4 space-y-4">
                  {/* Status Progress Track */}
                  {!isRejected && (
                    <div className="bg-emerald-50/60 p-3.5 rounded-xl border border-emerald-100">
                      <div className="text-[11px] font-bold text-slate-700 mb-2 flex items-center justify-between">
                        <span>Live Delivery Status</span>
                        {!isCompleted && (
                          <span className="text-emerald-700 flex items-center gap-1 font-bold">
                            <Clock className="w-3.5 h-3.5" /> ETA: 10-15 Mins
                          </span>
                        )}
                      </div>

                      {/* 5-step tracker */}
                      <div className="grid grid-cols-5 gap-1 text-center">
                        {[
                          { num: 1, label: 'Placed' },
                          { num: 2, label: 'Accepted' },
                          { num: 3, label: 'Packing' },
                          { num: 4, label: 'Out' },
                          { num: 5, label: 'Delivered' },
                        ].map((s) => {
                          const reached = step >= s.num;
                          const current = step === s.num;
                          return (
                            <div key={s.num} className="flex flex-col items-center">
                              <div
                                className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold mb-1 transition-all ${
                                  reached
                                    ? 'bg-emerald-600 text-white'
                                    : 'bg-slate-200 text-slate-500'
                                } ${current ? 'ring-4 ring-emerald-200' : ''}`}
                              >
                                {reached ? '✓' : s.num}
                              </div>
                              <span
                                className={`text-[10px] font-medium leading-tight ${
                                  reached ? 'text-emerald-900 font-bold' : 'text-slate-400'
                                }`}
                              >
                                {s.label}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Delivery Courier & OTP Details if active */}
                  {!isCompleted && !isRejected && (
                    <div className="p-3 bg-slate-900 text-white rounded-xl flex items-center justify-between gap-3">
                      <div>
                        <div className="text-[10px] uppercase font-bold text-emerald-400">
                          Handover Verification OTP
                        </div>
                        <div className="text-xs text-slate-300">
                          Share this with courier on arrival:
                        </div>
                      </div>
                      <div className="font-mono text-xl font-black bg-emerald-800 text-yellow-300 px-3 py-1 rounded-lg tracking-widest border border-emerald-600">
                        {order.deliveryOtp}
                      </div>
                    </div>
                  )}

                  {order.deliveryPartnerName && !isCompleted && (
                    <div className="flex items-center justify-between text-xs bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center">
                          <Bike className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-800">{order.deliveryPartnerName}</p>
                          <p className="text-[10px] text-slate-500">Super Express Courier</p>
                        </div>
                      </div>
                      <a
                        href={`tel:${order.deliveryPartnerPhone || '+919876543210'}`}
                        className="flex items-center gap-1 bg-emerald-600 text-white px-2.5 py-1 rounded-lg text-xs font-bold hover:bg-emerald-700"
                      >
                        <Phone className="w-3 h-3" /> Call
                      </a>
                    </div>
                  )}

                  {/* Items summary */}
                  <div className="border-t border-slate-100 pt-3">
                    <p className="text-xs font-bold text-slate-700 mb-2">
                      Items Ordered ({order.itemCount})
                    </p>
                    <div className="space-y-1.5">
                      {order.items?.map((item) => (
                        <div
                          key={item.id}
                          className="flex items-center justify-between text-xs text-slate-600"
                        >
                          <span className="truncate max-w-[240px]">
                            {item.quantity}x {item.name} ({item.unit})
                          </span>
                          <span className="font-semibold text-slate-800">
                            ₹{item.totalPrice}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Actions & Reorder */}
                  <div className="border-t border-slate-100 pt-3 flex items-center justify-between">
                    <div className="text-xs text-slate-500">
                      Payment: <span className="font-bold text-slate-700">{order.paymentMethod}</span> ({order.paymentStatus})
                    </div>
                    <button
                      onClick={() => handleReorder(order)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs rounded-xl border border-emerald-200 cursor-pointer transition"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Reorder All</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
