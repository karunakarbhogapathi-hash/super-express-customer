package com.superexpress.customer.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.superexpress.customer.SuperExpressCustomerApp
import com.superexpress.customer.data.SeedCatalog
import com.superexpress.customer.data.model.Apartment
import com.superexpress.customer.data.model.CartItem
import com.superexpress.customer.data.model.Category
import com.superexpress.customer.data.model.CustomerProfile
import com.superexpress.customer.data.model.Order
import com.superexpress.customer.data.model.Product
import com.superexpress.customer.data.model.Store
import com.superexpress.customer.data.repository.CustomerFirebaseRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

data class CustomerUiState(
    val authLoading: Boolean = true,
    val isAuthenticated: Boolean = false,
    val authError: String? = null,
    val authSubmitting: Boolean = false,
    val profile: CustomerProfile = CustomerProfile(),
    val apartments: List<Apartment> = SeedCatalog.apartments,
    val stores: List<Store> = SeedCatalog.stores,
    val categories: List<Category> = SeedCatalog.categories,
    val products: List<Product> = SeedCatalog.products,
    val selectedApartmentId: String = SeedCatalog.apartments.first().id,
    val selectedCategoryId: String = "cat-all",
    val searchQuery: String = "",
    val cart: List<CartItem> = emptyList(),
    val orders: List<Order> = emptyList(),
    val isPlacingOrder: Boolean = false,
    val checkoutError: String? = null,
    val pendingOnlineOrder: Order? = null,
    val isVerifyingOnlinePayment: Boolean = false,
    val confirmedOrder: Order? = null,
    val profileMessage: String? = null,
    val isSavingProfile: Boolean = false
) {
    val activeApartment: Apartment?
        get() = apartments.find { it.id == selectedApartmentId } ?: apartments.firstOrNull()

    val activeStore: Store?
        get() = stores.find { it.apartmentId == selectedApartmentId && it.status == "active" }
            ?: stores.find { it.id == activeApartment?.activeStoreId }

    val storeProducts: List<Product>
        get() {
            val sid = activeStore?.id ?: return emptyList()
            return products.filter { it.storeId == sid }
        }

    val filteredProducts: List<Product>
        get() {
            val q = searchQuery.trim().lowercase()
            return storeProducts.filter { p ->
                val catOk = selectedCategoryId == "cat-all" || p.category == selectedCategoryId
                val searchOk = q.isEmpty() ||
                    p.name.lowercase().contains(q) ||
                    p.brand.lowercase().contains(q) ||
                    p.description.lowercase().contains(q)
                catOk && searchOk
            }
        }

    val cartCount: Int
        get() = cart.sumOf { it.quantity }

    val cartSubtotal: Double
        get() = cart.sumOf { it.lineTotal }

    val deliveryFee: Double
        get() = if (cartSubtotal >= 199.0 || cart.isEmpty()) 0.0 else 25.0

    val handlingFee: Double
        get() = if (cart.isEmpty()) 0.0 else 5.0

    val grandTotal: Double
        get() = cartSubtotal + deliveryFee + handlingFee
}

class CustomerViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as SuperExpressCustomerApp
    private val repo = CustomerFirebaseRepository(app.firebaseAuth, app.firestore)

    private val _uiState = MutableStateFlow(CustomerUiState())
    val uiState: StateFlow<CustomerUiState> = _uiState.asStateFlow()

    private var dataSyncJob: Job? = null

    init {
        viewModelScope.launch {
            repo.testFirestoreConnection()
        }
        observeSession()
    }

    private fun observeSession() {
        viewModelScope.launch {
            repo.observeAuthUser().collectLatest { fbUser ->
                dataSyncJob?.cancel()
                if (fbUser == null) {
                    _uiState.value = _uiState.value.copy(
                        authLoading = false,
                        isAuthenticated = false,
                        profile = CustomerProfile(),
                        orders = emptyList(),
                        cart = emptyList()
                    )
                    return@collectLatest
                }

                _uiState.value = _uiState.value.copy(authLoading = true)
                try {
                    val profile = repo.loadOrCreateCustomerProfile(fbUser)
                    _uiState.value = _uiState.value.copy(
                        authLoading = false,
                        isAuthenticated = true,
                        authError = null,
                        profile = profile,
                        selectedApartmentId = profile.apartmentId.ifEmpty {
                            SeedCatalog.apartments.first().id
                        }
                    )
                    startFirestoreCatalogAndOrdersSync(fbUser.uid)
                } catch (e: Exception) {
                    _uiState.value = _uiState.value.copy(
                        authLoading = false,
                        isAuthenticated = false,
                        authError = e.message ?: "Unable to verify customer session."
                    )
                }
            }
        }
    }

    private fun startFirestoreCatalogAndOrdersSync(uid: String) {
        dataSyncJob?.cancel()
        dataSyncJob = viewModelScope.launch {
            launch {
                repo.observeApartments()
                    .catch { }
                    .collect { apts ->
                        _uiState.value = _uiState.value.copy(apartments = apts)
                    }
            }
            launch {
                repo.observeStores()
                    .catch { }
                    .collect { list ->
                        _uiState.value = _uiState.value.copy(stores = list)
                    }
            }
            launch {
                repo.observeProducts()
                    .catch { }
                    .collect { list ->
                        _uiState.value = _uiState.value.copy(products = list)
                    }
            }
            launch {
                repo.observeCustomerOrders(uid)
                    .catch { }
                    .collect { list ->
                        _uiState.value = _uiState.value.copy(orders = list)
                    }
            }
        }
    }

    fun clearAuthError() {
        _uiState.value = _uiState.value.copy(authError = null)
    }

    fun loginWithEmail(email: String, password: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(authSubmitting = true, authError = null)
            try {
                repo.loginWithEmail(email, password)
                _uiState.value = _uiState.value.copy(authSubmitting = false)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    authSubmitting = false,
                    authError = repo.mapAuthError(e)
                )
            }
        }
    }

    fun registerCustomer(
        name: String,
        phone: String,
        email: String,
        password: String,
        apartmentId: String,
        block: String,
        flatNumber: String
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(authSubmitting = true, authError = null)
            try {
                repo.registerCustomer(name, phone, email, password, apartmentId, block, flatNumber)
                _uiState.value = _uiState.value.copy(authSubmitting = false)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    authSubmitting = false,
                    authError = repo.mapAuthError(e)
                )
            }
        }
    }

    fun selectApartment(apartmentId: String) {
        if (_uiState.value.selectedApartmentId == apartmentId) return
        _uiState.value = _uiState.value.copy(
            selectedApartmentId = apartmentId,
            selectedCategoryId = "cat-all",
            searchQuery = "",
            cart = emptyList()
        )
    }

    fun selectCategory(categoryId: String) {
        _uiState.value = _uiState.value.copy(selectedCategoryId = categoryId)
    }

    fun updateSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun addToCart(product: Product) {
        if (!product.isAvailable) return
        val currentCart = _uiState.value.cart.toMutableList()
        val index = currentCart.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            val item = currentCart[index]
            currentCart[index] = item.copy(quantity = item.quantity + 1)
        } else {
            currentCart.add(CartItem(product = product, quantity = 1))
        }
        _uiState.value = _uiState.value.copy(cart = currentCart)
    }

    fun updateCartQuantity(productId: String, newQty: Int) {
        val currentCart = _uiState.value.cart.toMutableList()
        if (newQty <= 0) {
            currentCart.removeAll { it.product.id == productId }
        } else {
            val index = currentCart.indexOfFirst { it.product.id == productId }
            if (index >= 0) {
                currentCart[index] = currentCart[index].copy(quantity = newQty)
            }
        }
        _uiState.value = _uiState.value.copy(cart = currentCart)
    }

    fun clearCart() {
        _uiState.value = _uiState.value.copy(cart = emptyList())
    }

    fun quantityInCart(productId: String): Int {
        return _uiState.value.cart.find { it.product.id == productId }?.quantity ?: 0
    }

    fun placeOrder(paymentMethod: String, block: String, flatNumber: String) {
        val state = _uiState.value
        val apt = state.activeApartment
        val store = state.activeStore
        if (apt == null || store == null) {
            _uiState.value = state.copy(checkoutError = "No active supermarket selected.")
            return
        }
        if (state.cart.isEmpty()) {
            _uiState.value = state.copy(checkoutError = "Your cart is empty.")
            return
        }

        viewModelScope.launch {
            _uiState.value = state.copy(isPlacingOrder = true, checkoutError = null)
            try {
                val order = repo.placeOrder(
                    profile = state.profile,
                    apartment = apt,
                    store = store,
                    cart = state.cart,
                    paymentMethod = paymentMethod,
                    block = block,
                    flatNumber = flatNumber
                )
                if (paymentMethod == "ONLINE") {
                    _uiState.value = _uiState.value.copy(
                        isPlacingOrder = false,
                        cart = emptyList(),
                        pendingOnlineOrder = order
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isPlacingOrder = false,
                        cart = emptyList(),
                        confirmedOrder = order
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isPlacingOrder = false,
                    checkoutError = e.localizedMessage ?: "Failed to place order. Please try again."
                )
            }
        }
    }

    fun confirmOnlinePayment() {
        val pending = _uiState.value.pendingOnlineOrder ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isVerifyingOnlinePayment = true)
            try {
                val txnId = repo.verifyOnlinePayment(pending.id)
                val updated = pending.copy(
                    paymentStatus = "paid",
                    transactionId = txnId,
                    status = "accepted"
                )
                _uiState.value = _uiState.value.copy(
                    isVerifyingOnlinePayment = false,
                    pendingOnlineOrder = null,
                    confirmedOrder = updated
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isVerifyingOnlinePayment = false,
                    checkoutError = e.localizedMessage ?: "Payment confirmation failed."
                )
            }
        }
    }

    fun dismissPendingOnlinePayment() {
        _uiState.value = _uiState.value.copy(pendingOnlineOrder = null)
    }

    fun dismissConfirmedOrder() {
        _uiState.value = _uiState.value.copy(confirmedOrder = null)
    }

    fun reorder(order: Order) {
        val state = _uiState.value
        val availableProducts = state.products.associateBy { it.id }
        val newCart = order.items.mapNotNull { item ->
            val p = availableProducts[item.productId]
            if (p != null && p.isAvailable) CartItem(p, item.quantity) else null
        }
        if (newCart.isNotEmpty()) {
            _uiState.value = state.copy(cart = newCart)
        }
    }

    fun saveProfile(
        name: String,
        phone: String,
        apartmentId: String,
        block: String,
        flatNumber: String
    ) {
        val uid = _uiState.value.profile.id
        if (uid.isEmpty()) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSavingProfile = true, profileMessage = null)
            try {
                repo.updateCustomerProfile(uid, name, phone, apartmentId, block, flatNumber)
                val aptName = _uiState.value.apartments.find { it.id == apartmentId }?.name ?: ""
                _uiState.value = _uiState.value.copy(
                    isSavingProfile = false,
                    selectedApartmentId = apartmentId,
                    profile = _uiState.value.profile.copy(
                        name = name.trim(),
                        phone = phone.trim(),
                        apartmentId = apartmentId,
                        apartmentName = aptName,
                        block = block.trim(),
                        flatNumber = flatNumber.trim()
                    ),
                    profileMessage = "Profile updated successfully"
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isSavingProfile = false,
                    profileMessage = e.localizedMessage ?: "Could not save profile."
                )
            }
        }
    }

    fun clearProfileMessage() {
        _uiState.value = _uiState.value.copy(profileMessage = null)
    }

    fun signOut() {
        repo.signOut()
    }
}
