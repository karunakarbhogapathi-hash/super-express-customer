# Super Express Security Specification

## 1. Data Invariants
1. **Single Supermarket per Apartment**: Each apartment complex must have exactly one active supermarket assigned (`activeStoreId`).
2. **Apartment Boundary Enforcement**: Customers can only view and order from the supermarket assigned to their verified apartment. Customers cannot place orders across different apartments.
3. **Role Segregation**: Store owners cannot modify apartments or stores other than their assigned store. Customers cannot alter order statuses or product inventories.
4. **Order Integrity**: Total amount must strictly equal subtotal + deliveryFee + handlingFee. Customers cannot forge delivery OTPs, change payment status from pending to paid without valid payment records, or alter delivery partner assignments.
5. **Subscription Gate**: Supermarkets must maintain an active or grace monthly subscription (₹199) to receive and fulfill orders. Store owners cannot self-approve free subscriptions.
6. **PII and Order Privacy**: Order records and delivery addresses are visible exclusively to the ordering customer, the assigned store owner, the assigned delivery agent, and platform admins.
7. **Delivery Agent Scoping**: Delivery partners can view and update only the orders explicitly dispatched to their assigned partner ID.
8. **Admin Privilege Verification**: Administrative operations (assigning store to apartment, suspending store, modifying categories) require verified admin authorization.

## 2. The "Dirty Dozen" Threat Payloads (Must Return PERMISSION_DENIED)
1. **Apartment Leap Write**: Customer in Apartment A attempts to create an order referencing Store B from Apartment B.
2. **Price Tampering**: Customer sends order with `totalAmount: 1` when items subtotal is ₹850.
3. **Inventory Hi-Jack**: Unauthorized customer sends update payload altering product `price` or `stockCount`.
4. **Subscription Bypass**: Store owner sets `subscriptionStatus: "active"` and `subscriptionExpiresAt` to 2099 without an approved ₹199 transaction.
5. **Self-Promoted Admin**: Customer updates their own user document setting `role: "admin"`.
6. **Delivery Agent Order Steal**: Delivery agent updates `status: "delivered"` on an order assigned to a different delivery partner.
7. **Store Owner Cross-Store Spying**: Owner of Store 1 attempts to query or read orders and financials belonging to Store 2.
8. **Shadow Field Injection**: User attempts to inject `isSuperUser: true` or `isAdmin: true` into a profile creation payload.
9. **Post-Terminal Mutation**: Customer tries to cancel or alter an order after its status has reached `delivered` or `out_for_delivery`.
10. **Delivery OTP Forgery**: Customer updates `deliveryOtp` to "000000" to fake delivery completion without courier scan.
11. **Malicious Store Assignment**: Store owner attempts to overwrite `apartment.activeStoreId` to usurp another store's territory.
12. **PII Leakage Query**: Unauthenticated or unauthorized user performs a blanket list query on `/users` or `/orders`.

## 3. Test Runner Specification
See `tests/firestore.rules.test.ts` enforcing these invariants against the emulator / rules engine.
