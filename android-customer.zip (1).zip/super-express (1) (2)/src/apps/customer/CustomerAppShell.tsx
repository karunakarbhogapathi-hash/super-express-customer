import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Zap,
  MapPin,
  Search,
  Bell,
  User,
  ShoppingBag,
  ChevronDown,
  Store,
  Tag,
  Clock,
  ShieldCheck,
  Plus,
  Minus,
  ArrowRight,
  AlertTriangle,
  Star,
} from 'lucide-react';
import { Product, Order } from '../../types';
import { CartModal } from '../../components/customer/CartModal';
import { OrderConfirmationModal } from '../../components/customer/OrderConfirmationModal';
import { OrdersTab } from '../../components/customer/OrdersTab';
import { NotificationDrawer } from '../../components/NotificationDrawer';
import { CustomerSplash } from './CustomerSplash';
import { CustomerAuth } from './CustomerAuth';
import { ProductDetailModal } from './ProductDetailModal';
import { SupermarketsModal } from './SupermarketsModal';
import { CustomerProfileView } from './CustomerProfileView';

export const CustomerAppShell: React.FC = () => {
  const {
    customerAuthLoading,
    customerFirebaseUser,
    currentUser,
    apartments,
    stores,
    categories,
    products,
    activeApartment,
    activeStore,
    selectApartment,
    cart,
    cartTotal,
    cartCount,
    addToCart,
    updateCartQuantity,
    notifications,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'home' | 'supermarkets' | 'orders' | 'profile'>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('cat-all');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isSupermarketsOpen, setIsSupermarketsOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  if (customerAuthLoading) {
    return <CustomerSplash />;
  }

  if (!customerFirebaseUser) {
    return <CustomerAuth />;
  }

  const unreadNotifs = notifications.filter((n) => !n.isRead).length;
  const storeProducts = products.filter((p) => p.storeId === activeStore?.id);

  const filteredProducts = storeProducts.filter((product) => {
    const matchesCategory =
      selectedCategory === 'cat-all' || product.category === selectedCategory;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      !q ||
      product.name.toLowerCase().includes(q) ||
      product.description.toLowerCase().includes(q) ||
      (product.brand && product.brand.toLowerCase().includes(q));
    return matchesCategory && matchesSearch;
  });

  const getProductQuantity = (productId: string): number => {
    const item = cart.find((c) => c.product.id === productId);
    return item ? item.quantity : 0;
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased pb-24">
      {/* Standalone Customer Header (No RoleSwitcher) */}
      <header className="sticky top-0 z-40 bg-white border-b border-emerald-100 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
          {/* App Brand */}
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-700 via-emerald-600 to-green-500 flex items-center justify-center text-white shadow-md shadow-emerald-700/20 shrink-0">
              <Zap className="w-5 h-5 fill-white text-yellow-300" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base sm:text-lg tracking-tight text-emerald-950">
                  SUPER<span className="text-emerald-600">EXPRESS</span>
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsSupermarketsOpen(true)}
                className="flex items-center gap-1 text-[11px] font-semibold text-emerald-800 hover:text-emerald-950 truncate max-w-[200px] sm:max-w-[260px] cursor-pointer"
              >
                <MapPin className="w-3 h-3 text-emerald-600 shrink-0" />
                <span className="truncate">
                  {activeApartment?.name || 'Select Society'} • Flat {currentUser.flatNumber || '101'}
                </span>
                <ChevronDown className="w-3 h-3 shrink-0" />
              </button>
            </div>
          </div>

          {/* Desktop Search */}
          <div className="flex-1 max-w-md hidden md:block">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-600" />
              <input
                type="text"
                placeholder={`Search groceries in ${activeStore?.name || 'supermarket'}...`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 focus:bg-white text-slate-900 text-xs sm:text-sm pl-9 pr-4 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 outline-none"
              />
            </div>
          </div>

          {/* Action Icons */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setIsNotificationOpen(true)}
              className="relative p-2 rounded-xl text-slate-700 hover:bg-slate-100 transition cursor-pointer"
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadNotifs > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {unreadNotifs}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className="flex items-center gap-1.5 p-1.5 sm:px-2.5 rounded-xl text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
                {currentUser.name ? currentUser.name[0].toUpperCase() : <User className="w-4 h-4" />}
              </div>
              <span className="text-xs font-bold text-slate-800 hidden sm:inline max-w-[90px] truncate">
                {currentUser.name.split(' ')[0]}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setIsCartOpen(true)}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-2 rounded-xl font-bold text-xs shadow-sm cursor-pointer"
            >
              <div className="relative">
                <ShoppingBag className="w-4 h-4" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-yellow-400 text-emerald-950 text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </div>
              <span>₹{cartTotal}</span>
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        {activeTab === 'home' && (
          <div className="md:hidden px-4 pb-2.5">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-600" />
              <input
                type="text"
                placeholder={`Search milk, veggies, snacks in ${activeStore?.name || 'store'}...`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 focus:bg-white text-slate-900 text-xs pl-9 pr-4 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 outline-none"
              />
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main>
        {activeTab === 'orders' ? (
          <OrdersTab onReorder={() => setIsCartOpen(true)} />
        ) : activeTab === 'profile' ? (
          <CustomerProfileView />
        ) : activeTab === 'supermarkets' ? (
          <div className="max-w-4xl mx-auto px-4 py-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                  <Store className="w-5 h-5 text-emerald-600" />
                  Supermarkets & Residential Societies
                </h2>
                <p className="text-xs text-slate-500">
                  Select your residential society to shop from its exclusive Super Express supermarket
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {apartments.map((apt) => {
                const assignedStore = stores.find(
                  (s) => s.apartmentId === apt.id && s.status === 'active'
                );
                const isSelected = apt.id === activeApartment?.id;

                return (
                  <div
                    key={apt.id}
                    onClick={() => {
                      selectApartment(apt.id);
                      setActiveTab('home');
                    }}
                    className={`bg-white p-4 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                      isSelected
                        ? 'border-emerald-600 ring-2 ring-emerald-500/20 shadow-sm'
                        : 'border-slate-200 hover:border-emerald-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="font-black text-sm text-slate-900">{apt.name}</h3>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {apt.address}, {apt.city} - {apt.pincode}
                        </p>
                      </div>
                      {isSelected && (
                        <span className="bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                          Selected
                        </span>
                      )}
                    </div>

                    {assignedStore ? (
                      <div className="p-3 bg-emerald-50/70 rounded-xl border border-emerald-100 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          {assignedStore.logoUrl && (
                            <img
                              src={assignedStore.logoUrl}
                              alt={assignedStore.name}
                              className="w-10 h-10 rounded-xl object-cover border border-emerald-200 shrink-0"
                            />
                          )}
                          <div className="min-w-0">
                            <div className="font-bold text-xs text-emerald-950 truncate">
                              {assignedStore.name}
                            </div>
                            <div className="text-[11px] text-emerald-700">
                              ⚡ {assignedStore.deliveryTimeMinutes} mins • Min ₹{assignedStore.minOrderAmount}
                            </div>
                          </div>
                        </div>
                        <span className="flex items-center gap-0.5 text-xs font-black text-amber-700 bg-white px-2 py-1 rounded-lg border border-amber-200 shrink-0">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          {assignedStore.rating}
                        </span>
                      </div>
                    ) : (
                      <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs font-semibold text-amber-800">
                        Supermarket onboarding in progress
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="max-w-7xl mx-auto px-4 py-4 space-y-5">
            {/* Assigned Supermarket Hero Banner */}
            <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-slate-900 text-white rounded-3xl p-5 shadow-xl relative overflow-hidden">
              <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="bg-emerald-500/30 text-emerald-300 text-[11px] font-extrabold px-2.5 py-0.5 rounded-full border border-emerald-400/30 flex items-center gap-1">
                      <Zap className="w-3.5 h-3.5 fill-emerald-300" />
                      10–15 MIN DELIVERY
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsSupermarketsOpen(true)}
                      className="text-[11px] text-emerald-200 underline cursor-pointer"
                    >
                      Switch Society
                    </button>
                  </div>

                  <h1 className="text-xl sm:text-2xl font-black tracking-tight">
                    {activeStore ? activeStore.name : 'No Active Supermarket Assigned'}
                  </h1>

                  <p className="text-xs text-emerald-100 max-w-xl">
                    {activeStore
                      ? `Exclusively serving ${activeApartment?.name}. Open ${activeStore.openingTime} – ${activeStore.closingTime}.`
                      : 'Please choose another residential society or check back shortly.'}
                  </p>
                </div>

                {activeStore && (
                  <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/15 text-right shrink-0">
                    <div className="text-[11px] uppercase tracking-wider text-emerald-300 font-bold">
                      Delivery Speed
                    </div>
                    <div className="text-lg font-black text-white">
                      {activeStore.deliveryTimeMinutes} Minutes
                    </div>
                    <div className="text-[11px] text-emerald-200 font-medium">
                      Rating ★ {activeStore.rating} / 5
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Categories Strip */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h2 className="font-bold text-sm text-slate-800 flex items-center gap-1.5">
                  <Tag className="w-4 h-4 text-emerald-600" />
                  Browse Categories
                </h2>
                {selectedCategory !== 'cat-all' && (
                  <button
                    type="button"
                    onClick={() => setSelectedCategory('cat-all')}
                    className="text-xs text-emerald-600 font-semibold hover:underline cursor-pointer"
                  >
                    Show All ({storeProducts.length})
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2 overflow-x-auto pb-2">
                {categories.map((cat) => {
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      type="button"
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
                        isSelected
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-300'
                      }`}
                    >
                      <img
                        src={cat.imageUrl}
                        alt={cat.name}
                        className="w-5 h-5 rounded-md object-cover"
                      />
                      <span>{cat.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Products Grid */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-black text-base text-slate-900 tracking-tight">
                  {selectedCategory === 'cat-all'
                    ? 'Fresh Grocery Essentials'
                    : categories.find((c) => c.id === selectedCategory)?.name}
                </h2>
                <span className="text-xs text-slate-500 font-medium">
                  {filteredProducts.length} Items
                </span>
              </div>

              {filteredProducts.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
                  <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto mb-2" />
                  <h3 className="font-bold text-sm text-slate-800">No matching products</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Try clearing your search or selecting another category.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('cat-all');
                    }}
                    className="mt-3 px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl cursor-pointer"
                  >
                    Reset Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
                  {filteredProducts.map((product) => {
                    const qty = getProductQuantity(product.id);
                    const discountPct =
                      product.mrp > product.price
                        ? Math.round(((product.mrp - product.price) / product.mrp) * 100)
                        : 0;
                    const outOfStock = !product.inStock || product.stockCount <= 0;

                    return (
                      <div
                        key={product.id}
                        className="bg-white rounded-2xl border border-slate-200 hover:border-emerald-300 hover:shadow-md transition-all flex flex-col overflow-hidden group"
                      >
                        <button
                          type="button"
                          onClick={() => setSelectedProduct(product)}
                          className="relative aspect-square bg-slate-50 overflow-hidden text-left cursor-pointer"
                        >
                          <img
                            src={product.imageUrl}
                            alt={product.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                          />
                          {discountPct > 0 && (
                            <span className="absolute top-2 left-2 bg-emerald-600 text-white text-[10px] font-black px-1.5 py-0.5 rounded-md shadow-xs">
                              {discountPct}% OFF
                            </span>
                          )}
                          {outOfStock && (
                            <span className="absolute inset-0 bg-slate-950/55 text-white text-xs font-black flex items-center justify-center">
                              Out of Stock
                            </span>
                          )}
                        </button>

                        <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                          <button
                            type="button"
                            onClick={() => setSelectedProduct(product)}
                            className="text-left cursor-pointer"
                          >
                            <span className="text-[10px] font-semibold text-slate-500 block truncate">
                              {product.brand ? `${product.brand} • ` : ''}
                              {product.unit}
                            </span>
                            <h4 className="font-bold text-xs text-slate-900 line-clamp-2 leading-tight mt-0.5 group-hover:text-emerald-700 transition">
                              {product.name}
                            </h4>
                          </button>

                          <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                            <div>
                              <div className="text-xs font-black text-slate-900">
                                ₹{product.price}
                              </div>
                              {product.mrp > product.price && (
                                <div className="text-[10px] text-slate-400 line-through">
                                  ₹{product.mrp}
                                </div>
                              )}
                            </div>

                            {outOfStock ? (
                              <span className="text-[10px] font-bold text-rose-600">Unavailable</span>
                            ) : qty === 0 ? (
                              <button
                                type="button"
                                onClick={() => addToCart(product)}
                                className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white border border-emerald-300 hover:border-emerald-600 rounded-lg text-xs font-black transition-all cursor-pointer"
                              >
                                ADD
                              </button>
                            ) : (
                              <div className="flex items-center bg-emerald-600 text-white rounded-lg px-1.5 py-1">
                                <button
                                  type="button"
                                  onClick={() => updateCartQuantity(product.id, qty - 1)}
                                  className="w-4 h-4 flex items-center justify-center hover:bg-emerald-700 rounded cursor-pointer"
                                >
                                  <Minus className="w-3 h-3" />
                                </button>
                                <span className="text-xs font-black px-1.5 min-w-[16px] text-center">
                                  {qty}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => updateCartQuantity(product.id, qty + 1)}
                                  className="w-4 h-4 flex items-center justify-center hover:bg-emerald-700 rounded cursor-pointer"
                                >
                                  <Plus className="w-3 h-3" />
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Floating Cart Bar */}
      {cartCount > 0 && activeTab !== 'orders' && (
        <div className="fixed bottom-16 sm:bottom-6 left-0 right-0 z-30 px-4 max-w-lg mx-auto pointer-events-none">
          <button
            type="button"
            onClick={() => setIsCartOpen(true)}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white p-3.5 rounded-2xl shadow-xl shadow-emerald-700/30 flex items-center justify-between pointer-events-auto cursor-pointer ring-2 ring-white/50"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center font-bold text-xs">
                {cartCount}
              </div>
              <div className="text-left">
                <div className="text-xs font-medium text-emerald-100">
                  {cartCount} {cartCount === 1 ? 'item' : 'items'}
                </div>
                <div className="text-sm font-black">₹{cartTotal}</div>
              </div>
            </div>
            <div className="flex items-center gap-1.5 font-bold text-xs bg-white text-emerald-950 px-3 py-1.5 rounded-xl">
              <span>View Cart</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </button>
        </div>
      )}

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 py-1.5 px-4 shadow-lg sm:max-w-md sm:mx-auto sm:rounded-t-2xl">
        <div className="flex items-center justify-around">
          {[
            { id: 'home', label: 'Home', icon: <Zap className="w-5 h-5" /> },
            { id: 'supermarkets', label: 'Stores', icon: <Store className="w-5 h-5" /> },
            {
              id: 'cart',
              label: 'Cart',
              icon: (
                <div className="relative">
                  <ShoppingBag className="w-5 h-5" />
                  {cartCount > 0 && (
                    <span className="absolute -top-1.5 -right-2 bg-emerald-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                      {cartCount}
                    </span>
                  )}
                </div>
              ),
              action: () => setIsCartOpen(true),
            },
            { id: 'orders', label: 'Orders', icon: <Clock className="w-5 h-5" /> },
            { id: 'profile', label: 'Profile', icon: <ShieldCheck className="w-5 h-5" /> },
          ].map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                type="button"
                key={item.id}
                onClick={() => {
                  if (item.action) {
                    item.action();
                  } else {
                    setActiveTab(item.id as typeof activeTab);
                  }
                }}
                className={`flex flex-col items-center py-1 px-2 rounded-xl text-[10px] font-bold transition-all cursor-pointer ${
                  isActive ? 'text-emerald-700' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                {item.icon}
                <span className="mt-0.5">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Modals & Drawers */}
      <ProductDetailModal
        product={selectedProduct}
        categoryName={categories.find((c) => c.id === selectedProduct?.category)?.name}
        storeName={activeStore?.name}
        quantityInCart={selectedProduct ? getProductQuantity(selectedProduct.id) : 0}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={addToCart}
        onUpdateQuantity={updateCartQuantity}
        onOpenCart={() => setIsCartOpen(true)}
      />

      <SupermarketsModal
        isOpen={isSupermarketsOpen}
        onClose={() => setIsSupermarketsOpen(false)}
        apartments={apartments}
        stores={stores}
        activeApartmentId={activeApartment?.id}
        onSelectApartment={selectApartment}
      />

      <CartModal
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onOrderPlaced={(order) => {
          setConfirmedOrder(order);
          setActiveTab('orders');
        }}
      />

      <OrderConfirmationModal
        order={confirmedOrder}
        onClose={() => setConfirmedOrder(null)}
        onViewOrders={() => {
          setConfirmedOrder(null);
          setActiveTab('orders');
        }}
      />

      <NotificationDrawer
        isOpen={isNotificationOpen}
        onClose={() => setIsNotificationOpen(false)}
      />
    </div>
  );
};
