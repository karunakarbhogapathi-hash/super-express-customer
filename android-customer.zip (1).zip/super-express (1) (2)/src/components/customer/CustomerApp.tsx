import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShoppingBag,
  Zap,
  Plus,
  Minus,
  Sparkles,
  Search,
  Store,
  Clock,
  ArrowRight,
  ShieldCheck,
  Tag,
  AlertTriangle,
} from 'lucide-react';
import { Product, Order } from '../../types';
import { CartModal } from './CartModal';
import { OrderConfirmationModal } from './OrderConfirmationModal';
import { OrdersTab } from './OrdersTab';
import { ProfileTab } from './ProfileTab';

interface CustomerAppProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
}

export const CustomerApp: React.FC<CustomerAppProps> = ({
  searchQuery,
  setSearchQuery,
  isCartOpen,
  setIsCartOpen,
}) => {
  const {
    activeApartment,
    activeStore,
    categories,
    products,
    cart,
    cartTotal,
    cartCount,
    addToCart,
    updateCartQuantity,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'home' | 'categories' | 'orders' | 'profile'>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('cat-all');
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  // Business Model Filter:
  // "Customers must not see other supermarkets. Customers can order groceries only from their apartment's assigned supermarket."
  const storeProducts = products.filter((p) => p.storeId === activeStore?.id);

  const filteredProducts = storeProducts.filter((product) => {
    const matchesCategory =
      selectedCategory === 'cat-all' || product.category === selectedCategory;
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getProductQuantity = (productId: string): number => {
    const item = cart.find((c) => c.product.id === productId);
    return item ? item.quantity : 0;
  };

  return (
    <div className="min-h-screen bg-slate-50/60 pb-24">
      {/* View router based on active bottom tab */}
      {activeTab === 'orders' ? (
        <OrdersTab onReorder={() => setIsCartOpen(true)} />
      ) : activeTab === 'profile' ? (
        <ProfileTab />
      ) : (
        <div className="max-w-7xl mx-auto px-4 py-4 space-y-5">
          {/* Assigned Supermarket Banner */}
          <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-slate-900 text-white rounded-3xl p-5 shadow-xl relative overflow-hidden">
            <div className="absolute -right-10 -bottom-10 w-44 h-44 bg-emerald-500/20 rounded-full blur-2xl"></div>

            <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="bg-emerald-500/30 text-emerald-300 text-[11px] font-extrabold px-2.5 py-0.5 rounded-full border border-emerald-400/30 flex items-center gap-1">
                    <Zap className="w-3.5 h-3.5 fill-emerald-300" />
                    SINGLE STORE APARTMENT SYSTEM
                  </span>
                  <span className="text-xs text-emerald-200">
                    ⚡ 10-15 Min Express
                  </span>
                </div>

                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                  {activeStore ? activeStore.name : 'No Supermarket Assigned'}
                </h1>

                <p className="text-xs text-emerald-100 max-w-xl">
                  {activeStore ? (
                    <>
                      Exclusively serving residents of{' '}
                      <span className="font-bold text-white underline">
                        {activeApartment?.name}
                      </span>
                      . Fresh groceries delivered straight from the store downstairs!
                    </>
                  ) : (
                    'This apartment currently does not have an active supermarket assigned. Please contact the administrator.'
                  )}
                </p>
              </div>

              {activeStore && (
                <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/15 text-right shrink-0">
                  <div className="text-[11px] uppercase tracking-wider text-emerald-300 font-bold">
                    Delivery Speed
                  </div>
                  <div className="text-lg font-black text-white">
                    {activeStore.deliveryTimeMinutes} Minutes
                  </div>
                  <div className="text-[11px] text-emerald-200 font-medium">
                    Store Rating: ★ {activeStore.rating} / 5
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Promotional Banner Carousel / Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-gradient-to-br from-amber-50 to-orange-100/70 border border-amber-200/80 rounded-2xl p-4 flex items-center justify-between">
              <div>
                <span className="bg-amber-600 text-white text-[10px] font-black px-2 py-0.5 rounded uppercase">
                  Society Exclusive
                </span>
                <h3 className="font-extrabold text-sm text-amber-950 mt-1">
                  Free Delivery on Orders Above ₹199
                </h3>
                <p className="text-xs text-amber-800 mt-0.5">
                  Direct elevator-delivery with zero minimum hassle!
                </p>
              </div>
              <div className="text-3xl">🥦</div>
            </div>

            <div className="bg-gradient-to-br from-emerald-50 to-teal-100/70 border border-emerald-200/80 rounded-2xl p-4 flex items-center justify-between">
              <div>
                <span className="bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded uppercase">
                  Farm Fresh Daily
                </span>
                <h3 className="font-extrabold text-sm text-emerald-950 mt-1">
                  Morning Milk, Eggs & Fresh Vegetables
                </h3>
                <p className="text-xs text-emerald-800 mt-0.5">
                  Handpicked & sanitized stock refreshed at 6:30 AM
                </p>
              </div>
              <div className="text-3xl">🥛</div>
            </div>
          </div>

          {/* Category Horizontal Selector */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-sm text-slate-800 flex items-center gap-1.5">
                <Tag className="w-4 h-4 text-emerald-600" />
                Browse Categories
              </h2>
              {selectedCategory !== 'cat-all' && (
                <button
                  onClick={() => setSelectedCategory('cat-all')}
                  className="text-xs text-emerald-600 font-semibold hover:underline"
                >
                  Show All ({storeProducts.length})
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              {categories.map((cat) => {
                const isSelected = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/50'
                    }`}
                  >
                    <img
                      src={cat.imageUrl}
                      alt={cat.name}
                      className="w-5 h-5 rounded-md object-cover"
                    />
                    <span>{cat.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Product Grid */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-black text-base text-slate-900 tracking-tight">
                {selectedCategory === 'cat-all'
                  ? 'All Grocery Essentials'
                  : categories.find((c) => c.id === selectedCategory)?.name}
              </h2>
              <span className="text-xs text-slate-500 font-medium">
                {filteredProducts.length} Products Available
              </span>
            </div>

            {filteredProducts.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
                <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto mb-2" />
                <h3 className="font-bold text-sm text-slate-800">No matching products</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Try clearing your search query or picking another category.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('cat-all');
                  }}
                  className="mt-3 px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl"
                >
                  Reset Filter
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
                {filteredProducts.map((product) => {
                  const qty = getProductQuantity(product.id);
                  const discountPct =
                    product.mrp > product.price
                      ? Math.round(((product.mrp - product.price) / product.mrp) * 100)
                      : 0;

                  return (
                    <div
                      key={product.id}
                      className="bg-white rounded-2xl border border-slate-200 hover:border-emerald-300 hover:shadow-md transition-all flex flex-col overflow-hidden group"
                    >
                      {/* Product Image Area */}
                      <div className="relative aspect-square bg-slate-50 overflow-hidden">
                        <img
                          src={product.imageUrl}
                          alt={product.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                        />

                        {discountPct > 0 && (
                          <span className="absolute top-2 left-2 bg-emerald-600 text-white text-[10px] font-black px-1.5 py-0.5 rounded-md shadow-xs">
                            {discountPct}% OFF
                          </span>
                        )}

                        <span className="absolute bottom-2 left-2 bg-white/90 backdrop-blur-xs text-slate-800 text-[10px] font-bold px-1.5 py-0.5 rounded shadow-2xs">
                          ⚡ 10m
                        </span>
                      </div>

                      {/* Details Area */}
                      <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                        <div>
                          <span className="text-[10px] font-semibold text-slate-500 block truncate">
                            {product.unit}
                          </span>
                          <h4 className="font-bold text-xs text-slate-900 line-clamp-2 leading-tight mt-0.5 group-hover:text-emerald-700 transition">
                            {product.name}
                          </h4>
                        </div>

                        {/* Price & Action */}
                        <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                          <div>
                            <div className="text-xs font-black text-slate-900">
                              ₹{product.price}
                            </div>
                            {product.mrp > product.price && (
                              <div className="text-[10px] text-slate-400 line-through">
                                ₹{product.mrp}
                              </div>
                            )}
                          </div>

                          {/* Add button or Quantity stepper */}
                          {qty === 0 ? (
                            <button
                              onClick={() => addToCart(product)}
                              className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white border border-emerald-300 hover:border-emerald-600 rounded-lg text-xs font-black transition-all cursor-pointer shadow-2xs"
                            >
                              ADD
                            </button>
                          ) : (
                            <div className="flex items-center bg-emerald-600 text-white rounded-lg px-1.5 py-1 shadow-2xs">
                              <button
                                onClick={() => updateCartQuantity(product.id, qty - 1)}
                                className="w-4 h-4 flex items-center justify-center hover:bg-emerald-700 rounded text-xs font-bold"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="text-xs font-black px-1.5 min-w-[16px] text-center">
                                {qty}
                              </span>
                              <button
                                onClick={() => updateCartQuantity(product.id, qty + 1)}
                                className="w-4 h-4 flex items-center justify-center hover:bg-emerald-700 rounded text-xs font-bold"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Floating Bottom Cart Bar (if items in cart and on home/categories tab) */}
      {cartCount > 0 && activeTab !== 'orders' && (
        <div className="fixed bottom-16 sm:bottom-6 left-0 right-0 z-30 px-4 max-w-lg mx-auto pointer-events-none">
          <button
            onClick={() => setIsCartOpen(true)}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white p-3.5 rounded-2xl shadow-xl shadow-emerald-700/30 flex items-center justify-between pointer-events-auto transform active:scale-98 transition-all cursor-pointer ring-2 ring-white/50"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center font-bold text-xs">
                {cartCount}
              </div>
              <div className="text-left">
                <div className="text-xs font-medium text-emerald-100">
                  {cartCount} {cartCount === 1 ? 'item' : 'items'}
                </div>
                <div className="text-sm font-black">₹{cartTotal}</div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 font-bold text-xs bg-white text-emerald-950 px-3 py-1.5 rounded-xl">
              <span>View Cart</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </button>
        </div>
      )}

      {/* Bottom Navigation Menu */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 py-1.5 px-4 shadow-lg sm:max-w-md sm:mx-auto sm:rounded-t-2xl">
        <div className="flex items-center justify-around">
          {[
            { id: 'home', label: 'Home', icon: <Zap className="w-5 h-5" /> },
            { id: 'categories', label: 'Categories', icon: <Tag className="w-5 h-5" /> },
            {
              id: 'cart',
              label: 'Cart',
              icon: (
                <div className="relative">
                  <ShoppingBag className="w-5 h-5" />
                  {cartCount > 0 && (
                    <span className="absolute -top-1.5 -right-2 bg-emerald-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                      {cartCount}
                    </span>
                  )}
                </div>
              ),
              action: () => setIsCartOpen(true),
            },
            { id: 'orders', label: 'Orders', icon: <Clock className="w-5 h-5" /> },
            { id: 'profile', label: 'Profile', icon: <ShieldCheck className="w-5 h-5" /> },
          ].map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  if (item.action) {
                    item.action();
                  } else {
                    setActiveTab(item.id as any);
                  }
                }}
                className={`flex flex-col items-center py-1 px-2 rounded-xl text-[10px] font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'text-emerald-700'
                    : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                {item.icon}
                <span className="mt-0.5">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Cart Drawer */}
      <CartModal
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onOrderPlaced={(order) => {
          setConfirmedOrder(order);
          setActiveTab('orders');
        }}
      />

      {/* Order Confirmation Feedback */}
      <OrderConfirmationModal
        order={confirmedOrder}
        onClose={() => setConfirmedOrder(null)}
        onViewOrders={() => {
          setConfirmedOrder(null);
          setActiveTab('orders');
        }}
      />
    </div>
  );
};
