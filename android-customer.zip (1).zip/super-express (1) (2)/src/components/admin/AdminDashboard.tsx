import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldCheck,
  Building2,
  Store,
  CreditCard,
  Package,
  TrendingUp,
  Plus,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCcw,
  Search,
  ExternalLink,
  Users,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { Apartment, Store as StoreType } from '../../types';

export const AdminDashboard: React.FC = () => {
  const {
    apartments,
    stores,
    orders,
    subscriptions,
    payments,
    addApartment,
    assignStoreToApartment,
    updateStoreStatus,
    approveStoreApplication,
    rejectStoreApplication,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'overview' | 'apartments' | 'stores' | 'subscriptions' | 'orders'>('overview');
  const [storeFilter, setStoreFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [approvalConflictMsg, setApprovalConflictMsg] = useState('');
  const [rejectModalStoreId, setRejectModalStoreId] = useState<string | null>(null);
  const [rejectReasonInput, setRejectReasonInput] = useState('');

  // Modal for new apartment
  const [isAddApartmentOpen, setIsAddApartmentOpen] = useState(false);
  const [aptName, setAptName] = useState('');
  const [aptAddress, setAptAddress] = useState('');
  const [aptCity, setAptCity] = useState('Bengaluru');
  const [aptPincode, setAptPincode] = useState('560100');
  const [aptTowers, setAptTowers] = useState(6);
  const [aptFlats, setAptFlats] = useState(600);

  // Platform KPIs
  const totalGMV = orders.reduce((sum, o) => sum + o.totalAmount, 0) + 185400;
  const totalPlatformSubscriptions = subscriptions.reduce((sum, s) => sum + s.amount, 0);
  const activeStoresCount = stores.filter((s) => s.status === 'active').length;
  const pendingStoresCount = stores.filter((s) => s.status === 'pending_approval').length;

  const filteredStoresList = stores.filter((s) => {
    if (storeFilter === 'pending') return s.status === 'pending_approval';
    if (storeFilter === 'approved') return s.status === 'active';
    if (storeFilter === 'rejected') return s.status === 'rejected';
    return true;
  });

  const handleApproveStore = async (storeId: string) => {
    setApprovalConflictMsg('');
    const res = await approveStoreApplication(storeId);
    if (!res.success && res.message) {
      setApprovalConflictMsg(res.message);
    }
  };

  const handlePromptReject = (storeId: string) => {
    setRejectModalStoreId(storeId);
    setRejectReasonInput('Another supermarket is already active for this apartment.');
  };

  const handleConfirmReject = async () => {
    if (!rejectModalStoreId) return;
    await rejectStoreApplication(rejectModalStoreId, rejectReasonInput);
    setRejectModalStoreId(null);
  };

  const handleCreateApartment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aptName.trim() || !aptAddress.trim()) return;

    await addApartment({
      name: aptName,
      address: aptAddress,
      city: aptCity,
      pincode: aptPincode,
      totalTowers: Number(aptTowers),
      totalFlats: Number(aptFlats),
      status: 'active',
    });

    setIsAddApartmentOpen(false);
    setAptName('');
    setAptAddress('');
  };

  return (
    <div className="min-h-screen bg-slate-100 p-4 sm:p-6 pb-20">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Admin Header */}
        <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-emerald-500/20">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight">
                  Super Express Platform HQ
                </h1>
                <span className="bg-emerald-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded uppercase">
                  Super Admin
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Centralized Single-Store-Per-Apartment Governance & Subscriptions Controller
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsAddApartmentOpen(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Register New Apartment</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
          {[
            { id: 'overview', label: 'Platform Overview', icon: <TrendingUp className="w-4 h-4" /> },
            { id: 'apartments', label: 'Apartments & Single-Store Binding', badge: apartments.length, icon: <Building2 className="w-4 h-4" /> },
            { id: 'stores', label: 'Supermarkets Approval & Status', badge: pendingStoresCount > 0 ? pendingStoresCount : undefined, icon: <Store className="w-4 h-4" /> },
            { id: 'subscriptions', label: '₹199 Subscription Ledger', icon: <CreditCard className="w-4 h-4" /> },
            { id: 'orders', label: 'Master Society Orders', badge: orders.length, icon: <Package className="w-4 h-4" /> },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
                {tab.badge !== undefined && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                      isActive ? 'bg-emerald-400 text-slate-950 font-black' : 'bg-amber-100 text-amber-900 font-bold'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* TAB 1: Platform Overview */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-slate-500 text-xs font-bold block">Total Platform GMV</span>
                <h3 className="text-2xl font-black text-slate-900 mt-1">₹{totalGMV.toLocaleString()}</h3>
                <p className="text-[11px] text-emerald-600 font-semibold mt-1">Across all registered societies</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-slate-500 text-xs font-bold block">₹199 Subscriptions Collected</span>
                <h3 className="text-2xl font-black text-emerald-800 mt-1">₹{totalPlatformSubscriptions}</h3>
                <p className="text-[11px] text-slate-400 mt-1">Monthly recurring supermarket fee</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-slate-500 text-xs font-bold block">Active Supermarkets</span>
                <h3 className="text-2xl font-black text-slate-900 mt-1">{activeStoresCount} Stores</h3>
                <p className="text-[11px] text-emerald-600 font-semibold mt-1">
                  1 store per apartment ratio strictly enforced
                </p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-slate-500 text-xs font-bold block">Registered Apartments</span>
                <h3 className="text-2xl font-black text-slate-900 mt-1">{apartments.length} Societies</h3>
                <p className="text-[11px] text-slate-400 mt-1">
                  {apartments.reduce((sum, a) => sum + a.totalFlats, 0)} total households served
                </p>
              </div>
            </div>

            {/* Architecture Invariant Banner */}
            <div className="bg-emerald-950 text-white rounded-3xl p-6 border border-emerald-800 flex items-start gap-4 shadow-md">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="font-extrabold text-sm text-emerald-300">
                  Business Model Rule: Single Supermarket Per Apartment
                </h3>
                <p className="text-xs text-emerald-100 leading-relaxed">
                  Every apartment complex is assigned exactly one authorized supermarket partner. Customers belonging to an apartment complex will never see products, listings, or prices from external stores. This protects store revenue and guarantees lightning 10-15 minute delivery!
                </p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: Apartments & Single-Store Binding */}
        {activeTab === 'apartments' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Apartment Territory Assignments</h3>
                  <p className="text-xs text-slate-500">
                    Assign or reassign the single exclusive supermarket for each residential complex
                  </p>
                </div>
                <button
                  onClick={() => setIsAddApartmentOpen(true)}
                  className="px-3 py-1.5 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-black"
                >
                  + Add Society
                </button>
              </div>

              <div className="divide-y divide-slate-100">
                {apartments.map((apt) => {
                  const assignedStore = stores.find((s) => s.id === apt.activeStoreId);

                  return (
                    <div key={apt.id} className="p-4 flex flex-wrap items-center justify-between gap-4 hover:bg-slate-50/70">
                      <div className="space-y-1 max-w-md">
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-sm text-slate-900">{apt.name}</h4>
                          <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-semibold">
                            {apt.city} • {apt.pincode}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500">{apt.address}</p>
                        <div className="text-[11px] text-slate-600 font-medium">
                          {apt.totalTowers} Towers • {apt.totalFlats} Flats
                        </div>
                      </div>

                      {/* Store Assignment Dropdown */}
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <label className="text-[10px] font-bold text-slate-400 uppercase block">
                            Assigned Supermarket:
                          </label>
                          <select
                            value={apt.activeStoreId || ''}
                            onChange={(e) => assignStoreToApartment(apt.id, e.target.value)}
                            className="text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-slate-800 outline-none focus:border-emerald-500"
                          >
                            <option value="" disabled>
                              Select Exclusive Supermarket...
                            </option>
                            {stores.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.name} ({s.ownerName})
                              </option>
                            ))}
                          </select>
                        </div>

                        {assignedStore && (
                          <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold" title="Store active">
                            ✓
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Supermarket Registration Management & Approvals */}
        {activeTab === 'stores' && (
          <div className="space-y-4">
            {/* Sub-navigation for registrations */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200">
              <div className="flex items-center gap-2">
                {[
                  { id: 'all', label: 'All Registrations', count: stores.length },
                  { id: 'pending', label: 'Pending Applications', count: stores.filter((s) => s.status === 'pending_approval').length },
                  { id: 'approved', label: 'Approved & Active', count: stores.filter((s) => s.status === 'active').length },
                  { id: 'rejected', label: 'Rejected', count: stores.filter((s) => s.status === 'rejected').length },
                ].map((st) => {
                  const isCur = storeFilter === st.id;
                  return (
                    <button
                      key={st.id}
                      onClick={() => setStoreFilter(st.id as any)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                        isCur
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <span>{st.label}</span>
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                          isCur ? 'bg-white text-emerald-900 font-extrabold' : 'bg-slate-200 text-slate-700 font-bold'
                        }`}
                      >
                        {st.count}
                      </span>
                    </button>
                  );
                })}
              </div>

              {approvalConflictMsg && (
                <div className="w-full p-3 bg-amber-50 border border-amber-300 text-amber-900 text-xs font-semibold rounded-xl flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>{approvalConflictMsg}</span>
                  <button
                    onClick={() => setApprovalConflictMsg('')}
                    className="ml-auto text-amber-700 hover:text-black font-bold"
                  >
                    Dismiss
                  </button>
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3.5">Supermarket & Address</th>
                    <th className="p-3.5">Owner Details</th>
                    <th className="p-3.5">Assigned Apartment</th>
                    <th className="p-3.5">Single-Store Status</th>
                    <th className="p-3.5">₹199 Subscription</th>
                    <th className="p-3.5 text-right">Admin Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredStoresList.map((s) => {
                    const apt = apartments.find((a) => a.id === s.apartmentId);
                    const conflictStore = stores.find(
                      (st) => st.apartmentId === s.apartmentId && st.status === 'active' && st.id !== s.id
                    );

                    return (
                      <tr key={s.id} className="hover:bg-slate-50/70">
                        <td className="p-3.5">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={s.logoUrl || 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=200&q=80'}
                              alt={s.name}
                              className="w-10 h-10 rounded-xl object-cover border border-slate-200 shrink-0"
                            />
                            <div>
                              <div className="font-bold text-slate-900">{s.name}</div>
                              <div className="text-[10px] text-slate-500 truncate max-w-[200px]">
                                {s.address || 'Address provided on application'}
                              </div>
                              <div className="text-[10px] text-slate-400">
                                Hours: {s.openingTime || '06:30 AM'} - {s.closingTime || '11:00 PM'}
                              </div>
                            </div>
                          </div>
                        </td>

                        <td className="p-3.5">
                          <div className="font-semibold text-slate-800">{s.ownerName}</div>
                          <div className="text-[11px] text-emerald-700 font-mono font-medium">{s.ownerPhone}</div>
                          {s.ownerEmail && (
                            <div className="text-[10px] text-slate-400">{s.ownerEmail}</div>
                          )}
                        </td>

                        <td className="p-3.5">
                          <div className="font-bold text-slate-900">{s.apartmentName || 'Unassigned'}</div>
                          {apt && (
                            <div className="text-[10px] text-slate-500">
                              {apt.totalFlats} Flats • {apt.city}
                            </div>
                          )}
                          {s.status === 'pending_approval' && conflictStore && (
                            <div className="text-[10px] font-bold text-amber-700 mt-1 flex items-center gap-1 bg-amber-50 p-1 rounded border border-amber-200">
                              <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0" />
                              <span>Current active: {conflictStore.name}</span>
                            </div>
                          )}
                        </td>

                        <td className="p-3.5">
                          <span
                            className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${
                              s.status === 'active'
                                ? 'bg-emerald-100 text-emerald-800'
                                : s.status === 'pending_approval'
                                ? 'bg-amber-100 text-amber-900 font-extrabold ring-1 ring-amber-400'
                                : s.status === 'rejected'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {s.status.replace(/_/g, ' ')}
                          </span>
                          {s.status === 'rejected' && s.rejectionReason && (
                            <div className="text-[10px] text-red-600 mt-0.5 max-w-[140px] truncate" title={s.rejectionReason}>
                              {s.rejectionReason}
                            </div>
                          )}
                        </td>

                        <td className="p-3.5">
                          <div className="font-bold text-slate-800">₹{s.monthlyFee} / Mo</div>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                              s.subscriptionStatus === 'active'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {s.subscriptionStatus}
                          </span>
                        </td>

                        <td className="p-3.5 text-right space-x-1.5 whitespace-nowrap">
                          {s.status === 'pending_approval' && (
                            <>
                              <button
                                onClick={() => handleApproveStore(s.id)}
                                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
                              >
                                Approve Store
                              </button>
                              <button
                                onClick={() => handlePromptReject(s.id)}
                                className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs rounded-xl cursor-pointer"
                              >
                                Reject
                              </button>
                            </>
                          )}

                          {s.status === 'active' && (
                            <button
                              onClick={() => updateStoreStatus(s.id, 'suspended')}
                              className="px-2.5 py-1.5 bg-amber-100 text-amber-800 hover:bg-amber-200 font-bold text-xs rounded-xl cursor-pointer"
                            >
                              Suspend Store
                            </button>
                          )}

                          {s.status === 'suspended' && (
                            <button
                              onClick={() => updateStoreStatus(s.id, 'active')}
                              className="px-2.5 py-1.5 bg-emerald-100 text-emerald-800 hover:bg-emerald-200 font-bold text-xs rounded-xl cursor-pointer"
                            >
                              Reactivate
                            </button>
                          )}

                          {s.status === 'rejected' && (
                            <button
                              onClick={() => handleApproveStore(s.id)}
                              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl cursor-pointer"
                            >
                              Re-evaluate
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: ₹199 Subscription Ledger */}
        {activeTab === 'subscriptions' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">₹199 Monthly Store Invoices</h3>
                  <p className="text-xs text-slate-500">
                    Audit platform subscription collections and renewal timestamps
                  </p>
                </div>
                <span className="text-xs font-black text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full">
                  Total Collected: ₹{totalPlatformSubscriptions}
                </span>
              </div>

              <div className="divide-y divide-slate-100">
                {subscriptions.map((sub) => (
                  <div key={sub.id} className="p-4 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-slate-900">{sub.storeName}</div>
                      <div className="text-[10px] text-slate-500">
                        Access period: {sub.periodMonth} (Ref: {sub.paymentId})
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-black text-emerald-700 text-sm">₹{sub.amount}</div>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                        Active & Verified
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: Master Society Orders */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3.5">Order ID</th>
                    <th className="p-3.5">Society & Flat</th>
                    <th className="p-3.5">Customer</th>
                    <th className="p-3.5">Assigned Store</th>
                    <th className="p-3.5">Amount</th>
                    <th className="p-3.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {orders.map((o) => (
                    <tr key={o.id} className="hover:bg-slate-50">
                      <td className="p-3.5 font-bold text-slate-900">#{o.id}</td>
                      <td className="p-3.5">
                        <div className="font-semibold text-slate-800">{o.apartmentName}</div>
                        <div className="text-[10px] text-slate-500">{o.deliveryAddress}</div>
                      </td>
                      <td className="p-3.5">{o.customerName}</td>
                      <td className="p-3.5 font-medium text-emerald-800">{o.storeName}</td>
                      <td className="p-3.5 font-bold text-slate-900">₹{o.totalAmount}</td>
                      <td className="p-3.5">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-800 uppercase">
                          {o.status.replace(/_/g, ' ')}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Register New Apartment Modal */}
      {isAddApartmentOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150">
            <h3 className="font-black text-base text-slate-900 mb-4">
              Register New Apartment Complex
            </h3>

            <form onSubmit={handleCreateApartment} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-600 font-bold block mb-1">Apartment Society Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Godrej Woodsman Estate"
                  value={aptName}
                  onChange={(e) => setAptName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none font-semibold text-slate-800 focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-slate-600 font-bold block mb-1">Street Address</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Bellary Road, Hebbal"
                  value={aptAddress}
                  onChange={(e) => setAptAddress(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none text-slate-800 focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-600 font-bold block mb-1">City</label>
                  <input
                    type="text"
                    required
                    value={aptCity}
                    onChange={(e) => setAptCity(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none"
                  />
                </div>
                <div>
                  <label className="text-slate-600 font-bold block mb-1">Pincode</label>
                  <input
                    type="text"
                    required
                    value={aptPincode}
                    onChange={(e) => setAptPincode(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-600 font-bold block mb-1">Total Towers</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={aptTowers}
                    onChange={(e) => setAptTowers(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-600 font-bold block mb-1">Total Flats / Doors</label>
                  <input
                    type="number"
                    required
                    min={10}
                    value={aptFlats}
                    onChange={(e) => setAptFlats(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none font-bold"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddApartmentOpen(false)}
                  className="flex-1 py-2.5 text-slate-600 hover:bg-slate-100 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-2 py-2.5 bg-slate-900 hover:bg-black text-white rounded-xl font-bold cursor-pointer"
                >
                  Register Apartment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reject Application Reason Modal */}
      {rejectModalStoreId && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150">
            <h3 className="font-black text-base text-slate-900 mb-2">
              Reject Supermarket Application
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Enter the reason for rejecting this application. The owner will be notified with this feedback.
            </p>
            <textarea
              rows={3}
              value={rejectReasonInput}
              onChange={(e) => setRejectReasonInput(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs outline-none focus:border-red-500 resize-none mb-4"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setRejectModalStoreId(null)}
                className="flex-1 py-2.5 text-slate-600 hover:bg-slate-100 rounded-xl font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmReject}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-xs shadow-md"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
