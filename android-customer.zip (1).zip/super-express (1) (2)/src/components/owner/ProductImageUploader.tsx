import React, { useEffect, useRef, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import {
  UploadCloud,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Trash2,
  Camera,
  Loader2,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import { auth, signInWithGoogleForFirebase } from '../../firebase';
import {
  CloudinaryUploadProgress,
  CloudinaryUploadResult,
  getCloudinaryConfig,
  resolveImageMimeType,
  uploadImageToCloudinary,
} from '../../services/cloudinary';

interface ProductImageUploaderProps {
  imageUrl: string;
  imagePublicId?: string;
  onImageUploaded: (result: CloudinaryUploadResult) => void;
  onImageRemoved: () => void;
  onUploadingChange?: (isUploading: boolean) => void;
}

export const ProductImageUploader: React.FC<ProductImageUploaderProps> = ({
  imageUrl,
  imagePublicId,
  onImageUploaded,
  onImageRemoved,
  onUploadingChange,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [progressInfo, setProgressInfo] = useState<CloudinaryUploadProgress | null>(null);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string>('');
  const [selectedFileName, setSelectedFileName] = useState<string>('');
  const [lastSelectedFile, setLastSelectedFile] = useState<File | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [firebaseUserEmail, setFirebaseUserEmail] = useState<string | null>(
    () => auth.currentUser?.email || auth.currentUser?.uid || null
  );

  const cloudinaryConfig = getCloudinaryConfig();

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setFirebaseUserEmail(user?.email || user?.uid || null);
    });
    return () => unsub();
  }, []);

  const startUpload = async (file: File) => {
    setErrorMsg('');
    setSuccessMsg('');
    setSelectedFileName(file.name);
    setLastSelectedFile(file);

    // Require Firebase Authentication before allowing upload
    if (!auth.currentUser) {
      setErrorMsg(
        'Firebase authentication is required before uploading product images. Please sign in with Google first.'
      );
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    // Validate image format (JPG, JPEG, PNG, WEBP)
    if (!resolveImageMimeType(file)) {
      setErrorMsg('Unsupported format. Please select a JPG, JPEG, PNG, or WEBP image.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    // Validate image size on client (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('Image file exceeds 5 MB limit. Please select a smaller photo from your gallery.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setIsUploading(true);
    onUploadingChange?.(true);
    setUploadProgress(0);
    setProgressInfo({ progress: 0, bytesTransferred: 0, totalBytes: file.size });

    try {
      const result = await uploadImageToCloudinary(file, (progress, info) => {
        setUploadProgress(progress);
        if (info) setProgressInfo(info);
      });

      onImageUploaded(result);
      setIsUploading(false);
      onUploadingChange?.(false);
      setSuccessMsg('Product image uploaded to Cloudinary!');
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      console.warn('Cloudinary product image upload error:', err?.message || err);
      setErrorMsg(err?.message || 'Failed to upload image to Cloudinary. Please try again.');
      setIsUploading(false);
      onUploadingChange?.(false);
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      startUpload(file);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsSigningIn(true);
    setErrorMsg('');
    try {
      const user = await signInWithGoogleForFirebase();
      setFirebaseUserEmail(user.email || user.uid);
      if (lastSelectedFile) {
        await startUpload(lastSelectedFile);
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Firebase Google Sign-In cancelled or failed.');
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleRetry = () => {
    if (lastSelectedFile) {
      startUpload(lastSelectedFile);
    } else {
      triggerPicker();
    }
  };

  const triggerPicker = () => {
    if (!auth.currentUser) {
      setErrorMsg('Please sign in with Google (Firebase Auth) before selecting an image to upload.');
      return;
    }
    fileInputRef.current?.click();
  };

  const formatFileSize = (bytes?: number) => {
    if (bytes === undefined || bytes === null) return '';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) {
      return `${Math.round(bytes / 1024)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <label className="text-slate-800 font-bold text-xs flex items-center gap-1.5">
          <span>Product Image</span>
          <span className="text-rose-500 font-black">*</span>
          <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
            Cloudinary CDN
          </span>
        </label>
        <div className="flex items-center gap-2">
          {firebaseUserEmail ? (
            <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> Auth Ready
            </span>
          ) : (
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isSigningIn}
              className="text-[10px] font-bold text-emerald-700 hover:text-emerald-900 underline cursor-pointer"
            >
              {isSigningIn ? 'Signing in...' : 'Sign in with Google'}
            </button>
          )}
          <span className="text-[10px] text-slate-400 font-medium">
            JPG, PNG, WEBP (Max 5 MB)
          </span>
        </div>
      </div>

      {/* Hidden native input with Android mobile gallery + desktop support */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"
        onChange={handleFileSelect}
        className="hidden"
      />

      {!cloudinaryConfig.isConfigured && (
        <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs space-y-1">
          <div className="font-bold">Cloudinary configuration required</div>
          <p className="text-[11px] leading-relaxed">
            Set <code className="font-mono font-bold">VITE_CLOUDINARY_CLOUD_NAME</code> and{' '}
            <code className="font-mono font-bold">VITE_CLOUDINARY_UPLOAD_PRESET</code> in your
            environment variables to enable image uploads.
          </p>
        </div>
      )}

      {/* Require Firebase Authentication gate before allowing new uploads */}
      {!firebaseUserEmail && !imageUrl && !isUploading && (
        <div className="border-2 border-dashed border-amber-300 bg-amber-50/70 rounded-2xl p-5 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-white text-amber-600 flex items-center justify-center mx-auto shadow-xs border border-amber-200">
            <Lock className="w-6 h-6" />
          </div>
          <div>
            <div className="text-sm font-black text-slate-900">
              Firebase Sign-In Required to Upload
            </div>
            <p className="text-xs text-slate-600 mt-1 max-w-sm mx-auto">
              Verify your owner session with Firebase Authentication before selecting product photos from your phone gallery.
            </p>
          </div>
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={isSigningIn}
            className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{isSigningIn ? 'Signing in...' : 'Sign in with Google (Firebase Auth)'}</span>
          </button>
        </div>
      )}

      {/* 1. AUTHENTICATED & NO IMAGE YET - Gallery Upload Button */}
      {firebaseUserEmail && !imageUrl && !isUploading && (
        <div
          onClick={triggerPicker}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && triggerPicker()}
          className="border-2 border-dashed border-emerald-300 hover:border-emerald-500 bg-emerald-50/60 hover:bg-emerald-50 rounded-2xl p-6 text-center cursor-pointer transition-all duration-150 group shadow-2xs"
        >
          <div className="w-14 h-14 rounded-2xl bg-white text-emerald-600 flex items-center justify-center mx-auto mb-3 shadow-sm group-hover:scale-108 transition-transform border border-emerald-100">
            <Camera className="w-7 h-7" />
          </div>
          <div className="text-sm font-black text-slate-800 tracking-tight">
            Select Photo from Mobile Gallery
          </div>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Tap to open your phone gallery or photos. Uploads directly to Cloudinary (Max 5 MB).
          </p>
          <div className="mt-3 inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer">
            <UploadCloud className="w-4 h-4" />
            <span>Open Gallery / Choose Photo</span>
          </div>
        </div>
      )}

      {/* 2. REAL-TIME PROGRESS PERCENTAGE BAR (0% - 100% from actual XHR upload events) */}
      {isUploading && (
        <div className="border border-emerald-300 bg-emerald-50/90 rounded-2xl p-5 text-center space-y-3.5 shadow-xs">
          <div className="flex items-center justify-center gap-2">
            <div className="w-9 h-9 rounded-full bg-emerald-600 text-white flex items-center justify-center animate-spin">
              <Loader2 className="w-5 h-5" />
            </div>
            <div className="text-left">
              <div className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <span>Uploading to Cloudinary...</span>
                <span className="text-emerald-700 font-extrabold text-sm">{uploadProgress}%</span>
              </div>
              <p className="text-[11px] text-slate-600 truncate max-w-xs">
                {selectedFileName}
                {progressInfo
                  ? ` (${formatFileSize(progressInfo.bytesTransferred)} / ${formatFileSize(progressInfo.totalBytes)})`
                  : ''}
              </p>
            </div>
          </div>

          <div className="space-y-1">
            <div className="w-full bg-emerald-200/80 h-2.5 rounded-full overflow-hidden p-0.5">
              <div
                className="bg-emerald-600 h-full rounded-full transition-all duration-150 ease-out shadow-xs"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-[10px] text-slate-500 px-0.5 font-medium">
              <span>Live upload progress</span>
              <span className="font-bold text-emerald-800">{uploadProgress}%</span>
            </div>
          </div>
        </div>
      )}

      {/* 3. UPLOADED IMAGE PREVIEW WITH CHANGE & REMOVE ACTIONS */}
      {imageUrl && !isUploading && (
        <div className="border border-slate-200 bg-slate-50/80 rounded-2xl p-3.5 flex items-center gap-3.5 shadow-2xs">
          <div className="relative w-20 h-20 rounded-xl overflow-hidden bg-white border border-slate-200 shrink-0 shadow-xs">
            <img
              src={imageUrl}
              alt="Uploaded Product"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="flex-1 min-w-0 space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-black text-emerald-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="truncate">
                {imagePublicId
                  ? 'Image Ready on Cloudinary'
                  : imageUrl.includes('openfoodfacts.org')
                  ? 'Auto-filled from Open Food Facts'
                  : 'Product Image Ready'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 truncate">
              {selectedFileName ? `${selectedFileName} • ` : ''}
              {imagePublicId
                ? `ID: ${imagePublicId}`
                : imageUrl.includes('openfoodfacts.org')
                ? 'You can keep this photo or replace it from your gallery.'
                : 'Secure HTTPS URL linked.'}
            </p>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={triggerPicker}
                className="px-3 py-1.5 bg-white hover:bg-slate-100 active:scale-98 border border-slate-300 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
              >
                <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
                <span>Change Image</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onImageRemoved();
                  setSelectedFileName('');
                  setLastSelectedFile(null);
                  setErrorMsg('');
                  setSuccessMsg('');
                }}
                className="px-3 py-1.5 bg-red-50 hover:bg-red-100 active:scale-98 border border-red-200 text-red-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-500" />
                <span>Remove</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. SUCCESS BANNER */}
      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2 animate-in fade-in-50 duration-150">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* 5. ERROR DISPLAY WITH AUTH / RETRY ACTIONS */}
      {errorMsg && (
        <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 text-xs space-y-2 animate-in fade-in-50 duration-150">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div className="flex-1 font-medium leading-relaxed break-words">{errorMsg}</div>
          </div>
          <div className="flex flex-wrap items-center gap-2 pt-1 pl-6">
            {!firebaseUserEmail && (
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isSigningIn}
                className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white font-bold text-[11px] rounded-lg flex items-center gap-1 cursor-pointer transition"
              >
                <ShieldCheck className="w-3 h-3" />
                <span>{isSigningIn ? 'Signing in...' : 'Sign in with Google (Firebase Auth)'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={handleRetry}
              className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] rounded-lg flex items-center gap-1 cursor-pointer transition"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry Upload</span>
            </button>
            <button
              type="button"
              onClick={triggerPicker}
              className="px-3 py-1 bg-white border border-rose-300 text-rose-700 font-bold text-[11px] rounded-lg cursor-pointer transition hover:bg-rose-50"
            >
              <span>Select Another Photo</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
