package com.superexpress.customer

import com.superexpress.customer.data.SeedCatalog
import com.superexpress.customer.data.model.CartItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CustomerCatalogTest {
    @Test
    fun seedCatalogHasActiveSocietiesAndProducts() {
        assertTrue(SeedCatalog.apartments.isNotEmpty())
        assertTrue(SeedCatalog.stores.isNotEmpty())
        assertTrue(SeedCatalog.products.isNotEmpty())
    }

    @Test
    fun discountCalculationIsAccurate() {
        val tomatoes = SeedCatalog.products.first { it.id == "prod-fm-01" }
        assertEquals(24, tomatoes.discountPercent)
    }

    @Test
    fun freeDeliveryAppliesAtOrAbove199() {
        val milk = SeedCatalog.products.first { it.id == "prod-fm-04" }
        val atta = SeedCatalog.products.first { it.id == "prod-fm-07" }
        val smallCart = listOf(CartItem(milk, 2))
        val largeCart = listOf(CartItem(atta, 1))

        val smallFee = if (smallCart.sumOf { it.lineTotal } >= 199.0) 0.0 else 25.0
        val largeFee = if (largeCart.sumOf { it.lineTotal } >= 199.0) 0.0 else 25.0

        assertEquals(25.0, smallFee, 0.001)
        assertEquals(0.0, largeFee, 0.001)
    }
}
