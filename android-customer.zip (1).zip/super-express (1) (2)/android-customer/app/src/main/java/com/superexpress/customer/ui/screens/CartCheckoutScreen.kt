package com.superexpress.customer.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.superexpress.customer.data.model.Order
import com.superexpress.customer.ui.theme.EmeraldDark
import com.superexpress.customer.ui.theme.EmeraldLight
import com.superexpress.customer.ui.theme.EmeraldPrimary
import com.superexpress.customer.ui.theme.RoseDanger
import com.superexpress.customer.ui.theme.SlateInk
import com.superexpress.customer.ui.theme.SlateMuted
import com.superexpress.customer.ui.viewmodel.CustomerUiState

@Composable
fun CartCheckoutScreen(
    uiState: CustomerUiState,
    onBack: () -> Unit,
    onUpdateQuantity: (String, Int) -> Unit,
    onClearCart: () -> Unit,
    onPlaceOrder: (paymentMethod: String, block: String, flatNumber: String) -> Unit,
    onConfirmOnlinePayment: () -> Unit,
    onDismissOnlinePayment: () -> Unit,
    onDismissConfirmedOrder: () -> Unit
) {
    var paymentMethod by remember { mutableStateOf("ONLINE") }
    var block by remember(uiState.profile.block) {
        mutableStateOf(uiState.profile.block.ifBlank { "Tower A" })
    }
    var flatNumber by remember(uiState.profile.flatNumber) {
        mutableStateOf(uiState.profile.flatNumber.ifBlank { "101" })
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        Surface(color = Color(0xFF0F172A)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Column {
                        Text(
                            text = "Your Grocery Basket",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "From ${uiState.activeStore?.name ?: "Supermarket"}",
                            color = Color(0xFFA7F3D0),
                            fontSize = 11.sp
                        )
                    }
                }
                if (uiState.cart.isNotEmpty()) {
                    IconButton(onClick = onClearCart) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = "Clear Cart", tint = Color(0xFFFCA5A5))
                    }
                }
            }
        }

        if (uiState.cart.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(40.dp))
                        .background(EmeraldLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.ShoppingBag,
                        contentDescription = null,
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(40.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Your basket is empty",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = SlateInk
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Add fresh groceries from ${uiState.activeStore?.name ?: "your supermarket"} to place an order.",
                    fontSize = 13.sp,
                    color = SlateMuted
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onBack,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("Start Shopping", fontWeight = FontWeight.Bold)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Delivering to ${uiState.activeApartment?.name ?: ""}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = EmeraldDark
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = block,
                                    onValueChange = { block = it },
                                    label = { Text("Block / Tower") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                OutlinedTextField(
                                    value = flatNumber,
                                    onValueChange = { flatNumber = it },
                                    label = { Text("Flat No") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        }
                    }
                }

                items(uiState.cart, key = { it.product.id }) { item ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncImage(
                                model = item.product.imageUrl,
                                contentDescription = item.product.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.product.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = SlateInk,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${item.product.unit} • ₹${item.product.price.toInt()}",
                                    fontSize = 11.sp,
                                    color = SlateMuted
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(EmeraldLight.copy(alpha = 0.7f))
                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Remove,
                                    contentDescription = "Remove",
                                    tint = EmeraldDark,
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clickable { onUpdateQuantity(item.product.id, item.quantity - 1) }
                                )
                                Text(
                                    text = item.quantity.toString(),
                                    color = EmeraldDark,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                                Icon(
                                    imageVector = Icons.Filled.Add,
                                    contentDescription = "Add",
                                    tint = EmeraldDark,
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clickable { onUpdateQuantity(item.product.id, item.quantity + 1) }
                                )
                            }
                        }
                    }
                }

                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Bill Details", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateInk)
                            BillRow("Item Total", "₹${uiState.cartSubtotal.toInt()}")
                            BillRow(
                                "Delivery Fee",
                                if (uiState.deliveryFee == 0.0) "FREE" else "₹${uiState.deliveryFee.toInt()}",
                                highlight = uiState.deliveryFee == 0.0
                            )
                            BillRow("Handling & Packaging", "₹${uiState.handlingFee.toInt()}")
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("To Pay", fontWeight = FontWeight.Black, fontSize = 15.sp, color = SlateInk)
                                Text(
                                    "₹${uiState.grandTotal.toInt()}",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    color = EmeraldPrimary
                                )
                            }
                        }
                    }
                }

                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Select Payment Method", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateInk)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                PaymentOptionCard(
                                    title = "Pay Online",
                                    subtitle = "UPI / Cards",
                                    icon = Icons.Filled.CreditCard,
                                    selected = paymentMethod == "ONLINE",
                                    onClick = { paymentMethod = "ONLINE" },
                                    modifier = Modifier.weight(1f)
                                )
                                PaymentOptionCard(
                                    title = "Cash on Delivery",
                                    subtitle = "Pay at doorstep",
                                    icon = Icons.Filled.Money,
                                    selected = paymentMethod == "COD",
                                    onClick = { paymentMethod = "COD" },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            Surface(color = Color.White, shadowElevation = 8.dp) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (!uiState.checkoutError.isNullOrBlank()) {
                        Text(
                            text = uiState.checkoutError,
                            color = RoseDanger,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }
                    Button(
                        onClick = { onPlaceOrder(paymentMethod, block, flatNumber) },
                        enabled = !uiState.isPlacingOrder,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        if (uiState.isPlacingOrder) {
                            CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Placing Order...", fontWeight = FontWeight.Bold)
                        } else {
                            Text(
                                text = if (paymentMethod == "ONLINE") {
                                    "Proceed to Pay ₹${uiState.grandTotal.toInt()}"
                                } else {
                                    "Place COD Order • ₹${uiState.grandTotal.toInt()}"
                                },
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }

    val pendingOrder = uiState.pendingOnlineOrder
    if (pendingOrder != null) {
        AlertDialog(
            onDismissRequest = onDismissOnlinePayment,
            icon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = EmeraldPrimary) },
            title = { Text("Super Express Pay", fontWeight = FontWeight.Black) },
            text = {
                Text(
                    "Confirm UPI / Card payment of ₹${pendingOrder.totalAmount.toInt()} for Order #${pendingOrder.id}."
                )
            },
            confirmButton = {
                Button(
                    onClick = onConfirmOnlinePayment,
                    enabled = !uiState.isVerifyingOnlinePayment,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text(if (uiState.isVerifyingOnlinePayment) "Verifying..." else "Pay ₹${pendingOrder.totalAmount.toInt()} Now")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = onDismissOnlinePayment) {
                    Text("Cancel")
                }
            }
        )
    }

    val confirmed: Order? = uiState.confirmedOrder
    if (confirmed != null) {
        AlertDialog(
            onDismissRequest = onDismissConfirmedOrder,
            icon = { Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(40.dp)) },
            title = { Text("Order Placed!", fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Order #${confirmed.id} from ${confirmed.storeName} is confirmed!")
                    Text("Total: ₹${confirmed.totalAmount.toInt()} (${confirmed.paymentMethod})", fontWeight = FontWeight.Bold)
                    Text("Delivery OTP: ${confirmed.deliveryOtp}", fontWeight = FontWeight.Black, color = EmeraldDark)
                }
            },
            confirmButton = {
                Button(
                    onClick = onDismissConfirmedOrder,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("Track Order")
                }
            }
        )
    }
}

@Composable
private fun BillRow(label: String, value: String, highlight: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = SlateMuted)
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (highlight) EmeraldPrimary else SlateInk
        )
    }
}

@Composable
private fun PaymentOptionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        color = if (selected) EmeraldLight.copy(alpha = 0.5f) else Color(0xFFF8FAFC),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) EmeraldPrimary else Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SlateInk)
                Text(subtitle, fontSize = 10.sp, color = SlateMuted)
            }
        }
    }
}
