export const OPEN_FOOD_FACTS_ENDPOINT = 'https://world.openfoodfacts.org/api/v2/product';
export const OPEN_FOOD_FACTS_FIELDS = 'product_name,brands,categories,image_front_url,quantity';
export const OPEN_FOOD_FACTS_USER_AGENT = 'SuperExpress/1.0 (karunakar.bhogapathi@gmail.com)';
const REQUEST_TIMEOUT_MS = 12000;

export interface OpenFoodFactsProductDetails {
  barcode: string;
  productName: string;
  brand: string;
  categoryId: string | null;
  rawCategory: string;
  packagingOrWeight: string;
  imageUrl: string;
}

export type OpenFoodFactsLookupResult =
  | {
      status: 'found';
      product: OpenFoodFactsProductDetails;
      httpStatus?: number;
      fromCache?: boolean;
      source?: 'proxy' | 'direct';
    }
  | {
      status: 'not_found';
      message: string;
      httpStatus?: number;
      fromCache?: boolean;
      source?: 'proxy' | 'direct';
    }
  | {
      status: 'invalid';
      message: string;
    }
  | {
      status: 'error';
      message: string;
      httpStatus?: number;
      errorType?: 'network' | 'timeout' | 'http' | 'json';
      fromCache?: boolean;
    };

// Cache successful and confirmed not-found lookups; never cache transient errors
type CacheableLookupResult = Extract<OpenFoodFactsLookupResult, { status: 'found' | 'not_found' }>;
const lookupCache = new Map<string, CacheableLookupResult>();
const inFlightRequests = new Map<string, Promise<OpenFoodFactsLookupResult>>();

export function clearOpenFoodFactsCache(): void {
  lookupCache.clear();
  inFlightRequests.clear();
}

/**
 * Normalizes a scanned or manually typed barcode by removing whitespace,
 * hyphens, and invisible scanner control characters (e.g. CR/LF/GS1 FNC1).
 */
export function normalizeBarcode(rawBarcode: string): string {
  return String(rawBarcode || '')
    .replace(/[\u0000-\u001F\u007F\s-]+/g, '')
    .trim();
}

/**
 * Validates standard numeric retail barcodes (UPC-E 6-8, EAN-8 8, UPC-A 12, EAN-13 13, GTIN-14 14).
 */
export function isValidBarcode(normalizedBarcode: string): boolean {
  return /^\d{6,14}$/.test(normalizedBarcode);
}

export function mapOpenFoodFactsCategory(
  categoriesTags: unknown,
  categoriesText: unknown
): string | null {
  const tagsList = Array.isArray(categoriesTags)
    ? categoriesTags.map((t) => String(t).toLowerCase())
    : [];
  const rawCombined = `${tagsList.join(' ')} ${typeof categoriesText === 'string' ? categoriesText.toLowerCase() : ''}`;
  const normalized = ` ${rawCombined.replace(/[^a-z0-9]+/g, ' ').trim()} `;

  if (!normalized.trim()) return null;

  if (
    /\b(cleaning|detergent|laundry|dishwash|dishwashing|soap|sanitizer|cleaner|paper towel|tissue|bleach|disinfectant)\b/.test(
      normalized
    )
  ) {
    return 'cat-cleaning';
  }
  if (
    /\b(potato chips|potato crisps|corn chips|tortilla chips|snack|snacks|chip|chips|crisp|crisps|biscuit|biscuits|cookie|cookies|chocolate|chocolates|sweet spreads|hazelnut spreads|hazelnut|hazelnuts|cocoa|chocolate spreads|confectionery|candy|candies|namkeen|instant noodles|noodles|cereal|cereals|cracker|crackers|popcorn|wafer|wafers)\b/.test(
      normalized
    )
  ) {
    return 'cat-snacks';
  }
  if (
    /\b(beverage|beverages|drink|drinks|juice|juices|soda|sodas|cola|colas|tea|teas|coffee|water|soft drink|soft drinks|iced tea|milkshake|energy drink)\b/.test(
      normalized
    )
  ) {
    return 'cat-beverages';
  }
  if (
    /\b(dairy|milk|milks|cheese|cheeses|yogurt|yogurts|yoghurt|butter|ghee|paneer|curd|bread|breads|bakery|egg|eggs|cream)\b/.test(
      normalized
    )
  ) {
    return 'cat-dairy';
  }
  if (
    /\b(vegetable|vegetables|fruit|fruits|fresh produce|potato|potatoes|tomato|tomatoes|onion|onions|salad|greens|herbs|apple|apples|banana|bananas|mango|mangoes|watermelon)\b/.test(
      normalized
    )
  ) {
    return 'cat-vegetables';
  }
  if (
    /\b(flour|atta|rice|dal|lentil|lentils|pulse|pulses|grain|grains|spice|spices|masala|cooking oil|vegetable oil|olive oil|sunflower oil|mustard oil|sugar|salt|pasta|staple|staples|condiment|condiments|sauce|sauces|ketchup|honey|jam|spread|spreads)\b/.test(
      normalized
    )
  ) {
    return 'cat-staples';
  }

  return null;
}

function parseOpenFoodFactsPayload(
  barcode: string,
  data: any,
  httpStatus: number,
  source: 'proxy' | 'direct'
): OpenFoodFactsLookupResult {
  if (!data || typeof data !== 'object') {
    return {
      status: 'error',
      errorType: 'json',
      httpStatus,
      message: 'Unexpected response format from Open Food Facts. Please enter details manually.',
    };
  }

  // Open Food Facts API v2 convention: status === 1 (found), status === 0 (not found)
  if (data.status === 0 || (data.status !== 1 && !data.product)) {
    return {
      status: 'not_found',
      httpStatus,
      source,
      message: 'Product not found. Please enter details manually.',
    };
  }

  if (data.status !== 1 || !data.product) {
    return {
      status: 'not_found',
      httpStatus,
      source,
      message: 'Product not found. Please enter details manually.',
    };
  }

  const p = data.product;
  const productName = typeof p.product_name === 'string' ? p.product_name.trim() : '';
  const brand =
    typeof p.brands === 'string'
      ? p.brands
          .split(',')[0]
          .trim()
      : '';
  const packagingOrWeight = typeof p.quantity === 'string' ? p.quantity.trim() : '';
  const imageUrl = typeof p.image_front_url === 'string' ? p.image_front_url.trim() : '';
  const rawCategory =
    typeof p.categories === 'string' ? p.categories.split(',')[0].trim() : '';
  const categoryId = mapOpenFoodFactsCategory(undefined, p.categories);

  if (!productName && !brand && !packagingOrWeight && !imageUrl) {
    return {
      status: 'not_found',
      httpStatus,
      source,
      message: 'Product not found. Please enter details manually.',
    };
  }

  return {
    status: 'found',
    httpStatus,
    source,
    product: {
      barcode,
      productName,
      brand,
      categoryId,
      rawCategory,
      packagingOrWeight,
      imageUrl,
    },
  };
}

/**
 * Calls https://world.openfoodfacts.org/api/v2/product/{barcode}.json directly.
 * Browser restrictions forbid setting User-Agent on fetch(), so User-Agent is only
 * attached in non-browser runtimes while browsers use a CORS-safe simple GET request.
 */
async function fetchDirectFromOpenFoodFacts(
  barcode: string
): Promise<OpenFoodFactsLookupResult> {
  const controller = new AbortController();
  const timeoutId = globalThis.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  const endpoint = `${OPEN_FOOD_FACTS_ENDPOINT}/${encodeURIComponent(
    barcode
  )}.json?fields=${OPEN_FOOD_FACTS_FIELDS}`;

  const isBrowser = typeof window !== 'undefined' && typeof document !== 'undefined';
  const headers: Record<string, string> = {
    Accept: 'application/json',
  };
  if (!isBrowser) {
    headers['User-Agent'] = OPEN_FOOD_FACTS_USER_AGENT;
  }

  let response: Response;
  try {
    response = await fetch(endpoint, {
      method: 'GET',
      mode: 'cors',
      headers,
      signal: controller.signal,
    });
  } catch (err: unknown) {
    globalThis.clearTimeout(timeoutId);
    if (err instanceof Error && err.name === 'AbortError') {
      return {
        status: 'error',
        errorType: 'timeout',
        message: 'Product lookup timed out. Please enter details manually.',
      };
    }
    return {
      status: 'error',
      errorType: 'network',
      message:
        'Connection error while searching Open Food Facts. Please check your internet connection or enter details manually.',
    };
  } finally {
    globalThis.clearTimeout(timeoutId);
  }

  let rawText = '';
  try {
    rawText = await response.text();
  } catch {
    return {
      status: 'error',
      errorType: 'network',
      httpStatus: response.status,
      message:
        'Connection interrupted while reading Open Food Facts response. Please enter details manually.',
    };
  }

  let parsed: any = null;
  if (rawText.trim()) {
    try {
      parsed = JSON.parse(rawText);
    } catch {
      parsed = null;
    }
  }

  // Open Food Facts returns HTTP 404 with JSON { status: 0, status_verbose: "product not found" }
  if (response.status === 404) {
    if (parsed && parsed.status === 1 && parsed.product) {
      return parseOpenFoodFactsPayload(barcode, parsed, response.status, 'direct');
    }
    return {
      status: 'not_found',
      httpStatus: 404,
      source: 'direct',
      message: 'Product not found. Please enter details manually.',
    };
  }

  if (!response.ok) {
    return {
      status: 'error',
      errorType: 'http',
      httpStatus: response.status,
      message: `Open Food Facts lookup failed (HTTP ${response.status}). Please enter details manually.`,
    };
  }

  if (!parsed) {
    return {
      status: 'error',
      errorType: 'json',
      httpStatus: response.status,
      message: 'Invalid JSON response from Open Food Facts. Please enter details manually.',
    };
  }

  return parseOpenFoodFactsPayload(barcode, parsed, response.status, 'direct');
}

/**
 * Uses the same-origin Express backend proxy (/api/openfoodfacts/:barcode) when running in the
 * browser so the server can send the official User-Agent header and avoid client CORS/ISP failures.
 * Returns null if no proxy route is mounted (e.g. static deployment), allowing direct HTTPS fallback.
 */
async function fetchViaBackendProxy(barcode: string): Promise<OpenFoodFactsLookupResult | null> {
  if (typeof window === 'undefined') {
    return null;
  }

  const controller = new AbortController();
  const timeoutId = globalThis.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS + 1000);

  let response: Response;
  try {
    response = await fetch(`/api/openfoodfacts/${encodeURIComponent(barcode)}`, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    });
  } catch {
    globalThis.clearTimeout(timeoutId);
    return null;
  } finally {
    globalThis.clearTimeout(timeoutId);
  }

  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    // Proxy endpoint is not mounted (e.g., Vite SPA HTML fallback on static hosting)
    return null;
  }

  let data: any;
  try {
    data = await response.json();
  } catch {
    return null;
  }

  if (data && data.error) {
    const errorType =
      data.error === 'timeout'
        ? 'timeout'
        : data.error === 'http_error'
        ? 'http'
        : data.error === 'invalid_json'
        ? 'json'
        : 'network';

    // If proxy failed due to a transient network/gateway issue, let caller decide whether to try direct
    return {
      status: 'error',
      errorType,
      httpStatus: typeof data.upstreamHttpStatus === 'number' ? data.upstreamHttpStatus : response.status,
      message:
        typeof data.message === 'string' && data.message
          ? data.message
          : 'Connection error while searching Open Food Facts. Please enter details manually.',
    };
  }

  const upstreamStatus =
    typeof data?.upstreamHttpStatus === 'number' ? data.upstreamHttpStatus : response.status;

  return parseOpenFoodFactsPayload(barcode, data, upstreamStatus, 'proxy');
}

export async function lookupProductByBarcode(
  rawBarcode: string
): Promise<OpenFoodFactsLookupResult> {
  const barcode = normalizeBarcode(rawBarcode);
  if (!barcode) {
    return {
      status: 'invalid',
      message: 'Please enter or scan a barcode number first.',
    };
  }

  if (!isValidBarcode(barcode)) {
    return {
      status: 'invalid',
      message:
        'Barcode must be 6–14 digits for Open Food Facts lookup. You can still enter product details manually.',
    };
  }

  const cached = lookupCache.get(barcode);
  if (cached) {
    return { ...cached, fromCache: true };
  }

  const existingRequest = inFlightRequests.get(barcode);
  if (existingRequest) {
    return existingRequest;
  }

  const requestPromise = (async (): Promise<OpenFoodFactsLookupResult> => {
    try {
      // 1. In browser, prefer the same-origin Express proxy so User-Agent & CORS are handled cleanly
      const proxyResult = await fetchViaBackendProxy(barcode);
      if (proxyResult) {
        if (proxyResult.status === 'found' || proxyResult.status === 'not_found') {
          lookupCache.set(barcode, proxyResult);
          return proxyResult;
        }
        if (proxyResult.status === 'error' && proxyResult.errorType !== 'network') {
          return proxyResult;
        }
      }

      // 2. Fallback to direct HTTPS Open Food Facts v2 API (Node runtime, static hosting, or proxy network fallback)
      const directResult = await fetchDirectFromOpenFoodFacts(barcode);
      if (directResult.status === 'found' || directResult.status === 'not_found') {
        lookupCache.set(barcode, directResult);
      }
      return directResult;
    } finally {
      inFlightRequests.delete(barcode);
    }
  })();

  inFlightRequests.set(barcode, requestPromise);
  return requestPromise;
}
