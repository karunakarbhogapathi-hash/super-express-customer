package com.superexpress.customer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superexpress.customer.data.model.Order
import com.superexpress.customer.ui.theme.EmeraldDark
import com.superexpress.customer.ui.theme.EmeraldLight
import com.superexpress.customer.ui.theme.EmeraldPrimary
import com.superexpress.customer.ui.theme.RoseDanger
import com.superexpress.customer.ui.theme.SlateInk
import com.superexpress.customer.ui.theme.SlateMuted

@Composable
fun OrdersScreen(
    orders: List<Order>,
    onReorder: (Order) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC)),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "My Orders & Tracking",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = SlateInk
                )
                Text(
                    text = "Live status updates directly from your apartment supermarket",
                    fontSize = 12.sp,
                    color = SlateMuted
                )
            }
        }

        if (orders.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ReceiptLong,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("No orders placed yet", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = SlateInk)
                        Text(
                            "Your grocery orders and live delivery tracking will appear here.",
                            fontSize = 12.sp,
                            color = SlateMuted
                        )
                    }
                }
            }
        } else {
            items(orders, key = { it.id }) { order ->
                OrderTrackingCard(order = order, onReorder = { onReorder(order) })
            }
        }
    }
}

@Composable
private fun OrderTrackingCard(order: Order, onReorder: () -> Unit) {
    val steps = listOf("placed", "accepted", "packing", "out_for_delivery", "delivered")
    val stepLabels = listOf("Placed", "Accepted", "Packing", "On Way", "Delivered")
    val currentIdx = steps.indexOf(order.status).coerceAtLeast(0)
    val isCancelledOrRejected = order.status == "cancelled" || order.status == "rejected"

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Order #${order.id}",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = SlateInk
                    )
                    Text(
                        text = "${order.storeName} • ${order.itemCount} items",
                        fontSize = 12.sp,
                        color = SlateMuted
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (isCancelledOrRejected) Color(0xFFFFE4E6) else EmeraldLight
                ) {
                    Text(
                        text = order.status.replace('_', ' ').uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isCancelledOrRejected) RoseDanger else EmeraldDark,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            if (!isCancelledOrRejected) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    stepLabels.forEachIndexed { idx, label ->
                        val reached = idx <= currentIdx
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(if (reached) EmeraldPrimary else Color(0xFFE2E8F0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${idx + 1}",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (reached) Color.White else SlateMuted
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = label,
                                fontSize = 10.sp,
                                fontWeight = if (reached) FontWeight.Bold else FontWeight.Normal,
                                color = if (reached) EmeraldDark else SlateMuted
                            )
                        }
                    }
                }
            }

            if (order.deliveryOtp.isNotBlank() && order.status != "delivered" && !isCancelledOrRejected) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFECFDF5))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.LocalShipping,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share Delivery OTP", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = EmeraldDark)
                    }
                    Text(order.deliveryOtp, fontSize = 14.sp, fontWeight = FontWeight.Black, color = EmeraldDark)
                }
            }

            HorizontalDivider()

            order.items.take(3).forEach { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${item.quantity}x ${item.name}",
                        fontSize = 12.sp,
                        color = SlateInk,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "₹${item.totalPrice.toInt()}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SlateInk
                    )
                }
            }
            if (order.items.size > 3) {
                Text(
                    text = "+${order.items.size - 3} more items",
                    fontSize = 11.sp,
                    color = SlateMuted
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total Paid (${order.paymentMethod})", fontSize = 11.sp, color = SlateMuted)
                    Text("₹${order.totalAmount.toInt()}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = SlateInk)
                }
                OutlinedButton(
                    onClick = onReorder,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = EmeraldPrimary)
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Reorder", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}
