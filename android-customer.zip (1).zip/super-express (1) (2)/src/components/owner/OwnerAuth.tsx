import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Store, Phone, User, Mail, ShieldCheck, ArrowRight, Lock, CheckCircle2, Sparkles } from 'lucide-react';

interface OwnerAuthProps {
  onSuccess?: () => void;
}

export const OwnerAuth: React.FC<OwnerAuthProps> = ({ onSuccess }) => {
  const { registerOwner, loginOwner } = useApp();
  const [mode, setMode] = useState<'login' | 'register'>('register');

  // Form fields
  const [fullName, setFullName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [generatedOtp, setGeneratedOtp] = useState('4921');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSendOtp = () => {
    if (!mobileNumber.trim() || mobileNumber.trim().length < 10) {
      setErrorMsg('Please enter a valid 10-digit mobile number');
      return;
    }
    setErrorMsg('');
    const randomOtp = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(randomOtp);
    setIsOtpSent(true);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOtpSent) {
      setErrorMsg('Please click Send OTP first');
      return;
    }
    if (otpCode.trim() !== generatedOtp && otpCode.trim() !== '1234' && otpCode.trim() !== '4921') {
      setErrorMsg(`Invalid OTP! Please enter ${generatedOtp}`);
      return;
    }
    if (!fullName.trim()) {
      setErrorMsg('Please enter owner full name');
      return;
    }

    setLoading(true);
    setErrorMsg('');
    try {
      await registerOwner(fullName.trim(), mobileNumber.trim(), emailAddress.trim());
      setLoading(false);
      if (onSuccess) onSuccess();
    } catch (err) {
      console.error(err);
      setErrorMsg('Registration failed. Please try again.');
      setLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOtpSent) {
      setErrorMsg('Please click Send OTP first');
      return;
    }
    if (otpCode.trim() !== generatedOtp && otpCode.trim() !== '1234' && otpCode.trim() !== '4921') {
      setErrorMsg(`Invalid OTP! Please enter ${generatedOtp}`);
      return;
    }

    setLoading(true);
    setErrorMsg('');
    try {
      await loginOwner(mobileNumber.trim());
      setLoading(false);
      if (onSuccess) onSuccess();
    } catch (err) {
      console.error(err);
      setErrorMsg('Login failed. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header Banner */}
        <div className="bg-gradient-to-br from-emerald-950 via-emerald-900 to-slate-900 text-white p-6 sm:p-8 text-center relative overflow-hidden">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-emerald-500/20 font-black">
            <Store className="w-9 h-9" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight">
            Supermarket Partner Portal
          </h2>
          <p className="text-xs text-emerald-200 mt-1 max-w-xs mx-auto">
            Exclusive single-store grocery platform for residential apartment complexes
          </p>

          <div className="mt-4 flex bg-white/10 p-1 rounded-xl text-xs font-bold border border-white/15">
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setErrorMsg('');
                setIsOtpSent(false);
                setOtpCode('');
              }}
              className={`flex-1 py-1.5 rounded-lg transition ${
                mode === 'register'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              New Owner Register
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMsg('');
                setIsOtpSent(false);
                setOtpCode('');
              }}
              className={`flex-1 py-1.5 rounded-lg transition ${
                mode === 'login'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              Owner Mobile Login
            </button>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-6 sm:p-8 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl font-medium">
              {errorMsg}
            </div>
          )}

          {mode === 'register' ? (
            <form onSubmit={handleRegister} className="space-y-3.5 text-xs">
              <div>
                <label className="text-slate-700 font-bold block mb-1">
                  Owner Full Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Suresh Kumar"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2.5 outline-none focus:border-emerald-500 font-medium text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">
                  Mobile Number (For OTP Verification) <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 9845012345"
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2.5 outline-none focus:border-emerald-500 font-medium text-slate-800"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleSendOtp}
                    className="px-3 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl whitespace-nowrap cursor-pointer transition text-xs shadow-xs"
                  >
                    {isOtpSent ? 'Resend OTP' : 'Send OTP'}
                  </button>
                </div>
              </div>

              {isOtpSent && (
                <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 space-y-1.5 animate-in fade-in duration-150">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-emerald-950">
                      Enter 4-digit code sent to {mobileNumber}
                    </span>
                    <span className="font-mono bg-emerald-200/80 text-emerald-900 px-1.5 py-0.5 rounded font-black">
                      OTP: {generatedOtp}
                    </span>
                  </div>
                  <input
                    type="text"
                    maxLength={4}
                    placeholder="Enter 4-digit OTP"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    className="w-full bg-white border border-emerald-300 rounded-xl p-2.5 text-center font-mono font-black text-base tracking-widest text-slate-900 outline-none focus:ring-2 focus:ring-emerald-400"
                  />
                </div>
              )}

              <div>
                <label className="text-slate-700 font-bold block mb-1">
                  Email Address <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    placeholder="e.g. owner@mysupermarket.com"
                    value={emailAddress}
                    onChange={(e) => setEmailAddress(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2.5 outline-none focus:border-emerald-500 font-medium text-slate-800"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black text-sm rounded-xl shadow-lg shadow-emerald-700/25 flex items-center justify-center gap-2 cursor-pointer transition transform active:scale-98 mt-2"
              >
                <span>{loading ? 'Creating Account...' : 'Create Owner Account'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <form onSubmit={handleLogin} className="space-y-3.5 text-xs">
              <div>
                <label className="text-slate-700 font-bold block mb-1">
                  Registered Mobile Number <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 9845012345"
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2.5 outline-none focus:border-emerald-500 font-medium text-slate-800"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleSendOtp}
                    className="px-3 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl whitespace-nowrap cursor-pointer transition text-xs shadow-xs"
                  >
                    {isOtpSent ? 'Resend OTP' : 'Send OTP'}
                  </button>
                </div>
              </div>

              {isOtpSent && (
                <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 space-y-1.5 animate-in fade-in duration-150">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-emerald-950">
                      Enter 4-digit SMS OTP
                    </span>
                    <span className="font-mono bg-emerald-200/80 text-emerald-900 px-1.5 py-0.5 rounded font-black">
                      OTP: {generatedOtp}
                    </span>
                  </div>
                  <input
                    type="text"
                    maxLength={4}
                    placeholder="Enter 4-digit OTP"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    className="w-full bg-white border border-emerald-300 rounded-xl p-2.5 text-center font-mono font-black text-base tracking-widest text-slate-900 outline-none focus:ring-2 focus:ring-emerald-400"
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-slate-900 hover:bg-black disabled:opacity-50 text-white font-black text-sm rounded-xl shadow-lg flex items-center justify-center gap-2 cursor-pointer transition transform active:scale-98 mt-2"
              >
                <span>{loading ? 'Authenticating...' : 'Log In to Owner Portal'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          <div className="pt-2 text-center border-t border-slate-100">
            <p className="text-[11px] text-slate-500">
              ⚡ Monthly store owner subscription is ₹199. Admin approval required for apartment exclusivity.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
