import React from 'react';
import { Zap, ShieldCheck, Clock, ArrowRight } from 'lucide-react';

interface SplashScreenProps {
  onEnter: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onEnter }) => {
  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-br from-emerald-950 via-emerald-900 to-slate-950 text-white flex flex-col justify-between p-6 sm:p-12 animate-in fade-in duration-300">
      {/* Top Tagline */}
      <div className="flex items-center justify-between">
        <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
          Single Store Apartment Network
        </span>
        <span className="text-emerald-200 text-xs font-mono">10-15m Express</span>
      </div>

      {/* Hero Branding */}
      <div className="max-w-md mx-auto text-center space-y-6 my-auto">
        <div className="relative inline-block">
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-tr from-emerald-600 to-green-400 flex items-center justify-center text-white mx-auto shadow-2xl shadow-emerald-500/40 ring-8 ring-emerald-500/10">
            <Zap className="w-14 h-14 sm:w-16 sm:h-16 fill-white text-yellow-300 animate-pulse" />
          </div>
          <span className="absolute -bottom-2 -right-2 bg-yellow-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase shadow-md">
            10 MINS
          </span>
        </div>

        <div className="space-y-2">
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white font-display">
            SUPER<span className="text-emerald-400">EXPRESS</span>
          </h1>
          <p className="text-sm sm:text-base text-emerald-100 font-medium leading-relaxed">
            Your Apartment's Dedicated Supermarket. Handpicked fresh groceries delivered directly to your doorstep in 10-15 minutes.
          </p>
        </div>

        {/* Feature Badges */}
        <div className="grid grid-cols-3 gap-2 text-center pt-2">
          <div className="bg-white/10 backdrop-blur-xs p-3 rounded-2xl border border-white/10">
            <span className="text-lg">🏬</span>
            <div className="text-[11px] font-bold text-white mt-1">1 Store Per Society</div>
          </div>
          <div className="bg-white/10 backdrop-blur-xs p-3 rounded-2xl border border-white/10">
            <span className="text-lg">⚡</span>
            <div className="text-[11px] font-bold text-white mt-1">10-15 Min Delivery</div>
          </div>
          <div className="bg-white/10 backdrop-blur-xs p-3 rounded-2xl border border-white/10">
            <span className="text-lg">🛡️</span>
            <div className="text-[11px] font-bold text-white mt-1">Doorstep OTP</div>
          </div>
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="max-w-md w-full mx-auto space-y-3">
        <button
          onClick={onEnter}
          className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-emerald-500/30 flex items-center justify-center gap-2 transition cursor-pointer transform active:scale-98"
        >
          <span>Enter Super Express</span>
          <ArrowRight className="w-4 h-4" />
        </button>
        <p className="text-[11px] text-emerald-300 text-center font-medium">
          Serving Emerald Heights, Prestige Falcon City & Sobha Dream Acres
        </p>
      </div>
    </div>
  );
};
