package com.superexpress.customer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.superexpress.customer.data.model.Product
import com.superexpress.customer.ui.screens.AuthScreen
import com.superexpress.customer.ui.screens.CartCheckoutScreen
import com.superexpress.customer.ui.screens.CustomerSplashScreen
import com.superexpress.customer.ui.screens.HomeScreen
import com.superexpress.customer.ui.screens.OrdersScreen
import com.superexpress.customer.ui.screens.ProductDetailBottomSheet
import com.superexpress.customer.ui.screens.ProfileScreen
import com.superexpress.customer.ui.screens.SearchScreen
import com.superexpress.customer.ui.screens.SupermarketsScreen
import com.superexpress.customer.ui.theme.EmeraldDark
import com.superexpress.customer.ui.theme.EmeraldLight
import com.superexpress.customer.ui.theme.EmeraldPrimary
import com.superexpress.customer.ui.theme.SlateMuted
import com.superexpress.customer.ui.theme.SuperExpressTheme
import com.superexpress.customer.ui.viewmodel.CustomerViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: CustomerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SuperExpressTheme {
                val uiState by viewModel.uiState.collectAsState()

                when {
                    uiState.authLoading -> CustomerSplashScreen()
                    !uiState.isAuthenticated -> AuthScreen(
                        apartments = uiState.apartments,
                        authError = uiState.authError,
                        isSubmitting = uiState.authSubmitting,
                        onClearError = viewModel::clearAuthError,
                        onLogin = viewModel::loginWithEmail,
                        onRegister = viewModel::registerCustomer
                    )
                    else -> CustomerMainHost(viewModel = viewModel)
                }
            }
        }
    }
}

private enum class CustomerTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Filled.Home),
    STORES("Stores", Icons.Filled.Storefront),
    SEARCH("Search", Icons.Filled.Search),
    ORDERS("Orders", Icons.AutoMirrored.Filled.ReceiptLong),
    PROFILE("Profile", Icons.Filled.Person)
}

@Composable
private fun CustomerMainHost(viewModel: CustomerViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    var activeTab by remember { mutableStateOf(CustomerTab.HOME) }
    var isCartOpen by remember { mutableStateOf(false) }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }

    if (isCartOpen) {
        CartCheckoutScreen(
            uiState = uiState,
            onBack = { isCartOpen = false },
            onUpdateQuantity = viewModel::updateCartQuantity,
            onClearCart = viewModel::clearCart,
            onPlaceOrder = viewModel::placeOrder,
            onConfirmOnlinePayment = viewModel::confirmOnlinePayment,
            onDismissOnlinePayment = viewModel::dismissPendingOnlinePayment,
            onDismissConfirmedOrder = {
                viewModel.dismissConfirmedOrder()
                isCartOpen = false
                activeTab = CustomerTab.ORDERS
            }
        )
        return
    }

    Scaffold(
        bottomBar = {
            Column {
                if (uiState.cartCount > 0 && activeTab != CustomerTab.ORDERS) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { isCartOpen = true },
                        color = EmeraldPrimary,
                        shadowElevation = 6.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                BadgedBox(
                                    badge = {
                                        Badge(containerColor = Color(0xFFFBBF24), contentColor = EmeraldDark) {
                                            Text(uiState.cartCount.toString(), fontWeight = FontWeight.Black)
                                        }
                                    }
                                ) {
                                    Icon(Icons.Filled.ShoppingBag, contentDescription = null, tint = Color.White)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "${uiState.cartCount} ${if (uiState.cartCount == 1) "item" else "items"}",
                                        color = EmeraldLight,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = "₹${uiState.cartSubtotal.toInt()}",
                                        color = Color.White,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 15.sp
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("View Cart", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = EmeraldDark)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = EmeraldDark, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }

                NavigationBar(containerColor = Color.White, tonalElevation = 4.dp) {
                    CustomerTab.entries.forEach { tab ->
                        val selected = activeTab == tab
                        NavigationBarItem(
                            selected = selected,
                            onClick = { activeTab = tab },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = {
                                Text(
                                    text = tab.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = EmeraldPrimary,
                                selectedTextColor = EmeraldPrimary,
                                indicatorColor = EmeraldLight.copy(alpha = 0.6f),
                                unselectedIconColor = SlateMuted,
                                unselectedTextColor = SlateMuted
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(innerPadding)
        ) {
            when (activeTab) {
                CustomerTab.HOME -> HomeScreen(
                    profile = uiState.profile,
                    activeApartment = uiState.activeApartment,
                    activeStore = uiState.activeStore,
                    categories = uiState.categories,
                    selectedCategoryId = uiState.selectedCategoryId,
                    products = uiState.filteredProducts,
                    quantityProvider = viewModel::quantityInCart,
                    onOpenSupermarkets = { activeTab = CustomerTab.STORES },
                    onOpenSearch = { activeTab = CustomerTab.SEARCH },
                    onSelectCategory = viewModel::selectCategory,
                    onProductClick = { selectedProduct = it },
                    onAddToCart = viewModel::addToCart,
                    onUpdateQuantity = viewModel::updateCartQuantity
                )

                CustomerTab.STORES -> SupermarketsScreen(
                    apartments = uiState.apartments,
                    stores = uiState.stores,
                    selectedApartmentId = uiState.selectedApartmentId,
                    onSelectApartment = { aptId ->
                        viewModel.selectApartment(aptId)
                        activeTab = CustomerTab.HOME
                    }
                )

                CustomerTab.SEARCH -> SearchScreen(
                    storeName = uiState.activeStore?.name ?: "supermarket",
                    searchQuery = uiState.searchQuery,
                    selectedCategoryId = uiState.selectedCategoryId,
                    categories = uiState.categories,
                    products = uiState.filteredProducts,
                    quantityProvider = viewModel::quantityInCart,
                    onQueryChange = viewModel::updateSearchQuery,
                    onSelectCategory = viewModel::selectCategory,
                    onProductClick = { selectedProduct = it },
                    onAddToCart = viewModel::addToCart,
                    onUpdateQuantity = viewModel::updateCartQuantity
                )

                CustomerTab.ORDERS -> OrdersScreen(
                    orders = uiState.orders,
                    onReorder = { order ->
                        viewModel.reorder(order)
                        isCartOpen = true
                    }
                )

                CustomerTab.PROFILE -> ProfileScreen(
                    profile = uiState.profile,
                    apartments = uiState.apartments,
                    totalOrdersCount = uiState.orders.size,
                    isSaving = uiState.isSavingProfile,
                    statusMessage = uiState.profileMessage,
                    onSaveProfile = viewModel::saveProfile,
                    onClearStatus = viewModel::clearProfileMessage,
                    onSignOut = viewModel::signOut
                )
            }
        }
    }

    val detailProduct = selectedProduct
    if (detailProduct != null) {
        ProductDetailBottomSheet(
            product = detailProduct,
            storeName = uiState.activeStore?.name ?: "Super Express",
            quantity = viewModel.quantityInCart(detailProduct.id),
            onDismiss = { selectedProduct = null },
            onAdd = { viewModel.addToCart(detailProduct) },
            onUpdateQty = { qty -> viewModel.updateCartQuantity(detailProduct.id, qty) },
            onGoToCart = { isCartOpen = true }
        )
    }
}
