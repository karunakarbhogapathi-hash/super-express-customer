import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  ShoppingBag,
  Plus,
  Minus,
  Trash2,
  MapPin,
  CreditCard,
  Banknote,
  ShieldCheck,
  ArrowRight,
  CheckCircle2,
  Lock,
  Sparkles,
  QrCode,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Order, PaymentMethod } from '../../types';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderPlaced: (order: Order) => void;
}

export const CartModal: React.FC<CartModalProps> = ({ isOpen, onClose, onOrderPlaced }) => {
  const {
    cart,
    cartTotal,
    cartCount,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    activeApartment,
    activeStore,
    currentUser,
    createOrder,
    verifyOnlinePayment,
  } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('ONLINE');
  const [flatNumber, setFlatNumber] = useState(currentUser.flatNumber || '402');
  const [block, setBlock] = useState(currentUser.block || 'Tower B');
  const [deliveryNotes, setDeliveryNotes] = useState('');
  const [isPlacing, setIsPlacing] = useState(false);
  const [showPaymentGateway, setShowPaymentGateway] = useState(false);
  const [pendingOrderId, setPendingOrderId] = useState<string | null>(null);
  const [onlinePaySubMethod, setOnlinePaySubMethod] = useState<'UPI' | 'CARD' | 'NETBANKING'>('UPI');
  const [isVerifyingPayment, setIsVerifyingPayment] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setCheckoutError(null);
      if (currentUser.flatNumber) setFlatNumber(currentUser.flatNumber);
      if (currentUser.block) setBlock(currentUser.block);
    }
  }, [isOpen, currentUser.flatNumber, currentUser.block]);

  if (!isOpen) return null;

  const deliveryFee = cartTotal >= 199 ? 0 : 25;
  const handlingFee = 5;
  const grandTotal = cartTotal + deliveryFee + handlingFee;

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setCheckoutError(null);
    setIsPlacing(true);

    try {
      const order = await createOrder({
        paymentMethod,
        deliveryAddress: `${block}, Flat ${flatNumber}, ${activeApartment?.name}`,
        flatNumber,
        block,
        notes: deliveryNotes,
      });

      if (paymentMethod === 'ONLINE') {
        setPendingOrderId(order.id);
        setShowPaymentGateway(true);
        setIsPlacing(false);
      } else {
        // COD order placed directly
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
        setIsPlacing(false);
        onClose();
        onOrderPlaced(order);
      }
    } catch (err) {
      console.error(err);
      setCheckoutError('Could not place order. Please check your connection and try again.');
      setIsPlacing(false);
    }
  };

  const handleOnlinePaymentConfirm = async () => {
    if (!pendingOrderId) return;
    setIsVerifyingPayment(true);

    // Simulate real gateway handshake & signature verification
    setTimeout(async () => {
      await verifyOnlinePayment(pendingOrderId, onlinePaySubMethod);
      setIsVerifyingPayment(false);
      setShowPaymentGateway(false);

      confetti({
        particleCount: 120,
        spread: 90,
        origin: { y: 0.5 },
      });

      onClose();
      // Look up finalized order
      const placedOrder = {
        id: pendingOrderId,
      } as Order;
      onOrderPlaced(placedOrder);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex justify-end">
      <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="font-bold text-base">Your Grocery Basket</h2>
              <p className="text-xs text-slate-300">
                From {activeStore?.name || 'Assigned Supermarket'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
            <div className="w-20 h-20 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4">
              <ShoppingBag className="w-10 h-10" />
            </div>
            <h3 className="font-bold text-lg text-slate-800">Your basket is empty</h3>
            <p className="text-sm text-slate-500 mt-1 max-w-xs">
              Add fresh vegetables, milk, bread, and essentials from your apartment supermarket!
            </p>
            <button
              onClick={onClose}
              className="mt-6 px-6 py-2.5 bg-emerald-600 text-white font-bold text-sm rounded-xl hover:bg-emerald-700 transition"
            >
              Start Shopping
            </button>
          </div>
        ) : (
          <>
            {/* Delivery address info */}
            <div className="bg-emerald-50/70 p-3 border-b border-emerald-100 px-4">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-emerald-700 mt-0.5 shrink-0" />
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-950">
                      Delivering to {activeApartment?.name}
                    </span>
                    <span className="text-[10px] bg-emerald-200/60 text-emerald-900 px-1.5 py-0.5 rounded font-bold">
                      ⚡ 10-15m
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <div>
                      <label className="text-[10px] text-slate-500 font-medium block">
                        Tower / Block
                      </label>
                      <input
                        type="text"
                        value={block}
                        onChange={(e) => setBlock(e.target.value)}
                        placeholder="e.g. Tower B"
                        className="w-full bg-white text-xs px-2.5 py-1.5 rounded-lg border border-emerald-200 outline-none focus:ring-1 focus:ring-emerald-500 font-semibold text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-500 font-medium block">
                        Flat / Door No
                      </label>
                      <input
                        type="text"
                        value={flatNumber}
                        onChange={(e) => setFlatNumber(e.target.value)}
                        placeholder="e.g. 402"
                        className="w-full bg-white text-xs px-2.5 py-1.5 rounded-lg border border-emerald-200 outline-none focus:ring-1 focus:ring-emerald-500 font-semibold text-slate-800"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500 pb-1">
                <span>{cartCount} Items selected</span>
                <button
                  onClick={clearCart}
                  className="text-red-500 hover:text-red-700 font-semibold flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Clear All
                </button>
              </div>

              {cart.map((item) => (
                <div
                  key={item.product.id}
                  className="flex items-center gap-3 p-2.5 bg-slate-50 rounded-xl border border-slate-100"
                >
                  <img
                    src={item.product.imageUrl}
                    alt={item.product.name}
                    className="w-14 h-14 rounded-lg object-cover bg-white shrink-0 border border-slate-100"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 truncate">
                      {item.product.name}
                    </h4>
                    <p className="text-[11px] text-slate-500">{item.product.unit}</p>
                    <div className="flex items-baseline gap-1.5 mt-1">
                      <span className="text-xs font-bold text-slate-900">
                        ₹{item.product.price}
                      </span>
                      {item.product.mrp > item.product.price && (
                        <span className="text-[10px] text-slate-400 line-through">
                          ₹{item.product.mrp}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Quantity Stepper */}
                  <div className="flex items-center gap-1.5 bg-white border border-emerald-300 rounded-lg px-1.5 py-1 shadow-2xs">
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                      className="w-5 h-5 rounded flex items-center justify-center text-emerald-800 hover:bg-emerald-50 font-bold"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-xs font-extrabold text-emerald-950 px-1 min-w-[16px] text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                      className="w-5 h-5 rounded flex items-center justify-center text-emerald-800 hover:bg-emerald-50 font-bold"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}

              {/* Delivery Instruction input */}
              <div className="pt-2">
                <input
                  type="text"
                  placeholder="Delivery note: (e.g. Ring doorbell, leave at door)"
                  value={deliveryNotes}
                  onChange={(e) => setDeliveryNotes(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none focus:border-emerald-500"
                />
              </div>

              {/* Bill Details */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2 text-xs">
                <h4 className="font-bold text-slate-900 text-xs">Bill Details</h4>
                <div className="flex justify-between text-slate-600">
                  <span>Item Total</span>
                  <span className="font-semibold text-slate-800">₹{cartTotal}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Delivery Partner Fee</span>
                  {deliveryFee === 0 ? (
                    <span className="text-emerald-700 font-bold">FREE (Orders above ₹199)</span>
                  ) : (
                    <span className="font-semibold text-slate-800">₹{deliveryFee}</span>
                  )}
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Apartment Handling & Packaging</span>
                  <span className="font-semibold text-slate-800">₹{handlingFee}</span>
                </div>
                <div className="border-t border-slate-200 pt-2 flex justify-between font-extrabold text-sm text-slate-900">
                  <span>To Pay</span>
                  <span className="text-emerald-700">₹{grandTotal}</span>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div className="space-y-2 pt-1">
                <label className="text-xs font-bold text-slate-800 block">
                  Select Payment Method
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('ONLINE')}
                    className={`p-3 rounded-xl border text-left transition flex items-center gap-2 cursor-pointer ${
                      paymentMethod === 'ONLINE'
                        ? 'border-emerald-600 bg-emerald-50/80 text-emerald-950 ring-1 ring-emerald-500'
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <div className="text-xs font-bold">Pay Online</div>
                      <div className="text-[10px] text-slate-500">UPI, Cards, NetBanking</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('COD')}
                    className={`p-3 rounded-xl border text-left transition flex items-center gap-2 cursor-pointer ${
                      paymentMethod === 'COD'
                        ? 'border-emerald-600 bg-emerald-50/80 text-emerald-950 ring-1 ring-emerald-500'
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <Banknote className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <div className="text-xs font-bold">Cash on Delivery</div>
                      <div className="text-[10px] text-slate-500">Pay at your doorstep</div>
                    </div>
                  </button>
                </div>
              </div>
            </div>

            {/* Bottom Sticky Checkout Action */}
            <div className="p-4 border-t border-slate-100 bg-white">
              {checkoutError && (
                <div className="mb-2.5 px-3 py-2 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 font-semibold">
                  {checkoutError}
                </div>
              )}
              <button
                disabled={isPlacing}
                onClick={handleCheckout}
                className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white py-3.5 px-4 rounded-xl font-bold text-sm shadow-lg shadow-emerald-700/25 flex items-center justify-between cursor-pointer transition transform active:scale-98"
              >
                <div className="text-left">
                  <div className="text-xs opacity-90">{cartCount} Items • ₹{grandTotal}</div>
                  <div className="text-sm font-extrabold">
                    {paymentMethod === 'ONLINE' ? 'Proceed to Online Payment' : 'Place Cash on Delivery Order'}
                  </div>
                </div>
                <div className="flex items-center gap-1 font-bold">
                  <span>{isPlacing ? 'Processing...' : 'Place Order'}</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </button>
              <p className="text-[11px] text-slate-400 text-center mt-2 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Secure 256-bit encrypted checkout for {activeApartment?.name}
              </p>
            </div>
          </>
        )}
      </div>

      {/* Online Payment Gateway Simulation Modal */}
      {showPaymentGateway && (
        <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-100 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Super Express Pay</h3>
                  <p className="text-[11px] text-slate-500">Secure Payment Gateway</p>
                </div>
              </div>
              <span className="font-extrabold text-base text-emerald-800">
                ₹{grandTotal}
              </span>
            </div>

            {/* Sub-method tabs */}
            <div className="flex border-b border-slate-100 my-3 text-xs">
              <button
                onClick={() => setOnlinePaySubMethod('UPI')}
                className={`flex-1 py-2 font-bold border-b-2 ${
                  onlinePaySubMethod === 'UPI'
                    ? 'border-emerald-600 text-emerald-700'
                    : 'border-transparent text-slate-400'
                }`}
              >
                UPI (GPay/PhonePe)
              </button>
              <button
                onClick={() => setOnlinePaySubMethod('CARD')}
                className={`flex-1 py-2 font-bold border-b-2 ${
                  onlinePaySubMethod === 'CARD'
                    ? 'border-emerald-600 text-emerald-700'
                    : 'border-transparent text-slate-400'
                }`}
              >
                Debit/Credit Card
              </button>
              <button
                onClick={() => setOnlinePaySubMethod('NETBANKING')}
                className={`flex-1 py-2 font-bold border-b-2 ${
                  onlinePaySubMethod === 'NETBANKING'
                    ? 'border-emerald-600 text-emerald-700'
                    : 'border-transparent text-slate-400'
                }`}
              >
                NetBanking
              </button>
            </div>

            {onlinePaySubMethod === 'UPI' && (
              <div className="space-y-3 py-2 text-center">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 inline-block">
                  <QrCode className="w-32 h-32 mx-auto text-slate-800" />
                  <p className="text-[10px] text-slate-500 mt-1 font-mono">
                    Scan with any UPI App
                  </p>
                </div>
                <div className="text-xs text-slate-600 font-medium">
                  UPI ID: <span className="font-bold text-slate-900">superexpress.pay@icici</span>
                </div>
              </div>
            )}

            {onlinePaySubMethod === 'CARD' && (
              <div className="space-y-2.5 py-2 text-xs">
                <div>
                  <label className="text-[11px] text-slate-500 block mb-0.5">Card Number</label>
                  <input
                    type="text"
                    defaultValue="4532 •••• •••• 8912"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono text-xs"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] text-slate-500 block mb-0.5">Expiry</label>
                    <input
                      type="text"
                      defaultValue="08/29"
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-500 block mb-0.5">CVV</label>
                    <input
                      type="password"
                      defaultValue="•••"
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs"
                    />
                  </div>
                </div>
              </div>
            )}

            {onlinePaySubMethod === 'NETBANKING' && (
              <div className="py-2 text-xs space-y-2">
                <p className="text-slate-500 text-[11px]">Select your bank account:</p>
                <div className="grid grid-cols-2 gap-2">
                  {['HDFC Bank', 'ICICI Bank', 'SBI', 'Axis Bank'].map((b) => (
                    <div
                      key={b}
                      className="p-2 border border-slate-200 rounded-lg text-center font-semibold text-slate-700 bg-slate-50 text-[11px]"
                    >
                      {b}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-4 pt-3 border-t border-slate-100 flex gap-2">
              <button
                onClick={() => setShowPaymentGateway(false)}
                className="flex-1 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                disabled={isVerifyingPayment}
                onClick={handleOnlinePaymentConfirm}
                className="flex-2 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {isVerifyingPayment ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>Verifying with Bank...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Pay ₹{grandTotal} Now</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
