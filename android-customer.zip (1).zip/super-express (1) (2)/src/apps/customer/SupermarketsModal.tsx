import React from 'react';
import { X, Store, MapPin, Clock, Star, CheckCircle2, Building2 } from 'lucide-react';
import { Apartment, Store as StoreType } from '../../types';

interface SupermarketsModalProps {
  isOpen: boolean;
  onClose: () => void;
  apartments: Apartment[];
  stores: StoreType[];
  activeApartmentId?: string;
  onSelectApartment: (apartmentId: string) => void;
}

export const SupermarketsModal: React.FC<SupermarketsModalProps> = ({
  isOpen,
  onClose,
  apartments,
  stores,
  activeApartmentId,
  onSelectApartment,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden max-h-[85vh] flex flex-col">
        <div className="p-4 bg-emerald-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Store className="w-5 h-5 text-emerald-300" />
            <div>
              <h3 className="font-black text-sm">Partner Supermarkets & Societies</h3>
              <p className="text-[11px] text-emerald-200">
                Select your apartment society to shop from its assigned supermarket
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-3 overflow-y-auto">
          {apartments.map((apt) => {
            const assignedStore = stores.find(
              (s) => s.apartmentId === apt.id && s.status === 'active'
            );
            const isSelected = apt.id === activeApartmentId;

            return (
              <button
                type="button"
                key={apt.id}
                onClick={() => {
                  onSelectApartment(apt.id);
                  onClose();
                }}
                className={`w-full text-left p-4 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50/70 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 hover:border-emerald-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <Building2 className="w-4 h-4 text-emerald-700 shrink-0" />
                      <h4 className="font-black text-sm text-slate-900 truncate">{apt.name}</h4>
                    </div>
                    <p className="text-xs text-slate-500 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{apt.address}, {apt.city}</span>
                    </p>
                  </div>
                  {isSelected && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-black bg-emerald-600 text-white px-2 py-0.5 rounded-full shrink-0">
                      <CheckCircle2 className="w-3 h-3" /> Active
                    </span>
                  )}
                </div>

                {assignedStore ? (
                  <div className="mt-3 pt-2.5 border-t border-slate-200/70 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2">
                      {assignedStore.logoUrl && (
                        <img
                          src={assignedStore.logoUrl}
                          alt={assignedStore.name}
                          className="w-7 h-7 rounded-lg object-cover border border-slate-200"
                        />
                      )}
                      <div>
                        <div className="font-bold text-emerald-950">{assignedStore.name}</div>
                        <div className="text-[10px] text-slate-500">
                          Open {assignedStore.openingTime} – {assignedStore.closingTime} • Min ₹{assignedStore.minOrderAmount}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] font-bold">
                      <span className="flex items-center gap-0.5 text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                        <Star className="w-3 h-3 fill-amber-500" /> {assignedStore.rating}
                      </span>
                      <span className="flex items-center gap-0.5 text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-md">
                        <Clock className="w-3 h-3" /> {assignedStore.deliveryTimeMinutes}m
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="mt-3 pt-2 border-t border-slate-200/70 text-[11px] font-semibold text-amber-700">
                    No active supermarket assigned yet
                  </div>
                )}
              </button>
            );
          })}
        </div>

        <div className="p-3 bg-slate-50 border-t border-slate-100 text-center text-[11px] text-slate-500">
          Each residential society is served exclusively by its assigned Super Express supermarket.
        </div>
      </div>
    </div>
  );
};
