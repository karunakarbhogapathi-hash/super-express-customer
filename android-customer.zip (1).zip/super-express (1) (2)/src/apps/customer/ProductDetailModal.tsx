import React from 'react';
import { X, Plus, Minus, ShoppingBag, Zap, ShieldCheck, Tag } from 'lucide-react';
import { Product } from '../../types';

interface ProductDetailModalProps {
  product: Product | null;
  categoryName?: string;
  storeName?: string;
  quantityInCart: number;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
  onUpdateQuantity: (productId: string, qty: number) => void;
  onOpenCart: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  categoryName,
  storeName,
  quantityInCart,
  onClose,
  onAddToCart,
  onUpdateQuantity,
  onOpenCart,
}) => {
  if (!product) return null;

  const discountPct =
    product.mrp > product.price
      ? Math.round(((product.mrp - product.price) / product.mrp) * 100)
      : 0;
  const savings = Math.max(0, product.mrp - product.price);
  const outOfStock = !product.inStock || product.stockCount <= 0;

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl border border-slate-200 max-h-[92vh] flex flex-col animate-in slide-in-from-bottom-4 duration-150">
        {/* Image Banner */}
        <div className="relative bg-slate-100 aspect-[4/3] w-full overflow-hidden shrink-0">
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover"
          />
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-slate-900 flex items-center justify-center shadow-md cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {discountPct > 0 && (
            <span className="absolute top-3 left-3 bg-emerald-600 text-white text-xs font-black px-2.5 py-1 rounded-lg shadow">
              {discountPct}% OFF
            </span>
          )}

          <span className="absolute bottom-3 left-3 bg-slate-950/80 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
            10–15 Min Society Delivery
          </span>
        </div>

        {/* Details Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            {product.brand && (
              <span className="bg-slate-100 text-slate-700 text-[11px] font-bold px-2.5 py-0.5 rounded-full border border-slate-200">
                {product.brand}
              </span>
            )}
            {categoryName && (
              <span className="bg-emerald-50 text-emerald-800 text-[11px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                <Tag className="w-3 h-3" />
                {categoryName}
              </span>
            )}
            <span
              className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                outOfStock
                  ? 'bg-rose-100 text-rose-800'
                  : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {outOfStock ? 'Out of Stock' : `In Stock (${product.stockCount} left)`}
            </span>
          </div>

          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 leading-snug">
              {product.name}
            </h2>
            <p className="text-xs font-semibold text-slate-500 mt-1">
              Pack Size / Weight: <span className="text-slate-800">{product.unit}</span>
            </p>
          </div>

          <div className="flex items-baseline gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
            <span className="text-2xl font-black text-emerald-800">₹{product.price}</span>
            {product.mrp > product.price && (
              <>
                <span className="text-sm text-slate-400 line-through font-semibold">
                  MRP ₹{product.mrp}
                </span>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                  Save ₹{savings}
                </span>
              </>
            )}
          </div>

          <div className="space-y-1.5">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Product Details
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              {product.description || `Fresh grocery item supplied by ${storeName || 'your assigned apartment supermarket'}.`}
            </p>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-500 bg-emerald-50/70 border border-emerald-100 p-3 rounded-xl">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              Sold & delivered directly by <strong className="text-slate-800">{storeName || 'Assigned Supermarket'}</strong>
            </span>
          </div>
        </div>

        {/* Bottom Action Bar */}
        <div className="p-4 border-t border-slate-100 bg-white flex items-center gap-3">
          {outOfStock ? (
            <button
              type="button"
              disabled
              className="flex-1 py-3 bg-slate-200 text-slate-500 font-bold text-sm rounded-xl cursor-not-allowed"
            >
              Currently Out of Stock
            </button>
          ) : quantityInCart === 0 ? (
            <button
              type="button"
              onClick={() => onAddToCart(product)}
              className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm rounded-xl shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-2 cursor-pointer transition"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Add to Cart • ₹{product.price}</span>
            </button>
          ) : (
            <>
              <div className="flex items-center gap-3 bg-emerald-600 text-white rounded-xl px-3 py-2 shadow-sm">
                <button
                  type="button"
                  onClick={() => onUpdateQuantity(product.id, quantityInCart - 1)}
                  className="w-7 h-7 flex items-center justify-center hover:bg-emerald-700 rounded-lg cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="text-sm font-black min-w-[20px] text-center">
                  {quantityInCart}
                </span>
                <button
                  type="button"
                  onClick={() => onUpdateQuantity(product.id, quantityInCart + 1)}
                  className="w-7 h-7 flex items-center justify-center hover:bg-emerald-700 rounded-lg cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenCart();
                }}
                className="flex-1 py-3 bg-slate-900 hover:bg-black text-white font-black text-sm rounded-xl cursor-pointer transition"
              >
                Go to Cart
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
