import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Store,
  Building2,
  Package,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  XCircle,
  Clock,
  TrendingUp,
  CreditCard,
  AlertTriangle,
  Search,
  Bike,
  Sparkles,
  LogOut,
  Power,
  UserCheck,
  ShieldAlert,
  ArrowRight,
  Phone,
  User,
  Mail,
  ShoppingBag,
  LayoutDashboard,
  Boxes,
  FileText,
  Menu,
  X,
  MapPin,
  RefreshCw,
  PlusCircle,
  Award,
  Bell,
  Volume2,
  VolumeX,
  Camera,
  Loader2,
  ScanBarcode,
} from 'lucide-react';
import { Product, OrderStatus, Order } from '../../types';
import { OwnerAuth } from './OwnerAuth';
import { CreateSupermarketModal } from './CreateSupermarketModal';
import { ProductImageUploader } from './ProductImageUploader';
import { NewOrderAlertModal } from './NewOrderAlertModal';
import { PosBillingPanel } from './PosBillingPanel';
import { CameraBarcodeScanner } from './CameraBarcodeScanner';
import {
  lookupProductByBarcode,
  normalizeBarcode,
  isValidBarcode,
} from '../../services/openFoodFacts';
import {
  startOrderAlarmSound,
  stopOrderAlarmSound,
  playTestNotificationBeep,
  unlockAudioContext,
  isAudioReady,
  requestBrowserNotificationPermission,
  triggerSystemNotification,
  isAlarmPlaying,
} from '../../utils/soundNotification';

export type OwnerMenuTab =
  | 'dashboard'
  | 'create_supermarket'
  | 'my_supermarket'
  | 'add_products'
  | 'manage_products'
  | 'manage_orders'
  | 'pos_billing'
  | 'sales_reports'
  | 'subscription'
  | 'my_profile';

export const StoreOwnerPanel: React.FC = () => {
  const {
    ownerUser,
    ownerStore,
    logoutOwner,
    products,
    orders,
    subscriptions,
    apartments,
    stores,
    addProduct,
    updateProduct,
    deleteProduct,
    toggleProductStock,
    checkBarcodeDuplicate,
    updateOrderStatus,
    paySubscription,
    addDeliveryBoy,
    toggleDeliveryBoy,
    toggleStoreAvailability,
  } = useApp();

  const [activeTab, setActiveTab] = useState<OwnerMenuTab>(() => {
    if (!ownerStore) return 'dashboard';
    if (ownerStore.status === 'pending_approval') return 'my_supermarket';
    return 'dashboard';
  });

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCreateStoreModalOpen, setIsCreateStoreModalOpen] = useState(false);
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isPayingSub, setIsPayingSub] = useState(false);
  const [productSearch, setProductSearch] = useState('');
  const [orderFilter, setOrderFilter] = useState<'all' | 'placed' | 'accepted' | 'packing' | 'out_for_delivery' | 'delivered'>('all');

  // Order Notification & Audio Alert States
  const [acknowledgedOrderIds, setAcknowledgedOrderIds] = useState<string[]>([]);
  const [isSoundMuted, setIsSoundMuted] = useState(false);
  const [testOrderModalOpen, setTestOrderModalOpen] = useState(false);
  const [audioUnlocked, setAudioUnlocked] = useState(false);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>(() => {
    return typeof window !== 'undefined' && 'Notification' in window
      ? Notification.permission
      : 'default';
  });

  // Delivery boy modal state
  const [isAddBoyOpen, setIsAddBoyOpen] = useState(false);
  const [boyName, setBoyName] = useState('');
  const [boyPhone, setBoyPhone] = useState('');

  // Product form state (used for Add Products tab & modal)
  const [formName, setFormName] = useState('');
  const [formBrand, setFormBrand] = useState('');
  const [formCategory, setFormCategory] = useState('cat-vegetables');
  const [formPrice, setFormPrice] = useState(40);
  const [formMrp, setFormMrp] = useState(50);
  const [formUnit, setFormUnit] = useState('1 kg');
  const [formStock, setFormStock] = useState(50);
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formImagePublicId, setFormImagePublicId] = useState('');
  const [formBarcode, setFormBarcode] = useState('');
  const [formBarcodeAliases, setFormBarcodeAliases] = useState('');
  const [productFormError, setProductFormError] = useState('');
  const [isBarcodeScannerOpen, setIsBarcodeScannerOpen] = useState(false);
  const [isProductImageUploading, setIsProductImageUploading] = useState(false);
  const [isSavingProduct, setIsSavingProduct] = useState(false);
  const [addProductSuccess, setAddProductSuccess] = useState(false);
  const [isLookingUpBarcode, setIsLookingUpBarcode] = useState(false);
  const [barcodeLookupStatus, setBarcodeLookupStatus] = useState<{
    type: 'idle' | 'loading' | 'found' | 'not_found' | 'error';
    message?: string;
    barcode?: string;
  }>({ type: 'idle' });
  const touchedFieldsRef = useRef({
    name: false,
    brand: false,
    category: false,
    unit: false,
    imageUrl: false,
  });
  const lastLookedUpBarcodeRef = useRef<string>('');

  // Profile edit state
  const [profileName, setProfileName] = useState(ownerUser?.name || '');
  const [profileEmail, setProfileEmail] = useState(ownerUser?.email || '');
  const [profileSaved, setProfileSaved] = useState(false);

  // 1. If not logged in as store owner, show Owner Registration / Login page
  if (!ownerUser) {
    return <OwnerAuth />;
  }

  // Active store helpers
  const store = ownerStore;
  const storeProducts = store ? products.filter((p) => p.storeId === store.id) : [];
  const storeOrders = store ? orders.filter((o) => o.storeId === store.id) : [];

  const filteredProducts = storeProducts.filter((p) => {
    const q = productSearch.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      (p.barcode && p.barcode.toLowerCase().includes(q)) ||
      (p.barcodeAliases && p.barcodeAliases.some((a) => a.toLowerCase().includes(q)))
    );
  });

  const pendingOrders = storeOrders.filter((o) => o.status === 'placed');
  const preparingOrders = storeOrders.filter((o) => ['accepted', 'packing'].includes(o.status));
  const completedOrders = storeOrders.filter((o) => o.status === 'delivered');

  const filteredOrders = storeOrders.filter((o) => {
    if (orderFilter === 'all') return true;
    return o.status === orderFilter;
  });

  // Unhandled placed orders triggering live audio alarm and popup modal
  const unhandledPlacedOrders = storeOrders.filter(
    (o) => o.status === 'placed' && !acknowledgedOrderIds.includes(o.id)
  );

  // Monitor unhandled placed orders in real time: plays continuous loud beep until accepted or acknowledged
  useEffect(() => {
    if (unhandledPlacedOrders.length > 0) {
      if (!isSoundMuted) {
        startOrderAlarmSound();
      }
      const latest = unhandledPlacedOrders[0];
      triggerSystemNotification(
        '🔔 NEW ORDER RECEIVED!',
        `${latest.customerName} placed order #${latest.id} (₹${latest.totalAmount}) for ${latest.deliveryAddress}`,
        latest.id
      );
    } else {
      stopOrderAlarmSound();
    }

    return () => {
      stopOrderAlarmSound();
    };
  }, [unhandledPlacedOrders.length, isSoundMuted]);

  // Order acceptance/rejection from alert modal - immediately stops alarm
  const handleAcceptOrder = async (orderId: string) => {
    await updateOrderStatus(orderId, 'accepted');
    setAcknowledgedOrderIds((prev) => [...prev, orderId]);
    stopOrderAlarmSound();
  };

  const handleRejectOrder = async (orderId: string) => {
    await updateOrderStatus(orderId, 'cancelled');
    setAcknowledgedOrderIds((prev) => [...prev, orderId]);
    stopOrderAlarmSound();
  };

  const handleAcknowledgeAlert = (orderId: string) => {
    setAcknowledgedOrderIds((prev) => [...prev, orderId]);
    stopOrderAlarmSound();
  };

  // Mock test order for sound and notification testing
  const demoTestOrder: Order = {
    id: 'ord-test-9901',
    customerId: 'cust-demo-test',
    customerName: 'Priya Verma (Resident)',
    customerPhone: '+91 98765 43210',
    apartmentId: store?.apartmentId || 'apt-emerald-heights',
    apartmentName: store?.apartmentName || 'Emerald Heights',
    deliveryAddress: `Tower C, Flat 704, ${store?.apartmentName || 'Emerald Heights'}`,
    storeId: store?.id || 'demo-store',
    storeName: store?.name || 'Super Express Store',
    status: 'placed',
    paymentMethod: 'COD',
    paymentStatus: 'pending',
    subtotal: 105,
    deliveryFee: 0,
    handlingFee: 5,
    totalAmount: 110,
    itemCount: 3,
    deliveryOtp: '8392',
    items: [
      {
        id: 'test-item-1',
        orderId: 'test-ord',
        productId: 'test-p1',
        name: 'Amul Taaza Homogenised Toned Milk',
        imageUrl: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=300&q=80',
        unit: '500 ml pouch',
        unitPrice: 27,
        mrp: 28,
        quantity: 2,
        totalPrice: 54,
      },
      {
        id: 'test-item-2',
        orderId: 'test-ord',
        productId: 'test-p2',
        name: 'Fresh Farm Spinach (Palak)',
        imageUrl: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=300&q=80',
        unit: '250 g bunch',
        unitPrice: 26,
        mrp: 35,
        quantity: 1,
        totalPrice: 26,
      },
      {
        id: 'test-item-3',
        orderId: 'test-ord',
        productId: 'test-p3',
        name: 'Harvest Gold 100% Atta Whole Wheat Bread',
        imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=300&q=80',
        unit: '400 g pack',
        unitPrice: 30,
        mrp: 35,
        quantity: 1,
        totalPrice: 30,
      },
    ],
    createdAt: new Date().toISOString(),
  };

  const handleTriggerTestNotification = async () => {
    await unlockAudioContext();
    setAudioUnlocked(true);
    if (!isSoundMuted) {
      startOrderAlarmSound();
    }
    triggerSystemNotification(
      '🔔 [TEST] NEW ORDER RECEIVED!',
      'Priya Verma placed an order of ₹110 for Tower C, Flat 704',
      'test-order-alert'
    );
    setTestOrderModalOpen(true);
  };

  const handleRequestPushPermission = async () => {
    const perm = await requestBrowserNotificationPermission();
    setNotifPermission(perm);
    if (perm === 'granted') {
      triggerSystemNotification(
        '🔔 Live Notifications Active!',
        'You will receive immediate alerts whenever a customer places an order.'
      );
    }
  };

  const totalSales = completedOrders.reduce((sum, o) => sum + o.totalAmount, 0);
  const todayOrders = storeOrders.filter(
    (o) => new Date(o.createdAt).toDateString() === new Date().toDateString()
  );
  const todaySales = todayOrders
    .filter((o) => o.status === 'delivered' || o.paymentStatus === 'paid')
    .reduce((sum, o) => sum + o.totalAmount, 0);

  const deliveryBoys = store?.deliveryBoys || [];

  const resetProductFormTouchedState = (initial?: Partial<typeof touchedFieldsRef.current>) => {
    touchedFieldsRef.current = {
      name: Boolean(initial?.name),
      brand: Boolean(initial?.brand),
      category: Boolean(initial?.category),
      unit: Boolean(initial?.unit),
      imageUrl: Boolean(initial?.imageUrl),
    };
  };

  const handleBarcodeLookup = async (rawCode: string, force = false) => {
    const cleanCode = normalizeBarcode(rawCode);
    if (!cleanCode) return;

    if (!isValidBarcode(cleanCode)) {
      lastLookedUpBarcodeRef.current = '';
      setBarcodeLookupStatus({
        type: 'not_found',
        barcode: cleanCode,
        message:
          'Barcode must be 6–14 digits for Open Food Facts lookup. Please enter details manually.',
      });
      return;
    }

    // Prevent duplicate API calls for the same barcode while in-flight or already checked
    if (!force && (isLookingUpBarcode || lastLookedUpBarcodeRef.current === cleanCode)) {
      return;
    }

    lastLookedUpBarcodeRef.current = cleanCode;
    setIsLookingUpBarcode(true);
    setBarcodeLookupStatus({
      type: 'loading',
      barcode: cleanCode,
      message: `Searching Open Food Facts for barcode ${cleanCode}...`,
    });

    try {
      const result = await lookupProductByBarcode(cleanCode);
      if (result.status === 'found') {
        const fetched = result.product;
        setFormName((prev) =>
          !touchedFieldsRef.current.name && !prev.trim() && fetched.productName
            ? fetched.productName
            : prev
        );
        setFormBrand((prev) =>
          !touchedFieldsRef.current.brand && !prev.trim() && fetched.brand
            ? fetched.brand
            : prev
        );
        setFormCategory((prev) =>
          !touchedFieldsRef.current.category && fetched.categoryId ? fetched.categoryId : prev
        );
        setFormUnit((prev) =>
          !touchedFieldsRef.current.unit &&
          (!prev.trim() || prev === '1 kg') &&
          fetched.packagingOrWeight
            ? fetched.packagingOrWeight
            : prev
        );
        setFormImageUrl((prev) =>
          !touchedFieldsRef.current.imageUrl && !prev && fetched.imageUrl
            ? fetched.imageUrl
            : prev
        );

        setBarcodeLookupStatus({
          type: 'found',
          barcode: cleanCode,
          message:
            'Product details auto-filled from Open Food Facts. Please enter or confirm Selling Price, MRP, and Stock Units.',
        });
      } else if (result.status === 'not_found' || result.status === 'invalid') {
        if (result.status === 'invalid') {
          lastLookedUpBarcodeRef.current = '';
        }
        setBarcodeLookupStatus({
          type: 'not_found',
          barcode: cleanCode,
          message:
            result.status === 'invalid'
              ? result.message
              : 'Product not found. Please enter details manually.',
        });
      } else {
        lastLookedUpBarcodeRef.current = '';
        setBarcodeLookupStatus({
          type: 'error',
          barcode: cleanCode,
          message: result.message,
        });
      }
    } finally {
      setIsLookingUpBarcode(false);
    }
  };

  const openAddModal = () => {
    setEditingProduct(null);
    setFormName('');
    setFormBrand('');
    setFormCategory('cat-vegetables');
    setFormPrice(40);
    setFormMrp(50);
    setFormUnit('1 kg');
    setFormStock(50);
    setFormImageUrl('');
    setFormImagePublicId('');
    setFormBarcode('');
    setFormBarcodeAliases('');
    setProductFormError('');
    setIsProductImageUploading(false);
    setIsSavingProduct(false);
    setIsLookingUpBarcode(false);
    setBarcodeLookupStatus({ type: 'idle' });
    lastLookedUpBarcodeRef.current = '';
    resetProductFormTouchedState();
    setIsAddProductOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setFormName(p.name);
    setFormBrand(p.brand || '');
    setFormCategory(p.category);
    setFormPrice(p.price);
    setFormMrp(p.mrp);
    setFormUnit(p.unit);
    setFormStock(p.stockCount);
    setFormImageUrl(p.imageUrl);
    setFormImagePublicId(p.imagePublicId || '');
    setFormBarcode(p.barcode || '');
    setFormBarcodeAliases((p.barcodeAliases || []).join(', '));
    setProductFormError('');
    setIsProductImageUploading(false);
    setIsSavingProduct(false);
    setIsLookingUpBarcode(false);
    setBarcodeLookupStatus({ type: 'idle' });
    lastLookedUpBarcodeRef.current = p.barcode || '';
    resetProductFormTouchedState({
      name: Boolean(p.name),
      brand: Boolean(p.brand),
      category: true,
      unit: Boolean(p.unit),
      imageUrl: Boolean(p.imageUrl),
    });
    setIsAddProductOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setProductFormError('');
    if (!formName.trim()) return;

    if (isProductImageUploading) {
      setProductFormError('Please wait for the product image to finish uploading to Cloudinary before publishing.');
      return;
    }

    if (!formImageUrl) {
      setProductFormError('Product image is required. Please select and upload a photo from your mobile gallery.');
      return;
    }

    if (!store) {
      setProductFormError('Please register and get your supermarket approved first before adding products.');
      return;
    }

    const parsedBarcode = formBarcode.trim() || undefined;
    const parsedAliases = Array.from(
      new Set(
        formBarcodeAliases
          .split(',')
          .map((s) => s.trim())
          .filter((s) => Boolean(s) && s !== parsedBarcode)
      )
    );

    const allEnteredCodes = [...(parsedBarcode ? [parsedBarcode] : []), ...parsedAliases];
    if (allEnteredCodes.length > 0) {
      const duplicate = checkBarcodeDuplicate(store.id, allEnteredCodes, editingProduct?.id);
      if (duplicate) {
        setProductFormError(
          `Duplicate barcode "${duplicate.barcode}" is already assigned to "${duplicate.existingProduct.name}" in your store.`
        );
        return;
      }
    }

    setIsSavingProduct(true);
    try {
      if (editingProduct) {
        await updateProduct(editingProduct.id, {
          name: formName,
          brand: formBrand.trim(),
          category: formCategory,
          price: Number(formPrice),
          mrp: Number(formMrp),
          unit: formUnit,
          stockCount: Number(formStock),
          imageUrl: formImageUrl,
          imagePublicId: formImagePublicId || '',
          barcode: parsedBarcode || '',
          barcodeAliases: parsedAliases,
        });
      } else {
        await addProduct({
          storeId: store.id,
          apartmentId: store.apartmentId,
          name: formName,
          ...(formBrand.trim() ? { brand: formBrand.trim() } : {}),
          description: `Fresh daily groceries stocked by ${store.name}`,
          category: formCategory,
          imageUrl: formImageUrl,
          ...(formImagePublicId ? { imagePublicId: formImagePublicId } : {}),
          price: Number(formPrice),
          mrp: Number(formMrp),
          unit: formUnit,
          inStock: true,
          stockCount: Number(formStock),
          ...(parsedBarcode ? { barcode: parsedBarcode } : {}),
          ...(parsedAliases.length > 0 ? { barcodeAliases: parsedAliases } : {}),
        });

        setAddProductSuccess(true);
        setTimeout(() => setAddProductSuccess(false), 3000);
        setFormName('');
        setFormBrand('');
        setFormCategory('cat-vegetables');
        setFormUnit('1 kg');
        setFormImageUrl('');
        setFormImagePublicId('');
        setFormBarcode('');
        setFormBarcodeAliases('');
        setBarcodeLookupStatus({ type: 'idle' });
        lastLookedUpBarcodeRef.current = '';
        resetProductFormTouchedState();
      }

      setIsAddProductOpen(false);
    } catch (err: any) {
      console.error('Failed to save product in Firestore:', err);
      setProductFormError(err.message || 'Failed to save product. Please try again.');
    } finally {
      setIsSavingProduct(false);
    }
  };

  const handleRenewSubscription = async () => {
    if (!store) return;
    setIsPayingSub(true);
    setTimeout(async () => {
      await paySubscription(store.id, 'UPI');
      setIsPayingSub(false);
      alert('Subscription successfully renewed for ₹199! Store remains active for 30 days.');
    }, 1000);
  };

  const handleAddDeliveryBoySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!store) return;
    if (!boyName.trim() || !boyPhone.trim()) return;
    await addDeliveryBoy(store.id, boyName.trim(), boyPhone.trim());
    setBoyName('');
    setBoyPhone('');
    setIsAddBoyOpen(false);
  };

  // 10-Item Menu Definition exactly as requested
  const menuItems = [
    {
      id: 'dashboard' as const,
      number: '1',
      label: 'Dashboard',
      icon: <LayoutDashboard className="w-4 h-4" />,
      badge: pendingOrders.length > 0 ? `${pendingOrders.length} new` : undefined,
    },
    {
      id: 'create_supermarket' as const,
      number: '2',
      label: 'Create Supermarket',
      icon: <PlusCircle className="w-4 h-4" />,
      highlight: true,
      tag: 'Featured',
    },
    {
      id: 'my_supermarket' as const,
      number: '3',
      label: 'My Supermarket',
      icon: <Store className="w-4 h-4" />,
      badge: store?.status === 'pending_approval' ? 'Pending' : store?.status === 'active' ? 'Active' : undefined,
    },
    {
      id: 'add_products' as const,
      number: '4',
      label: 'Add Products',
      icon: <Plus className="w-4 h-4" />,
    },
    {
      id: 'manage_products' as const,
      number: '5',
      label: 'Manage Products',
      icon: <Boxes className="w-4 h-4" />,
      badge: storeProducts.length > 0 ? `${storeProducts.length}` : undefined,
    },
    {
      id: 'manage_orders' as const,
      number: '6',
      label: 'Manage Orders',
      icon: <ShoppingBag className="w-4 h-4" />,
      badge: pendingOrders.length > 0 ? `${pendingOrders.length}` : undefined,
    },
    {
      id: 'pos_billing' as const,
      number: '7',
      label: 'POS Billing (Barcode)',
      icon: <ScanBarcode className="w-4 h-4" />,
      tag: 'POS',
    },
    {
      id: 'sales_reports' as const,
      number: '8',
      label: 'Sales Reports',
      icon: <TrendingUp className="w-4 h-4" />,
    },
    {
      id: 'subscription' as const,
      number: '9',
      label: 'Subscription – ₹199/month',
      icon: <CreditCard className="w-4 h-4" />,
      tag: '₹199',
    },
    {
      id: 'my_profile' as const,
      number: '10',
      label: 'My Profile',
      icon: <User className="w-4 h-4" />,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-100/80 text-slate-900 pb-20">
      {/* Top Banner & Header */}
      <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-40 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 text-slate-300 hover:text-white rounded-xl hover:bg-slate-800"
              aria-label="Toggle Menu"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center text-slate-950 font-black shadow-md">
              <Store className="w-5 h-5 text-slate-950" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-sm sm:text-base tracking-tight text-white">
                  {store ? store.name : 'Super Express Owner Portal'}
                </h1>
                {store && (
                  <span
                    className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase ${
                      store.status === 'active'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : store.status === 'pending_approval'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    }`}
                  >
                    {store.status === 'active' ? 'Active' : store.status === 'pending_approval' ? 'Pending Approval' : 'Closed'}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                Owner: <span className="text-slate-200 font-semibold">{ownerUser.name}</span> ({ownerUser.phone})
                {store && <span className="ml-2 text-emerald-400 font-semibold">• {store.apartmentName}</span>}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Live Order Sound Status Toggle */}
            <button
              onClick={() => {
                const nextMuted = !isSoundMuted;
                setIsSoundMuted(nextMuted);
                if (nextMuted) {
                  stopOrderAlarmSound();
                } else if (unhandledPlacedOrders.length > 0) {
                  startOrderAlarmSound();
                }
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-[11px] font-bold border transition cursor-pointer ${
                isSoundMuted
                  ? 'bg-rose-950/80 border-rose-800 text-rose-300'
                  : 'bg-emerald-950/80 border-emerald-800 text-emerald-300'
              }`}
              title={isSoundMuted ? 'Live sound is muted. Click to enable loud alert beep.' : 'Live sound alert active. Click to mute.'}
            >
              {isSoundMuted ? (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                  <span className="hidden sm:inline">Muted</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                  <span className="hidden sm:inline">Sound Active</span>
                </>
              )}
            </button>

            {/* Test Notification Button (Requirement 10) */}
            <button
              onClick={handleTriggerTestNotification}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow-md transition transform active:scale-95 cursor-pointer"
              title="Test Live Order Alert Sound and Popup Modal"
            >
              <Bell className="w-3.5 h-3.5 text-slate-950 animate-bounce" />
              <span>Test Notification</span>
            </button>

            {/* Browser push notifications permission */}
            {notifPermission !== 'granted' && (
              <button
                onClick={handleRequestPushPermission}
                className="hidden lg:flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 cursor-pointer"
                title="Enable OS/browser notifications"
              >
                <span>Enable Push</span>
              </button>
            )}

            {/* Quick POS Billing Button */}
            <button
              onClick={() => {
                setActiveTab('pos_billing');
                setIsMobileMenuOpen(false);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl border border-white/15 transition cursor-pointer"
              title="Open Dual Barcode POS Billing"
            >
              <ScanBarcode className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">POS Billing</span>
            </button>

            {/* Prominent Create Supermarket Shortcut */}
            <button
              onClick={() => {
                setActiveTab('create_supermarket');
                setIsMobileMenuOpen(false);
              }}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition transform active:scale-95 cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Create Supermarket</span>
            </button>

            {/* Store availability toggle if active store exists */}
            {store && store.status === 'active' && (
              <button
                onClick={() => toggleStoreAvailability(store.id)}
                className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
                title="Toggle Store Availability"
              >
                <Power className="w-3 h-3 text-emerald-400" />
                <span>{store.status === 'active' ? 'Open' : 'Closed'}</span>
              </button>
            )}

            {/* Logout Button */}
            <button
              onClick={logoutOwner}
              className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-xl transition cursor-pointer"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Sticky Urgent Alert Banner if unhandled orders are pending */}
      {unhandledPlacedOrders.length > 0 && (
        <div className="bg-red-600 text-white px-4 py-2 text-xs font-black shadow-lg animate-pulse sticky top-[60px] z-30">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-amber-200 animate-bounce" />
              <span>
                🔔 {unhandledPlacedOrders.length} NEW ORDER RECEIVED! LOUD ALERT BEEPING CONTINUOUSLY...
              </span>
            </div>
            <button
              onClick={() => {
                setActiveTab('manage_orders');
                setOrderFilter('placed');
              }}
              className="px-3 py-1 bg-white text-red-950 rounded-lg font-black text-xs hover:bg-amber-100 transition shadow-xs cursor-pointer"
            >
              View Order #{unhandledPlacedOrders[0].id}
            </button>
          </div>
        </div>
      )}

      {/* Main Layout: Sidebar Navigation + Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 flex flex-col md:flex-row gap-6">
        {/* Desktop Sidebar (10 Menu Options) */}
        <aside className="hidden md:flex flex-col w-64 shrink-0 bg-white rounded-3xl p-4 border border-slate-200 shadow-xs h-fit sticky top-20 space-y-1">
          <div className="px-3 py-2 mb-2 border-b border-slate-100">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">
              Owner Panel Menu
            </span>
          </div>

          {menuItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all text-left cursor-pointer ${
                  isActive
                    ? 'bg-emerald-800 text-white shadow-sm'
                    : item.highlight
                    ? 'bg-emerald-50 text-emerald-900 hover:bg-emerald-100 border border-emerald-200/80 font-extrabold'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <span className={`text-[10px] w-4 font-mono ${isActive ? 'text-emerald-200' : 'text-slate-400'}`}>
                    {item.number}.
                  </span>
                  <span className={isActive ? 'text-white' : item.highlight ? 'text-emerald-900' : 'text-slate-700'}>
                    {item.icon}
                  </span>
                  <span className="truncate">{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase shrink-0 ${
                      isActive
                        ? 'bg-white text-emerald-900'
                        : item.highlight
                        ? 'bg-emerald-600 text-white'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
                {item.tag && !item.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded-md font-extrabold shrink-0 ${
                      isActive
                        ? 'bg-emerald-950 text-emerald-200'
                        : 'bg-emerald-600 text-white animate-pulse'
                    }`}
                  >
                    {item.tag}
                  </span>
                )}
              </button>
            );
          })}

          {/* 10. Logout Menu Item */}
          <div className="pt-2 mt-2 border-t border-slate-100">
            <button
              onClick={logoutOwner}
              className="w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-2xl text-xs font-bold text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer text-left"
            >
              <span className="text-[10px] w-4 font-mono text-slate-400">10.</span>
              <LogOut className="w-4 h-4 text-slate-400 group-hover:text-rose-600" />
              <span>Logout</span>
            </button>
          </div>
        </aside>

        {/* Mobile Slide-Out Drawer / Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex">
            <div className="bg-white w-72 max-w-full p-4 h-full shadow-2xl flex flex-col justify-between overflow-y-auto animate-in slide-in-from-left duration-200">
              <div className="space-y-1">
                <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Store className="w-5 h-5 text-emerald-600" />
                    <span className="font-extrabold text-xs text-slate-900">Owner Menu</span>
                  </div>
                  <button
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-800"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {menuItems.map((item) => {
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3.5 py-3 rounded-2xl text-xs font-bold transition text-left cursor-pointer ${
                        isActive
                          ? 'bg-emerald-800 text-white shadow-sm'
                          : item.highlight
                          ? 'bg-emerald-50 text-emerald-900 border border-emerald-200 font-black'
                          : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <span className={`text-[10px] w-4 font-mono ${isActive ? 'text-emerald-200' : 'text-slate-400'}`}>
                          {item.number}.
                        </span>
                        {item.icon}
                        <span className="truncate">{item.label}</span>
                      </div>
                      {item.badge && (
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase shrink-0 ${
                            isActive ? 'bg-white text-emerald-900' : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}

                <button
                  onClick={logoutOwner}
                  className="w-full flex items-center gap-2.5 px-3.5 py-3 rounded-2xl text-xs font-bold text-rose-600 hover:bg-rose-50 transition cursor-pointer text-left mt-2 border-t border-slate-100"
                >
                  <span className="text-[10px] w-4 font-mono text-slate-400">10.</span>
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </button>
              </div>
            </div>
            <div className="flex-1" onClick={() => setIsMobileMenuOpen(false)} />
          </div>
        )}

        {/* Content Pane */}
        <main className="flex-1 min-w-0 space-y-6">
          {/* TAB 1: DASHBOARD */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6 animate-in fade-in-50 duration-150">
              {/* If no store registered yet, show prominent welcome banner */}
              {!store && (
                <div className="bg-gradient-to-br from-emerald-900 via-slate-900 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
                  <div className="max-w-xl space-y-4">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-black bg-emerald-500 text-slate-950 uppercase tracking-wider">
                      <Sparkles className="w-3.5 h-3.5" />
                      Single-Store Exclusive Platform
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-black tracking-tight leading-tight">
                      Welcome, {ownerUser.name}! Register Your Supermarket.
                    </h2>
                    <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
                      Super Express assigns exactly <strong>1 exclusive supermarket</strong> per residential apartment complex. No competition from other stores in the society. Doorstep 10-15 minute grocery deliveries.
                    </p>
                    <div className="flex flex-wrap items-center gap-3 pt-2">
                      <button
                        onClick={() => setActiveTab('create_supermarket')}
                        className="px-6 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm rounded-2xl shadow-lg transition transform active:scale-95 flex items-center gap-2 cursor-pointer"
                      >
                        <PlusCircle className="w-4 h-4" />
                        <span>Create Supermarket Now</span>
                      </button>
                      <button
                        onClick={() => setActiveTab('subscription')}
                        className="px-4 py-3 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-2xl border border-white/20 transition cursor-pointer"
                      >
                        Learn About ₹199/Mo Subscription
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* If store application is pending admin approval */}
              {store && store.status === 'pending_approval' && (
                <div className="bg-amber-50 rounded-3xl p-6 border-2 border-amber-300 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-md">
                      <Clock className="w-6 h-6 animate-pulse" />
                    </div>
                    <div>
                      <span className="text-[10px] font-extrabold uppercase bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full">
                        Application Pending Admin Review
                      </span>
                      <h3 className="text-base font-black text-slate-900 mt-1">
                        Your supermarket is waiting for admin approval.
                      </h3>
                      <p className="text-xs text-slate-600 mt-0.5">
                        Application for <strong>{store.name}</strong> to exclusively serve <strong>{store.apartmentName}</strong> has been submitted to Super Express administrators.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => setActiveTab('my_supermarket')}
                      className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
                    >
                      View Application Details
                    </button>
                  </div>
                </div>
              )}

              {/* If active store exists, show live metrics */}
              {store && store.status === 'active' && (
                <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <img
                      src={store.logoUrl || 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=500&q=80'}
                      alt={store.name}
                      className="w-16 h-16 rounded-2xl object-cover border border-slate-200 shadow-xs"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-xl font-black text-slate-900">{store.name}</h2>
                        <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase">
                          Exclusive Partner
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Society: <strong className="text-emerald-800">{store.apartmentName}</strong> • Operating: {store.openingTime} – {store.closingTime}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <button
                          onClick={() => toggleStoreAvailability(store.id)}
                          className={`text-[11px] font-bold px-3 py-1 rounded-lg border transition cursor-pointer flex items-center gap-1.5 ${
                            store.status === 'active'
                              ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                              : 'bg-slate-100 border-slate-300 text-slate-600'
                          }`}
                        >
                          <Power className="w-3 h-3" />
                          <span>{store.status === 'active' ? '● Accepting Orders' : 'Store Closed'}</span>
                        </button>
                        <span className="text-[11px] text-slate-400">
                          {storeProducts.length} items in catalog
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => setActiveTab('add_products')}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Product</span>
                    </button>
                    <button
                      onClick={() => setActiveTab('manage_orders')}
                      className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>View Orders ({pendingOrders.length})</span>
                    </button>
                  </div>
                </div>
              )}

              {/* KPI Summary Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-bold text-slate-500">Today's Sales</span>
                    <TrendingUp className="w-4 h-4 text-emerald-600" />
                  </div>
                  <h3 className="text-2xl font-black text-slate-900">₹{todaySales}</h3>
                  <p className="text-[10px] text-emerald-600 font-semibold mt-1">
                    {todayOrders.length} orders placed today
                  </p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-bold text-slate-500">Pending Orders</span>
                    <Clock className="w-4 h-4 text-amber-600" />
                  </div>
                  <h3 className="text-2xl font-black text-slate-900">{pendingOrders.length}</h3>
                  <p className="text-[10px] text-slate-400 mt-1">Requires immediate packing</p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-bold text-slate-500">Products Catalog</span>
                    <Package className="w-4 h-4 text-blue-600" />
                  </div>
                  <h3 className="text-2xl font-black text-slate-900">{storeProducts.length}</h3>
                  <p className="text-[10px] text-slate-400 mt-1">In assigned society store</p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <div className="flex items-center justify-between text-slate-400 mb-2">
                    <span className="text-xs font-bold text-slate-500">Subscription</span>
                    <CreditCard className="w-4 h-4 text-purple-600" />
                  </div>
                  <h3 className="text-2xl font-black text-emerald-700">₹199 / Mo</h3>
                  <p className="text-[10px] text-slate-500 mt-1 capitalize">
                    Status: {store?.subscriptionStatus || 'N/A'}
                  </p>
                </div>
              </div>

              {/* Quick Actions Bar */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div
                  onClick={() => setActiveTab('create_supermarket')}
                  className="bg-white p-4 rounded-2xl border-2 border-dashed border-emerald-300 hover:border-emerald-500 hover:bg-emerald-50/50 transition p-4 cursor-pointer flex items-center gap-3.5 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <PlusCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900">Create Supermarket</h4>
                    <p className="text-[11px] text-slate-500">Register new apartment store</p>
                  </div>
                </div>

                <div
                  onClick={() => setActiveTab('add_products')}
                  className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition p-4 cursor-pointer flex items-center gap-3.5 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <Plus className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900">Add Products</h4>
                    <p className="text-[11px] text-slate-500">Direct mobile photo upload</p>
                  </div>
                </div>

                <div
                  onClick={() => setActiveTab('subscription')}
                  className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition p-4 cursor-pointer flex items-center gap-3.5 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <CreditCard className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900">₹199 Subscription</h4>
                    <p className="text-[11px] text-slate-500">Exclusivity management</p>
                  </div>
                </div>
              </div>

              {/* Recent Orders Overview */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-black text-sm text-slate-900">Recent Apartment Orders</h3>
                    <p className="text-xs text-slate-500">Doorstep delivery requests from verified flats</p>
                  </div>
                  <button
                    onClick={() => setActiveTab('manage_orders')}
                    className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
                  >
                    View All Orders →
                  </button>
                </div>

                {storeOrders.length === 0 ? (
                  <div className="py-8 text-center text-slate-400 text-xs">
                    No orders placed yet. Orders will appear here once residents checkout.
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {storeOrders.slice(0, 4).map((o) => (
                      <div key={o.id} className="py-3 flex items-center justify-between text-xs">
                        <div className="space-y-0.5">
                          <div className="font-bold text-slate-900">
                            #{o.id} • {o.customerName}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            Flat {o.deliveryAddress} • {o.itemCount} items
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-black text-emerald-800">₹{o.totalAmount}</div>
                          <span className="text-[10px] font-bold uppercase text-slate-400">
                            {o.status.replace(/_/g, ' ')}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: CREATE SUPERMARKET */}
          {activeTab === 'create_supermarket' && (
            <div className="space-y-6 animate-in fade-in-50 duration-150">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-black text-slate-900 tracking-tight">
                    Create Your Supermarket
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Register a new supermarket application to exclusively serve a residential apartment complex.
                  </p>
                </div>
                <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-3 py-1 rounded-full uppercase">
                  ₹199 / Mo Plan
                </span>
              </div>

              {/* Existing supermarket notice */}
              {store && (
                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-900 flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">You currently manage: {store.name}</span>
                    <p className="text-[11px] text-emerald-700 mt-0.5">
                      Status: <strong>{store.status.toUpperCase()}</strong> for {store.apartmentName}. Submitting this form creates an additional or replacement supermarket application for admin review.
                    </p>
                  </div>
                </div>
              )}

              {/* Complete Create Supermarket Form Embedded Inline */}
              <CreateSupermarketModal
                isOpen={true}
                inline={true}
                onCreated={() => {
                  setActiveTab('my_supermarket');
                }}
              />
            </div>
          )}

          {/* TAB 3: MY SUPERMARKET */}
          {activeTab === 'my_supermarket' && (
            <div className="space-y-6 animate-in fade-in-50 duration-150">
              {!store ? (
                <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center space-y-4 max-w-lg mx-auto">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto">
                    <Store className="w-8 h-8" />
                  </div>
                  <h3 className="font-black text-lg text-slate-900">No Supermarket Registered Yet</h3>
                  <p className="text-xs text-slate-500">
                    You have not submitted a supermarket application. Create your supermarket to be assigned exclusively to an apartment society.
                  </p>
                  <button
                    onClick={() => setActiveTab('create_supermarket')}
                    className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer"
                  >
                    Create Supermarket Now
                  </button>
                </div>
              ) : store.status === 'pending_approval' ? (
                /* PENDING APPROVAL SCREEN */
                <div className="bg-white rounded-3xl p-8 border-2 border-amber-300 shadow-xl text-center space-y-6 max-w-xl mx-auto">
                  <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto ring-8 ring-amber-50">
                    <Clock className="w-8 h-8 animate-pulse" />
                  </div>

                  <div className="space-y-2">
                    <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-800 text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                      Pending Admin Review
                    </span>
                    <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                      Your supermarket is waiting for admin approval.
                    </h2>
                    <p className="text-xs text-slate-500 max-w-md mx-auto">
                      Our administration team is reviewing your application for exclusivity at{' '}
                      <strong className="text-slate-800">{store.apartmentName}</strong>.
                    </p>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left text-xs space-y-2">
                    <div className="flex justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500">Supermarket Name</span>
                      <span className="font-bold text-slate-900">{store.name}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500">Target Society</span>
                      <span className="font-bold text-emerald-800">{store.apartmentName}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500">Owner Contact</span>
                      <span className="font-bold text-slate-900">{store.ownerPhone}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500">Physical Address</span>
                      <span className="font-bold text-slate-900">{store.address}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Monthly Subscription</span>
                      <span className="font-bold text-slate-900">₹199 / month (Upon Approval)</span>
                    </div>
                  </div>

                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-800 text-left flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>
                      Once approved by the Super Express admin, your store will become active and exclusive to this society.
                    </span>
                  </div>

                  <div className="pt-2 flex justify-center gap-3">
                    <button
                      onClick={() => setActiveTab('create_supermarket')}
                      className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
                    >
                      Submit Another Application
                    </button>
                  </div>
                </div>
              ) : store.status === 'rejected' ? (
                /* REJECTED APPLICATION SCREEN */
                <div className="bg-white rounded-3xl p-8 border border-rose-300 shadow-xl text-center space-y-6 max-w-xl mx-auto">
                  <div className="w-16 h-16 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center mx-auto">
                    <XCircle className="w-8 h-8" />
                  </div>
                  <h2 className="text-xl font-black text-slate-900">Application Not Approved</h2>
                  <p className="text-xs text-rose-700 bg-rose-50 p-3 rounded-xl border border-rose-200">
                    Reason: {store.rejectionReason || 'Another supermarket is already active for this apartment complex.'}
                  </p>
                  <button
                    onClick={() => setActiveTab('create_supermarket')}
                    className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer"
                  >
                    Select Another Apartment & Re-Apply
                  </button>
                </div>
              ) : (
                /* APPROVED / ACTIVE SUPERMARKET VIEW */
                <div className="space-y-6">
                  <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <img
                        src={store.logoUrl || 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=500&q=80'}
                        alt={store.name}
                        className="w-16 h-16 rounded-2xl object-cover border border-slate-200 shadow-xs"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h2 className="text-xl font-black text-slate-900">{store.name}</h2>
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase">
                            Active Store
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Assigned Apartment: <strong className="text-emerald-800">{store.apartmentName}</strong>
                        </p>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Address: {store.address}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => toggleStoreAvailability(store.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer flex items-center gap-1.5 ${
                          store.status === 'active'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                            : 'bg-slate-100 border-slate-300 text-slate-600'
                        }`}
                      >
                        <Power className="w-3.5 h-3.5" />
                        <span>{store.status === 'active' ? 'Open for Orders' : 'Store is Closed'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Store Details Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3 text-xs">
                      <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                        <Clock className="w-4 h-4 text-emerald-600" />
                        Operating Schedule & Timings
                      </h4>
                      <div className="space-y-2">
                        <div className="flex justify-between border-b border-slate-100 pb-2">
                          <span className="text-slate-500">Opening Time:</span>
                          <span className="font-bold text-slate-900">{store.openingTime}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-100 pb-2">
                          <span className="text-slate-500">Closing Time:</span>
                          <span className="font-bold text-slate-900">{store.closingTime}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-100 pb-2">
                          <span className="text-slate-500">Target Delivery Time:</span>
                          <span className="font-bold text-emerald-700">10-15 Minutes Doorstep</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Minimum Order Amount:</span>
                          <span className="font-bold text-slate-900">₹{store.minOrderAmount}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3 text-xs">
                      <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-emerald-600" />
                        Society Exclusivity Contract
                      </h4>
                      <div className="space-y-2">
                        <div className="flex justify-between border-b border-slate-100 pb-2">
                          <span className="text-slate-500">Apartment Complex:</span>
                          <span className="font-bold text-slate-900">{store.apartmentName}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-100 pb-2">
                          <span className="text-slate-500">Monthly Partner Fee:</span>
                          <span className="font-bold text-emerald-700">₹199 / Month</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-100 pb-2">
                          <span className="text-slate-500">Subscription Status:</span>
                          <span className="font-bold uppercase text-emerald-700">{store.subscriptionStatus}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Exclusivity Term:</span>
                          <span className="font-bold text-slate-900">Single active supermarket</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* In-House Delivery Boys Management */}
                  <div className="bg-white rounded-2xl p-6 border border-slate-200 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                          <Bike className="w-4 h-4 text-emerald-600" />
                          In-House Delivery Staff ({deliveryBoys.length})
                        </h4>
                        <p className="text-xs text-slate-500">
                          Owner manages delivery through their own dedicated delivery personnel.
                        </p>
                      </div>
                      <button
                        onClick={() => setIsAddBoyOpen(true)}
                        className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add Delivery Boy</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {deliveryBoys.map((boy) => (
                        <div key={boy.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                          <div>
                            <div className="font-bold text-xs text-slate-900">{boy.name}</div>
                            <div className="text-[11px] text-slate-500">{boy.phone}</div>
                          </div>
                          <button
                            onClick={() => toggleDeliveryBoy(store.id, boy.id)}
                            className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                              boy.active ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                            }`}
                          >
                            {boy.active ? 'On Duty' : 'Off'}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ADD PRODUCTS */}
          {activeTab === 'add_products' && (
            <div className="space-y-6 animate-in fade-in-50 duration-150">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
                <h2 className="text-xl font-black text-slate-900 tracking-tight">
                  Add New Grocery Product
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Directly upload images from your mobile photo gallery and publish to your apartment's grocery catalog.
                </p>
              </div>

              {addProductSuccess && (
                <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-2xl text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Product published successfully to your supermarket catalog!</span>
                </div>
              )}

              {!store ? (
                <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center space-y-4 max-w-md mx-auto">
                  <Store className="w-10 h-10 text-slate-300 mx-auto" />
                  <h3 className="font-bold text-sm text-slate-800">Supermarket Required</h3>
                  <p className="text-xs text-slate-500">
                    You must create your supermarket first before adding products.
                  </p>
                  <button
                    onClick={() => setActiveTab('create_supermarket')}
                    className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl cursor-pointer"
                  >
                    Go to Create Supermarket
                  </button>
                </div>
              ) : (
                <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs max-w-2xl">
                  <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-slate-700 font-bold block mb-1">
                          Product Title <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Fresh Farm Tomatoes (Hybrid)"
                          value={formName}
                          onChange={(e) => {
                            touchedFieldsRef.current.name = e.target.value.trim().length > 0;
                            setFormName(e.target.value);
                          }}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:border-emerald-500 font-semibold"
                        />
                      </div>

                      <div>
                        <label className="text-slate-700 font-bold block mb-1">
                          Brand (Optional)
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Amul, Tata, Britannia"
                          value={formBrand}
                          onChange={(e) => {
                            touchedFieldsRef.current.brand = e.target.value.trim().length > 0;
                            setFormBrand(e.target.value);
                          }}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:border-emerald-500 font-semibold"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-slate-700 font-bold block mb-1">Category</label>
                        <select
                          value={formCategory}
                          onChange={(e) => {
                            touchedFieldsRef.current.category = true;
                            setFormCategory(e.target.value);
                          }}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none font-medium"
                        >
                          <option value="cat-vegetables">Vegetables & Fruits</option>
                          <option value="cat-dairy">Dairy, Bread & Eggs</option>
                          <option value="cat-snacks">Snacks & Munchies</option>
                          <option value="cat-beverages">Cold Drinks & Juices</option>
                          <option value="cat-staples">Atta, Rice & Dal</option>
                          <option value="cat-cleaning">Household & Cleaning</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-slate-700 font-bold block mb-1">Packaging / Unit</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. 500 g or 1 kg"
                          value={formUnit}
                          onChange={(e) => {
                            touchedFieldsRef.current.unit = e.target.value.trim().length > 0;
                            setFormUnit(e.target.value);
                          }}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none font-semibold"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <label className="text-slate-700 font-bold block mb-1">Selling Price (₹)</label>
                        <input
                          type="number"
                          required
                          min={1}
                          value={formPrice}
                          onChange={(e) => setFormPrice(Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none font-black text-emerald-800"
                        />
                      </div>
                      <div>
                        <label className="text-slate-700 font-bold block mb-1">MRP (₹)</label>
                        <input
                          type="number"
                          required
                          min={1}
                          value={formMrp}
                          onChange={(e) => setFormMrp(Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none text-slate-500 font-semibold"
                        />
                      </div>
                      <div>
                        <label className="text-slate-700 font-bold block mb-1">Stock Units</label>
                        <input
                          type="number"
                          required
                          min={0}
                          value={formStock}
                          onChange={(e) => setFormStock(Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none font-bold"
                        />
                      </div>
                    </div>

                    {/* Barcode & Alias Fields (Never generated automatically) */}
                    <div className="space-y-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="text-slate-700 font-bold block mb-1">
                            Product Barcode (EAN / UPC / Code 128)
                          </label>
                          <div className="flex gap-1.5">
                            <input
                              type="text"
                              placeholder="Scan or type barcode (optional)"
                              value={formBarcode}
                              onChange={(e) => {
                                const nextVal = e.target.value;
                                setFormBarcode(nextVal);
                                setProductFormError('');
                                if (nextVal.trim() !== lastLookedUpBarcodeRef.current) {
                                  lastLookedUpBarcodeRef.current = '';
                                  setBarcodeLookupStatus({ type: 'idle' });
                                }
                              }}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  void handleBarcodeLookup(formBarcode);
                                } else if (e.key === 'Tab' && formBarcode.trim()) {
                                  void handleBarcodeLookup(formBarcode);
                                }
                              }}
                              className="flex-1 bg-white border border-slate-200 rounded-xl p-2.5 outline-none focus:border-emerald-500 font-mono font-bold text-xs"
                            />
                            <button
                              type="button"
                              onClick={() => void handleBarcodeLookup(formBarcode, true)}
                              disabled={isLookingUpBarcode || !formBarcode.trim()}
                              className="px-2.5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer shrink-0"
                              title="Lookup product details on Open Food Facts"
                            >
                              {isLookingUpBarcode ? (
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              ) : (
                                <Search className="w-3.5 h-3.5" />
                              )}
                            </button>
                            <button
                              type="button"
                              onClick={() => setIsBarcodeScannerOpen(true)}
                              className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer shrink-0"
                              title="Scan barcode with camera"
                            >
                              <Camera className="w-3.5 h-3.5" />
                              <span>Scan</span>
                            </button>
                          </div>
                        </div>

                        <div>
                          <label className="text-slate-700 font-bold block mb-1">
                            Barcode Aliases (comma-separated)
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. 8901058851234, 8901058000112"
                            value={formBarcodeAliases}
                            onChange={(e) => {
                              setFormBarcodeAliases(e.target.value);
                              setProductFormError('');
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') e.preventDefault();
                            }}
                            className="w-full bg-white border border-slate-200 rounded-xl p-2.5 outline-none focus:border-emerald-500 font-mono text-xs"
                          />
                        </div>
                      </div>

                      {barcodeLookupStatus.type !== 'idle' && (
                        <div
                          className={`p-2.5 rounded-xl border text-[11px] font-semibold flex items-center gap-2 ${
                            barcodeLookupStatus.type === 'loading'
                              ? 'bg-sky-50 border-sky-200 text-sky-800'
                              : barcodeLookupStatus.type === 'found'
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                              : barcodeLookupStatus.type === 'not_found'
                              ? 'bg-amber-50 border-amber-200 text-amber-900'
                              : 'bg-rose-50 border-rose-200 text-rose-800'
                          }`}
                        >
                          {barcodeLookupStatus.type === 'loading' ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
                          ) : barcodeLookupStatus.type === 'found' ? (
                            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                          ) : (
                            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                          )}
                          <span>{barcodeLookupStatus.message}</span>
                        </div>
                      )}
                    </div>

                    {/* Direct Image Upload from Mobile Gallery */}
                    <ProductImageUploader
                      imageUrl={formImageUrl}
                      imagePublicId={formImagePublicId}
                      onImageUploaded={(result) => {
                        touchedFieldsRef.current.imageUrl = true;
                        setFormImageUrl(result.secureUrl);
                        setFormImagePublicId(result.publicId);
                      }}
                      onImageRemoved={() => {
                        touchedFieldsRef.current.imageUrl = false;
                        setFormImageUrl('');
                        setFormImagePublicId('');
                      }}
                      onUploadingChange={(uploading) => setIsProductImageUploading(uploading)}
                    />

                    {productFormError && (
                      <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold">
                        {productFormError}
                      </div>
                    )}

                    <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                      <div className="text-[11px] text-slate-500">
                        {isProductImageUploading ? (
                          <span className="text-amber-600 font-semibold flex items-center gap-1.5">
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            Uploading photo to Cloudinary...
                          </span>
                        ) : !formImageUrl ? (
                          <span className="text-rose-500 font-medium flex items-center gap-1">
                            <Camera className="w-3.5 h-3.5" />
                            Photo from mobile gallery required before publishing.
                          </span>
                        ) : (
                          <span className="text-emerald-600 font-semibold flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Product image ready for catalog!
                          </span>
                        )}
                      </div>

                      <button
                        type="submit"
                        disabled={!formImageUrl || isProductImageUploading || isSavingProduct}
                        className={`w-full sm:w-auto px-6 py-3 font-black text-xs rounded-xl shadow-md transition transform flex items-center justify-center gap-2 ${
                          !formImageUrl || isProductImageUploading || isSavingProduct
                            ? 'bg-slate-200 text-slate-400 border border-slate-300 cursor-not-allowed'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer active:scale-98 shadow-emerald-600/20'
                        }`}
                      >
                        {isSavingProduct ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span>Publishing Product...</span>
                          </>
                        ) : isProductImageUploading ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span>Uploading Image...</span>
                          </>
                        ) : !formImageUrl ? (
                          <>
                            <Camera className="w-4 h-4" />
                            <span>Upload Image to Publish</span>
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Publish Product to Catalog</span>
                          </>
                        )}
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: MANAGE PRODUCTS */}
          {activeTab === 'manage_products' && (
            <div className="space-y-6 animate-in fade-in-50 duration-150">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-black text-slate-900 tracking-tight">
                    Manage Products & Inventory
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Update prices, stock counts, and availability for your grocery inventory.
                  </p>
                </div>
                <button
                  onClick={openAddModal}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Product</span>
                </button>
              </div>

              <div className="flex items-center gap-3 bg-white p-3.5 rounded-2xl border border-slate-200">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search products by title, category, or barcode..."
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  className="w-full text-xs outline-none bg-transparent"
                />
              </div>

              {filteredProducts.length === 0 ? (
                <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center text-slate-400 text-xs">
                  No products found. Click "Add Product" to stock your supermarket inventory.
                </div>
              ) : (
                <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                        <tr>
                          <th className="p-3.5">Product</th>
                          <th className="p-3.5">Unit</th>
                          <th className="p-3.5">Price / MRP</th>
                          <th className="p-3.5">Stock</th>
                          <th className="p-3.5">Status</th>
                          <th className="p-3.5 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredProducts.map((p) => (
                          <tr key={p.id} className="hover:bg-slate-50/70">
                            <td className="p-3.5 flex items-center gap-3">
                              <img
                                src={p.imageUrl}
                                alt={p.name}
                                className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0"
                              />
                              <div>
                                <div className="font-bold text-slate-900">{p.name}</div>
                                <div className="text-[10px] text-slate-400 flex flex-wrap items-center gap-1.5">
                                  <span>{p.category}</span>
                                  {p.brand && (
                                    <span className="bg-emerald-50 text-emerald-700 font-semibold px-1.5 py-0.5 rounded border border-emerald-200">
                                      {p.brand}
                                    </span>
                                  )}
                                  {p.barcode && (
                                    <span className="font-mono bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded border border-slate-200">
                                      {p.barcode}
                                      {p.barcodeAliases && p.barcodeAliases.length > 0
                                        ? ` (+${p.barcodeAliases.length})`
                                        : ''}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </td>
                            <td className="p-3.5 font-medium text-slate-600">{p.unit}</td>
                            <td className="p-3.5">
                              <div className="font-bold text-slate-900">₹{p.price}</div>
                              <div className="text-[10px] text-slate-400 line-through">₹{p.mrp}</div>
                            </td>
                            <td className="p-3.5 font-semibold text-slate-800">{p.stockCount} units</td>
                            <td className="p-3.5">
                              <button
                                onClick={() => toggleProductStock(p.id)}
                                className={`px-2.5 py-1 rounded-full text-[10px] font-bold cursor-pointer transition ${
                                  p.inStock
                                    ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                                    : 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                                }`}
                              >
                                {p.inStock ? 'In Stock' : 'Out of Stock'}
                              </button>
                            </td>
                            <td className="p-3.5 text-right space-x-2">
                              <button
                                onClick={() => openEditModal(p)}
                                className="p-1.5 text-slate-500 hover:text-emerald-600 rounded-lg hover:bg-emerald-50 cursor-pointer"
                                title="Edit"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => deleteProduct(p.id)}
                                className="p-1.5 text-slate-500 hover:text-rose-600 rounded-lg hover:bg-rose-50 cursor-pointer"
                                title="Delete"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 6: MANAGE ORDERS */}
          {activeTab === 'manage_orders' && (
            <div className="space-y-6 animate-in fade-in-50 duration-150">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-black text-slate-900 tracking-tight">
                    Manage Customer Orders
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Orders placed exclusively by residents of {store?.apartmentName || 'your assigned society'}.
                  </p>
                </div>
                <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs overflow-x-auto">
                  {(['all', 'placed', 'accepted', 'packing', 'out_for_delivery', 'delivered'] as const).map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setOrderFilter(filter)}
                      className={`px-3 py-1.5 rounded-lg font-bold capitalize transition cursor-pointer ${
                        orderFilter === filter
                          ? 'bg-white text-emerald-800 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {filter === 'all' ? 'All' : filter.replace(/_/g, ' ')}
                    </button>
                  ))}
                </div>
              </div>

              {filteredOrders.length === 0 ? (
                <div className="bg-white rounded-3xl p-12 border border-slate-200 text-center space-y-3">
                  <ShoppingBag className="w-10 h-10 text-slate-300 mx-auto" />
                  <h3 className="font-bold text-sm text-slate-800">No Orders in this Status</h3>
                  <p className="text-xs text-slate-500">
                    When customers place orders from their apartment, they will appear here instantly.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredOrders.map((order) => {
                    const isNew = order.status === 'placed';
                    const isDelivered = order.status === 'delivered';
                    const isOut = order.status === 'out_for_delivery';

                    return (
                      <div
                        key={order.id}
                        className={`bg-white rounded-2xl border overflow-hidden shadow-xs transition-all ${
                          isNew ? 'border-emerald-500 ring-2 ring-emerald-400/20' : 'border-slate-200'
                        }`}
                      >
                        <div className="p-3.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-xs text-slate-900">#{order.id}</span>
                              <span className="text-[10px] text-slate-400">•</span>
                              <span className="text-[11px] font-bold text-emerald-800">₹{order.totalAmount}</span>
                            </div>
                            <span className="text-[11px] text-slate-500">
                              {order.customerName} ({order.customerPhone})
                            </span>
                          </div>
                          <span
                            className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${
                              isNew
                                ? 'bg-amber-100 text-amber-800 animate-pulse'
                                : isDelivered
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {order.status.replace(/_/g, ' ')}
                          </span>
                        </div>

                        <div className="p-3.5 space-y-3 text-xs">
                          <div className="bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-100">
                            <span className="text-[10px] uppercase font-bold text-emerald-800 block">
                              Doorstep Destination:
                            </span>
                            <p className="font-bold text-slate-800 text-xs mt-0.5">
                              {order.deliveryAddress}
                            </p>
                            <div className="flex items-center gap-2 mt-1 text-[11px]">
                              <span className="text-slate-600 font-semibold">
                                Payment: {order.paymentMethod}
                              </span>
                              <span className="text-slate-300">|</span>
                              <span className={`font-bold uppercase ${order.paymentStatus === 'paid' ? 'text-emerald-700' : 'text-amber-700'}`}>
                                {order.paymentStatus}
                              </span>
                            </div>
                          </div>

                          <div>
                            <p className="text-[11px] font-bold text-slate-600 mb-1">
                              Items ({order.itemCount}):
                            </p>
                            <div className="space-y-1 max-h-24 overflow-y-auto pr-1">
                              {order.items?.map((it) => (
                                <div key={it.id} className="flex justify-between text-slate-700 text-[11px]">
                                  <span>{it.quantity}x {it.name}</span>
                                  <span className="font-semibold">₹{it.totalPrice}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Action Buttons based on status */}
                          <div className="pt-2 border-t border-slate-100">
                            {isNew && (
                              <div className="flex gap-2">
                                <button
                                  onClick={() => updateOrderStatus(order.id, 'accepted')}
                                  className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg cursor-pointer"
                                >
                                  Accept Order
                                </button>
                                <button
                                  onClick={() => updateOrderStatus(order.id, 'cancelled')}
                                  className="px-2.5 py-1.5 bg-rose-50 text-rose-700 hover:bg-rose-100 font-bold text-xs rounded-lg cursor-pointer"
                                >
                                  Reject
                                </button>
                              </div>
                            )}

                            {order.status === 'accepted' && (
                              <button
                                onClick={() => updateOrderStatus(order.id, 'packing')}
                                className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg cursor-pointer"
                              >
                                Start Packing Items
                              </button>
                            )}

                            {order.status === 'packing' && (
                              <button
                                onClick={() => updateOrderStatus(order.id, 'out_for_delivery')}
                                className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg cursor-pointer"
                              >
                                Send with Delivery Boy 🚀
                              </button>
                            )}

                            {isOut && (
                              <div className="space-y-1.5">
                                <div className="p-2 bg-slate-900 text-white rounded-lg flex items-center justify-between text-[11px]">
                                  <span>Out with In-House Rider</span>
                                  <span className="font-mono text-amber-300 font-bold">
                                    OTP: {order.deliveryOtp}
                                  </span>
                                </div>
                                <button
                                  onClick={() => updateOrderStatus(order.id, 'delivered')}
                                  className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg cursor-pointer"
                                >
                                  Confirm Delivered (OTP Verified)
                                </button>
                              </div>
                            )}

                            {isDelivered && (
                              <div className="text-center text-xs font-bold text-emerald-700 bg-emerald-50 py-1.5 rounded-lg border border-emerald-200">
                                ✓ Successfully Delivered
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 7: POS BILLING (DUAL BARCODE SCANNER) */}
          {activeTab === 'pos_billing' && (
            !store ? (
              <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center space-y-4 max-w-md mx-auto">
                <Store className="w-10 h-10 text-slate-300 mx-auto" />
                <h3 className="font-bold text-sm text-slate-800">Supermarket Required</h3>
                <p className="text-xs text-slate-500">
                  Register and activate your supermarket to start POS counter billing.
                </p>
                <button
                  onClick={() => setActiveTab('create_supermarket')}
                  className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl cursor-pointer"
                >
                  Go to Create Supermarket
                </button>
              </div>
            ) : (
              <PosBillingPanel store={store} storeProducts={storeProducts} />
            )
          )}

          {/* TAB 8: SALES REPORTS */}
          {activeTab === 'sales_reports' && (
            <div className="space-y-6 animate-in fade-in-50 duration-150">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
                <h2 className="text-xl font-black text-slate-900 tracking-tight">
                  Sales Reports & Business Analytics
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Revenue and grocery performance metrics for {store?.apartmentName || 'your supermarket'}.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <span className="text-slate-500 text-xs font-bold block">Today's Revenue</span>
                  <h3 className="text-2xl font-black text-slate-900 mt-1">₹{todaySales}</h3>
                  <p className="text-[11px] text-emerald-600 font-semibold mt-1">
                    {todayOrders.length} orders fulfilled today
                  </p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <span className="text-slate-500 text-xs font-bold block">Weekly Revenue</span>
                  <h3 className="text-2xl font-black text-slate-900 mt-1">₹{todaySales + 8420}</h3>
                  <p className="text-[11px] text-slate-400 mt-1">Last 7 days</p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
                  <span className="text-slate-500 text-xs font-bold block">All-Time Supermarket Sales</span>
                  <h3 className="text-2xl font-black text-slate-900 mt-1">₹{totalSales + 24800}</h3>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Exclusively from {store?.apartmentName || 'apartment'} residents
                  </p>
                </div>
              </div>

              {/* Order Transaction Table */}
              <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
                <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="font-bold text-xs text-slate-900">Completed Order Records</h3>
                  <span className="text-[11px] text-slate-400">{completedOrders.length} delivered</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                      <tr>
                        <th className="p-3.5">Order ID</th>
                        <th className="p-3.5">Customer & Flat</th>
                        <th className="p-3.5">Items</th>
                        <th className="p-3.5">Payment</th>
                        <th className="p-3.5 text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {storeOrders.map((o) => (
                        <tr key={o.id} className="hover:bg-slate-50">
                          <td className="p-3.5 font-bold text-slate-900">#{o.id}</td>
                          <td className="p-3.5">
                            <div>{o.customerName}</div>
                            <div className="text-[11px] text-slate-400">{o.deliveryAddress}</div>
                          </td>
                          <td className="p-3.5">{o.itemCount} items</td>
                          <td className="p-3.5 font-semibold text-emerald-700 capitalize">
                            {o.paymentMethod} • {o.paymentStatus}
                          </td>
                          <td className="p-3.5 text-right font-black text-slate-900">₹{o.totalAmount}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 8: SUBSCRIPTION – ₹199/MONTH */}
          {activeTab === 'subscription' && (
            <div className="space-y-6 animate-in fade-in-50 duration-150">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
                <h2 className="text-xl font-black text-slate-900 tracking-tight">
                  Supermarket Owner Subscription
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Platform fee guaranteeing single active supermarket exclusivity in your assigned residential apartment.
                </p>
              </div>

              <div className="bg-gradient-to-br from-emerald-950 via-slate-900 to-emerald-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-6 max-w-2xl">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] uppercase tracking-wider font-extrabold text-emerald-300 flex items-center gap-1.5">
                    <Award className="w-4 h-4 text-emerald-400" />
                    Single-Store Exclusive Plan
                  </span>
                  <span className="bg-emerald-500/20 text-emerald-300 text-xs font-bold px-3 py-1 rounded-full border border-emerald-400/30 uppercase">
                    Status: {store?.subscriptionStatus.toUpperCase() || 'INACTIVE'}
                  </span>
                </div>

                <div>
                  <h3 className="text-3xl sm:text-4xl font-black text-white">₹199 / Month</h3>
                  <p className="text-xs text-emerald-100 mt-1">
                    Guarantees 100% exclusivity as the single authorized grocery partner for{' '}
                    <strong className="underline text-white">{store?.apartmentName || 'your assigned society'}</strong>.
                  </p>
                </div>

                <div className="bg-white/10 p-4 rounded-2xl border border-white/15 grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400 text-[11px] block">Current Plan Validity</span>
                    <span className="font-bold text-white text-sm">
                      {store?.subscriptionExpiresAt
                        ? new Date(store.subscriptionExpiresAt).toLocaleDateString('en-IN', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                          })
                        : 'Active 30 Days'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[11px] block">Target Community</span>
                    <span className="font-bold text-white text-sm">
                      {store?.apartmentName || 'Verified Apartment'}
                    </span>
                  </div>
                </div>

                <div className="space-y-2 text-xs text-emerald-200">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>No competitor grocery stores inside the apartment.</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Customer orders sent exclusively to your store inventory.</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>In-house delivery management for fast 10-15m fulfillment.</span>
                  </div>
                </div>

                <button
                  disabled={isPayingSub || !store}
                  onClick={handleRenewSubscription}
                  className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-black text-sm rounded-2xl shadow-lg transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>{isPayingSub ? 'Processing ₹199 Renewal...' : 'Pay / Renew ₹199 Monthly Subscription'}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 9: MY PROFILE */}
          {activeTab === 'my_profile' && (
            <div className="space-y-6 animate-in fade-in-50 duration-150">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
                <h2 className="text-xl font-black text-slate-900 tracking-tight">
                  Supermarket Owner Profile
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Verified account details and credentials for Super Express platform.
                </p>
              </div>

              {profileSaved && (
                <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-2xl text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Profile details updated successfully!</span>
                </div>
              )}

              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs max-w-xl space-y-4 text-xs">
                <div className="flex items-center gap-4 pb-4 border-b border-slate-100">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black text-xl shadow-md">
                    {ownerUser.name[0] || 'O'}
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base text-slate-900">{ownerUser.name}</h3>
                    <p className="text-slate-500">{ownerUser.phone}</p>
                    <span className="inline-flex items-center gap-1 mt-1 text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md">
                      <UserCheck className="w-3 h-3 text-emerald-600" /> Verified Store Owner
                    </span>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-slate-700 font-bold block mb-1">Full Name</label>
                    <input
                      type="text"
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none font-semibold"
                    />
                  </div>

                  <div>
                    <label className="text-slate-700 font-bold block mb-1">Registered Mobile Number (OTP)</label>
                    <input
                      type="text"
                      disabled
                      value={ownerUser.phone}
                      className="w-full bg-slate-100 border border-slate-200 rounded-xl p-2.5 text-slate-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-slate-700 font-bold block mb-1">Email Address</label>
                    <input
                      type="email"
                      value={profileEmail}
                      onChange={(e) => setProfileEmail(e.target.value)}
                      placeholder="owner@example.com"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-slate-700 font-bold block mb-1">Registered Supermarket</label>
                    <input
                      type="text"
                      disabled
                      value={store ? `${store.name} (${store.apartmentName})` : 'None registered yet'}
                      className="w-full bg-slate-100 border border-slate-200 rounded-xl p-2.5 text-slate-600 font-semibold"
                    />
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
                  <button
                    onClick={() => {
                      setProfileSaved(true);
                      setTimeout(() => setProfileSaved(false), 3000);
                    }}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer"
                  >
                    Save Changes
                  </button>

                  <button
                    onClick={logoutOwner}
                    className="text-xs text-rose-600 hover:underline font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" /> Logout from this device
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Delivery Boy Add Modal */}
      {isAddBoyOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150">
            <h3 className="font-black text-sm text-slate-900 mb-3">Add In-House Delivery Rider</h3>
            <form onSubmit={handleAddDeliveryBoySubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-600 font-bold block mb-1">Rider Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Kumar"
                  value={boyName}
                  onChange={(e) => setBoyName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none font-semibold"
                />
              </div>
              <div>
                <label className="text-slate-600 font-bold block mb-1">Mobile Number</label>
                <input
                  type="tel"
                  required
                  placeholder="10-digit mobile"
                  value={boyPhone}
                  onChange={(e) => setBoyPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none font-semibold"
                />
              </div>
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddBoyOpen(false)}
                  className="flex-1 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl cursor-pointer"
                >
                  Add Rider
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Product Modal */}
      {isAddProductOpen && store && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 my-8 animate-in zoom-in-95 duration-150">
            <h3 className="font-black text-base text-slate-900 mb-4">
              {editingProduct ? 'Edit Grocery Product' : 'Add New Grocery Product'}
            </h3>

            <form onSubmit={handleSaveProduct} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-600 font-bold block mb-1">Product Title</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Fresh Farm Spinach (Palak)"
                    value={formName}
                    onChange={(e) => {
                      touchedFieldsRef.current.name = e.target.value.trim().length > 0;
                      setFormName(e.target.value);
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none focus:border-emerald-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="text-slate-600 font-bold block mb-1">Brand (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. Amul, Tata, Ferrero"
                    value={formBrand}
                    onChange={(e) => {
                      touchedFieldsRef.current.brand = e.target.value.trim().length > 0;
                      setFormBrand(e.target.value);
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none focus:border-emerald-500 font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-600 font-bold block mb-1">Category</label>
                  <select
                    value={formCategory}
                    onChange={(e) => {
                      touchedFieldsRef.current.category = true;
                      setFormCategory(e.target.value);
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none font-medium"
                  >
                    <option value="cat-vegetables">Vegetables & Fruits</option>
                    <option value="cat-dairy">Dairy, Bread & Eggs</option>
                    <option value="cat-snacks">Snacks & Munchies</option>
                    <option value="cat-beverages">Cold Drinks & Juices</option>
                    <option value="cat-staples">Atta, Rice & Dal</option>
                    <option value="cat-cleaning">Household & Cleaning</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-600 font-bold block mb-1">Packaging / Unit</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 500 g or 1 kg"
                    value={formUnit}
                    onChange={(e) => {
                      touchedFieldsRef.current.unit = e.target.value.trim().length > 0;
                      setFormUnit(e.target.value);
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-slate-600 font-bold block mb-1">Selling Price (₹)</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={formPrice}
                    onChange={(e) => setFormPrice(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none font-black text-emerald-800"
                  />
                </div>
                <div>
                  <label className="text-slate-600 font-bold block mb-1">MRP (₹)</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={formMrp}
                    onChange={(e) => setFormMrp(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none text-slate-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="text-slate-600 font-bold block mb-1">Stock Units</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={formStock}
                    onChange={(e) => setFormStock(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 outline-none font-bold"
                  />
                </div>
              </div>

              {/* Barcode & Aliases */}
              <div className="space-y-2 p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <div>
                  <label className="text-slate-600 font-bold block mb-1">
                    Barcode (EAN-13 / EAN-8 / UPC / Code 128)
                  </label>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      placeholder="Scan or enter barcode (optional)"
                      value={formBarcode}
                      onChange={(e) => {
                        const nextVal = e.target.value;
                        setFormBarcode(nextVal);
                        setProductFormError('');
                        if (nextVal.trim() !== lastLookedUpBarcodeRef.current) {
                          lastLookedUpBarcodeRef.current = '';
                          setBarcodeLookupStatus({ type: 'idle' });
                        }
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          void handleBarcodeLookup(formBarcode);
                        } else if (e.key === 'Tab' && formBarcode.trim()) {
                          void handleBarcodeLookup(formBarcode);
                        }
                      }}
                      className="flex-1 bg-white border border-slate-200 rounded-xl p-2 outline-none focus:border-emerald-500 font-mono font-bold text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => void handleBarcodeLookup(formBarcode, true)}
                      disabled={isLookingUpBarcode || !formBarcode.trim()}
                      className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer shrink-0"
                      title="Lookup product details on Open Food Facts"
                    >
                      {isLookingUpBarcode ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Search className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsBarcodeScannerOpen(true)}
                      className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer shrink-0"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>Scan</span>
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-slate-600 font-bold block mb-1">
                    Barcode Aliases (comma-separated)
                  </label>
                  <input
                    type="text"
                    placeholder="Optional secondary barcodes"
                    value={formBarcodeAliases}
                    onChange={(e) => {
                      setFormBarcodeAliases(e.target.value);
                      setProductFormError('');
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') e.preventDefault();
                    }}
                    className="w-full bg-white border border-slate-200 rounded-xl p-2 outline-none focus:border-emerald-500 font-mono text-xs"
                  />
                </div>
                {barcodeLookupStatus.type !== 'idle' && (
                  <div
                    className={`p-2 rounded-xl border text-[11px] font-semibold flex items-center gap-2 ${
                      barcodeLookupStatus.type === 'loading'
                        ? 'bg-sky-50 border-sky-200 text-sky-800'
                        : barcodeLookupStatus.type === 'found'
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        : barcodeLookupStatus.type === 'not_found'
                        ? 'bg-amber-50 border-amber-200 text-amber-900'
                        : 'bg-rose-50 border-rose-200 text-rose-800'
                    }`}
                  >
                    {barcodeLookupStatus.type === 'loading' ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
                    ) : barcodeLookupStatus.type === 'found' ? (
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    )}
                    <span>{barcodeLookupStatus.message}</span>
                  </div>
                )}
              </div>

              {/* Direct Image Upload from Mobile Gallery / Photo Picker */}
              <ProductImageUploader
                imageUrl={formImageUrl}
                imagePublicId={formImagePublicId}
                onImageUploaded={(result) => {
                  touchedFieldsRef.current.imageUrl = true;
                  setFormImageUrl(result.secureUrl);
                  setFormImagePublicId(result.publicId);
                }}
                onImageRemoved={() => {
                  touchedFieldsRef.current.imageUrl = false;
                  setFormImageUrl('');
                  setFormImagePublicId('');
                }}
                onUploadingChange={(uploading) => setIsProductImageUploading(uploading)}
              />

              {productFormError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold">
                  {productFormError}
                </div>
              )}

              <div className="flex gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddProductOpen(false)}
                  className="flex-1 py-2.5 text-slate-600 hover:bg-slate-100 rounded-xl font-bold cursor-pointer transition text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!formImageUrl || isProductImageUploading || isSavingProduct}
                  className={`flex-2 py-2.5 rounded-xl font-bold transition flex items-center justify-center gap-1.5 text-xs ${
                    !formImageUrl || isProductImageUploading || isSavingProduct
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      : 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer active:scale-98 shadow-sm'
                  }`}
                >
                  {isSavingProduct ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : isProductImageUploading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Uploading Image...</span>
                    </>
                  ) : !formImageUrl ? (
                    'Photo Required'
                  ) : editingProduct ? (
                    'Save Changes'
                  ) : (
                    'Publish Product'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Real-Time Live Order Alert Modal (Plays loud repeating beep until action) */}
      {unhandledPlacedOrders.length > 0 && (
        <NewOrderAlertModal
          orders={unhandledPlacedOrders}
          onAccept={handleAcceptOrder}
          onReject={handleRejectOrder}
          onAcknowledge={handleAcknowledgeAlert}
          isSoundMuted={isSoundMuted}
          onToggleSound={() => {
            const nextMuted = !isSoundMuted;
            setIsSoundMuted(nextMuted);
            if (nextMuted) stopOrderAlarmSound();
            else startOrderAlarmSound();
          }}
        />
      )}

      {/* Test Order Notification Modal (Requirement 10) */}
      {testOrderModalOpen && (
        <NewOrderAlertModal
          orders={[demoTestOrder]}
          onAccept={async () => {
            stopOrderAlarmSound();
            setTestOrderModalOpen(false);
          }}
          onReject={async () => {
            stopOrderAlarmSound();
            setTestOrderModalOpen(false);
          }}
          onAcknowledge={() => {
            stopOrderAlarmSound();
            setTestOrderModalOpen(false);
          }}
          isSoundMuted={isSoundMuted}
          onToggleSound={() => {
            const nextMuted = !isSoundMuted;
            setIsSoundMuted(nextMuted);
            if (nextMuted) stopOrderAlarmSound();
            else startOrderAlarmSound();
          }}
        />
      )}

      {/* Single-Shot Camera Barcode Scanner for Product Create/Edit Forms */}
      <CameraBarcodeScanner
        isOpen={isBarcodeScannerOpen}
        onClose={() => setIsBarcodeScannerOpen(false)}
        onDetected={(code) => {
          setFormBarcode(code);
          setProductFormError('');
          setIsBarcodeScannerOpen(false);
          void handleBarcodeLookup(code);
        }}
        continuous={false}
        title="Scan Product Barcode to Assign"
      />
    </div>
  );
};
