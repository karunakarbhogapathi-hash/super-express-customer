package com.superexpress.customer

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SuperExpressCustomerApp : Application() {

    val firebaseApp: FirebaseApp by lazy {
        FirebaseApp.getApps(this).firstOrNull()
            ?: FirebaseApp.initializeApp(
                this,
                FirebaseOptions.Builder()
                    .setProjectId(BuildConfig.FIREBASE_PROJECT_ID)
                    .setApiKey(BuildConfig.FIREBASE_API_KEY)
                    .setApplicationId(BuildConfig.FIREBASE_APP_ID)
                    .setStorageBucket(BuildConfig.FIREBASE_STORAGE_BUCKET)
                    .setGcmSenderId(BuildConfig.FIREBASE_MESSAGING_SENDER_ID)
                    .build()
            )
    }

    val firebaseAuth: FirebaseAuth by lazy {
        FirebaseAuth.getInstance(firebaseApp)
    }

    val firestore: FirebaseFirestore by lazy {
        FirebaseFirestore.getInstance(firebaseApp, BuildConfig.FIRESTORE_DATABASE_ID)
    }

    override fun onCreate() {
        super.onCreate()
        firebaseApp
    }
}
