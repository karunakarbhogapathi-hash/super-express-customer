import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Zap,
  MapPin,
  Search,
  Bell,
  User,
  ShoppingBag,
  ChevronDown,
  Building2,
  CheckCircle2,
  X,
} from 'lucide-react';

interface HeaderProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  openCart: () => void;
  openNotifications: () => void;
  openProfile: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  searchQuery,
  setSearchQuery,
  openCart,
  openNotifications,
  openProfile,
}) => {
  const {
    role,
    activeApartment,
    activeStore,
    apartments,
    selectApartment,
    cartCount,
    cartTotal,
    currentUser,
    notifications,
  } = useApp();

  const [isApartmentModalOpen, setIsApartmentModalOpen] = useState(false);

  const unreadNotifs = notifications.filter((n) => !n.isRead).length;

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-emerald-100 shadow-xs">
      {/* Top Banner / Apartment Selector Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 cursor-pointer">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-700 via-emerald-600 to-green-500 flex items-center justify-center text-white shadow-md shadow-emerald-700/20">
              <Zap className="w-5 h-5 fill-white text-yellow-300" />
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="font-extrabold text-lg tracking-tight text-emerald-950 font-display">
                  SUPER<span className="text-emerald-600">EXPRESS</span>
                </span>
                <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-1.5 py-0.5 rounded-full border border-amber-300">
                  APARTMENT
                </span>
              </div>
              <p className="text-[10px] text-emerald-700 font-medium -mt-1 hidden sm:block">
                Exclusive Single Store Society Delivery
              </p>
            </div>
          </div>

          {/* Customer's Verified Apartment Badge & Selector */}
          {role === 'customer' && (
            <button
              onClick={() => setIsApartmentModalOpen(true)}
              className="hidden md:flex items-center gap-2 bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 text-emerald-950 px-3 py-1.5 rounded-xl transition-all cursor-pointer text-left"
            >
              <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                <MapPin className="w-4 h-4" />
              </div>
              <div className="leading-tight">
                <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-800">
                  <span>⚡ 10-15 MINS</span>
                  <span className="text-slate-400">•</span>
                  <span>{currentUser.block || 'Tower B'} - Flat {currentUser.flatNumber || '402'}</span>
                </div>
                <div className="text-xs font-semibold text-slate-800 truncate max-w-[210px] flex items-center gap-1">
                  <span>{activeApartment?.name || 'Select Apartment'}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                </div>
              </div>
            </button>
          )}
        </div>

        {/* Search Bar (Customer View) */}
        {role === 'customer' && (
          <div className="flex-1 max-w-md hidden lg:block">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-600" />
              <input
                type="text"
                placeholder={`Search milk, tomatoes, bread in ${activeStore?.name || 'store'}...`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-900 text-xs sm:text-sm pl-9 pr-4 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
              />
            </div>
          </div>
        )}

        {/* Right Action Icons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Notification Bell */}
          <button
            onClick={openNotifications}
            className="relative p-2 rounded-xl text-slate-700 hover:bg-slate-100 hover:text-emerald-700 transition cursor-pointer"
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotifs > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center animate-bounce">
                {unreadNotifs}
              </span>
            )}
          </button>

          {/* User Profile */}
          <button
            onClick={openProfile}
            className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl text-slate-700 hover:bg-slate-100 transition cursor-pointer border border-transparent hover:border-slate-200"
          >
            <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
              {currentUser.name ? currentUser.name[0] : <User className="w-4 h-4" />}
            </div>
            <span className="text-xs font-semibold text-slate-800 hidden sm:inline max-w-[100px] truncate">
              {currentUser.name.split(' ')[0]}
            </span>
          </button>

          {/* Quick Cart Button (Customer View) */}
          {role === 'customer' && (
            <button
              onClick={openCart}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-3 sm:px-4 py-2 rounded-xl font-bold text-xs sm:text-sm shadow-md shadow-emerald-600/20 transition-all cursor-pointer transform active:scale-95"
            >
              <div className="relative">
                <ShoppingBag className="w-4 h-4" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-yellow-400 text-emerald-950 text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline">₹{cartTotal}</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile Location Header for Customer */}
      {role === 'customer' && (
        <div className="md:hidden border-t border-slate-100 px-4 py-2 bg-emerald-50/70 flex items-center justify-between text-xs">
          <button
            onClick={() => setIsApartmentModalOpen(true)}
            className="flex items-center gap-2 text-slate-800 text-left font-medium truncate"
          >
            <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span className="truncate font-semibold text-emerald-950">
              {activeApartment?.name || 'Select Apartment'}
            </span>
            <span className="text-slate-400">•</span>
            <span className="text-slate-600 shrink-0">Flat {currentUser.flatNumber || '402'}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </button>
          <span className="text-[10px] font-bold text-emerald-700 bg-white px-2 py-0.5 rounded-full border border-emerald-200 shrink-0">
            ⚡ 10-15m
          </span>
        </div>
      )}

      {/* Apartment Switcher / Selection Modal */}
      {isApartmentModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-emerald-900 text-white">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-300" />
                <div>
                  <h3 className="font-bold text-sm">Select Your Apartment Community</h3>
                  <p className="text-[11px] text-emerald-200">
                    Single supermarket assigned per residential society
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsApartmentModalOpen(false)}
                className="text-white/80 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 space-y-3 max-h-[70vh] overflow-y-auto">
              {apartments.map((apt) => {
                const isSelected = apt.id === activeApartment?.id;
                return (
                  <div
                    key={apt.id}
                    onClick={() => {
                      selectApartment(apt.id);
                      setIsApartmentModalOpen(false);
                    }}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                        : 'border-slate-200 hover:border-emerald-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-bold text-sm text-slate-900">{apt.name}</h4>
                          {isSelected && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          )}
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">{apt.address}</p>
                        <div className="flex items-center gap-2 mt-2 text-[11px]">
                          <span className="text-slate-600 font-medium">
                            {apt.totalTowers} Towers • {apt.totalFlats} Flats
                          </span>
                          <span className="text-slate-300">|</span>
                          <span className="inline-flex items-center gap-1 text-emerald-800 font-semibold bg-emerald-100/70 px-2 py-0.5 rounded">
                            Store: {apt.activeStoreName || 'Supermarket Assigned'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
              <p className="text-xs text-slate-500">
                🔒 Business Rule: Customers can only order from their apartment's assigned store.
              </p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
