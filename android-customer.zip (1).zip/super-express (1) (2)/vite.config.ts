import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import {defineConfig} from 'vite';

function readDotEnvFile(): Record<string, string> {
  try {
    const raw = fs.readFileSync(path.resolve(__dirname, '.env'), 'utf8');
    const out: Record<string, string> = {};
    for (const line of raw.split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eq = trimmed.indexOf('=');
      if (eq === -1) continue;
      const key = trimmed.slice(0, eq).trim();
      let val = trimmed.slice(eq + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      out[key] = val;
    }
    return out;
  } catch {
    return {};
  }
}

export default defineConfig(() => {
  const dotEnv = readDotEnvFile();
  const rawCloudName = (process.env.VITE_CLOUDINARY_CLOUD_NAME || '').trim();
  const resolvedCloudName =
    !rawCloudName || rawCloudName.startsWith('VITE_') || rawCloudName === 'your_cloudinary_cloud_name'
      ? (dotEnv.VITE_CLOUDINARY_CLOUD_NAME || '').trim()
      : rawCloudName;
  const rawPreset = (process.env.VITE_CLOUDINARY_UPLOAD_PRESET || '').trim();
  const resolvedPreset =
    !rawPreset || rawPreset.startsWith('VITE_') || rawPreset === 'your_unsigned_upload_preset'
      ? (dotEnv.VITE_CLOUDINARY_UPLOAD_PRESET || '').trim()
      : rawPreset;

  return {
    plugins: [
      react(),
      tailwindcss(),
      {
        name: 'super-express-cloudinary-config',
        transformIndexHtml() {
          return [
            {
              tag: 'script',
              injectTo: 'head-prepend',
              children: `window.__CLOUDINARY_CONFIG__ = ${JSON.stringify({
                cloudName: resolvedCloudName,
                uploadPreset: resolvedPreset,
              })};`,
            },
          ];
        },
      },
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
