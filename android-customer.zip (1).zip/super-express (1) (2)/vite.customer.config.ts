import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';

const rootDir = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  base: './',
  plugins: [
    react(),
    tailwindcss(),
    {
      name: 'customer-html-entry',
      closeBundle() {
        const outDir = path.resolve(rootDir, 'dist-customer');
        const builtHtml = path.join(outDir, 'customer.html');
        const indexHtml = path.join(outDir, 'index.html');
        if (fs.existsSync(builtHtml)) {
          fs.renameSync(builtHtml, indexHtml);
        }
      },
    },
  ],
  build: {
    outDir: 'dist-customer',
    emptyOutDir: true,
    rollupOptions: {
      input: path.resolve(rootDir, 'customer.html'),
    },
  },
  resolve: {
    alias: {
      '@': path.resolve(rootDir, '.'),
    },
  },
});
