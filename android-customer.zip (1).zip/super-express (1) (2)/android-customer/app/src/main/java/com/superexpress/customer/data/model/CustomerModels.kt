package com.superexpress.customer.data.model

data class CustomerProfile(
    val id: String = "",
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val role: String = "customer",
    val apartmentId: String = "",
    val apartmentName: String = "",
    val block: String = "Tower A",
    val flatNumber: String = "101",
    val isVerified: Boolean = true,
    val createdAt: String = "",
    val updatedAt: String = ""
)

data class Apartment(
    val id: String = "",
    val name: String = "",
    val address: String = "",
    val city: String = "",
    val pincode: String = "",
    val totalTowers: Int = 0,
    val totalFlats: Int = 0,
    val activeStoreId: String? = null,
    val activeStoreName: String? = null,
    val status: String = "active",
    val createdAt: String = ""
)

data class Store(
    val id: String = "",
    val name: String = "",
    val ownerId: String = "",
    val ownerName: String = "",
    val ownerPhone: String = "",
    val apartmentId: String = "",
    val apartmentName: String = "",
    val address: String = "",
    val description: String = "",
    val logoUrl: String = "",
    val status: String = "active",
    val openingTime: String = "07:00 AM",
    val closingTime: String = "10:30 PM",
    val deliveryTimeMinutes: Int = 15,
    val minOrderAmount: Int = 99,
    val rating: Double = 4.8,
    val totalOrders: Int = 0
)

data class Category(
    val id: String = "",
    val name: String = "",
    val imageUrl: String = "",
    val sortOrder: Int = 0,
    val isActive: Boolean = true
)

data class Product(
    val id: String = "",
    val storeId: String = "",
    val apartmentId: String = "",
    val name: String = "",
    val brand: String = "",
    val description: String = "",
    val category: String = "",
    val imageUrl: String = "",
    val price: Double = 0.0,
    val mrp: Double = 0.0,
    val unit: String = "",
    val inStock: Boolean = true,
    val stockCount: Int = 0,
    val barcode: String = "",
    val isPopular: Boolean = false,
    val createdAt: String = ""
) {
    val discountPercent: Int
        get() = if (mrp > price && mrp > 0.0) {
            (((mrp - price) / mrp) * 100).toInt()
        } else 0

    val isAvailable: Boolean
        get() = inStock && stockCount > 0
}

data class CartItem(
    val product: Product,
    val quantity: Int
) {
    val lineTotal: Double
        get() = product.price * quantity
}

data class OrderItem(
    val id: String = "",
    val orderId: String = "",
    val productId: String = "",
    val name: String = "",
    val imageUrl: String = "",
    val unit: String = "",
    val unitPrice: Double = 0.0,
    val mrp: Double = 0.0,
    val quantity: Int = 1,
    val totalPrice: Double = 0.0
)

data class Order(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val apartmentId: String = "",
    val apartmentName: String = "",
    val deliveryAddress: String = "",
    val storeId: String = "",
    val storeName: String = "",
    val status: String = "placed",
    val paymentMethod: String = "ONLINE",
    val paymentStatus: String = "pending",
    val transactionId: String = "",
    val subtotal: Double = 0.0,
    val deliveryFee: Double = 0.0,
    val handlingFee: Double = 5.0,
    val totalAmount: Double = 0.0,
    val itemCount: Int = 0,
    val deliveryOtp: String = "",
    val items: List<OrderItem> = emptyList(),
    val createdAt: String = "",
    val updatedAt: String = ""
)
