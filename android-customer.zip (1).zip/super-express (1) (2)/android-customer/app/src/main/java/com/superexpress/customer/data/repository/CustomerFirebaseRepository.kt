package com.superexpress.customer.data.repository

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import com.superexpress.customer.data.SeedCatalog
import com.superexpress.customer.data.model.Apartment
import com.superexpress.customer.data.model.CartItem
import com.superexpress.customer.data.model.CustomerProfile
import com.superexpress.customer.data.model.Order
import com.superexpress.customer.data.model.OrderItem
import com.superexpress.customer.data.model.Product
import com.superexpress.customer.data.model.Store
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.random.Random

class CustomerFirebaseRepository(
    private val auth: FirebaseAuth,
    private val db: FirebaseFirestore
) {
    private val tag = "CustomerFirebaseRepo"

    private fun isoNow(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }

    suspend fun testFirestoreConnection() {
        try {
            db.collection("test").document("connection").get(Source.SERVER).await()
        } catch (e: Exception) {
            val msg = e.message ?: ""
            if (msg.contains("offline", ignoreCase = true)) {
                Log.e(tag, "Firestore client is offline. Check Firebase configuration.")
            } else {
                Log.d(tag, "Firestore connection probe completed: ${e.message}")
            }
        }
    }

    fun observeAuthUser(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        trySend(auth.currentUser)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    suspend fun loginWithEmail(email: String, password: String): CustomerProfile {
        val cleanEmail = email.trim()
        val result = auth.signInWithEmailAndPassword(cleanEmail, password).await()
        val fbUser = result.user ?: throw IllegalStateException("Authentication failed.")
        return loadOrCreateCustomerProfile(fbUser)
    }

    suspend fun registerCustomer(
        name: String,
        phone: String,
        email: String,
        password: String,
        apartmentId: String,
        block: String,
        flatNumber: String
    ): CustomerProfile {
        val cleanEmail = email.trim()
        val cleanName = name.trim()
        val cleanPhone = phone.trim().take(20)
        val result = auth.createUserWithEmailAndPassword(cleanEmail, password).await()
        val fbUser = result.user ?: throw IllegalStateException("Registration failed.")

        try {
            fbUser.updateProfile(
                UserProfileChangeRequest.Builder()
                    .setDisplayName(cleanName)
                    .build()
            ).await()
        } catch (_: Exception) {
        }

        val now = isoNow()
        val userMap = hashMapOf<String, Any>(
            "id" to fbUser.uid,
            "phone" to cleanPhone,
            "name" to cleanName,
            "email" to (fbUser.email ?: cleanEmail),
            "role" to "customer",
            "apartmentId" to apartmentId,
            "flatNumber" to flatNumber.trim().ifEmpty { "101" },
            "block" to block.trim().ifEmpty { "Tower A" },
            "isVerified" to true,
            "createdAt" to now,
            "updatedAt" to now
        )

        try {
            db.collection("users").document(fbUser.uid).set(userMap).await()
        } catch (e: Exception) {
            handleFirestoreError(e, "create", "users/${fbUser.uid}")
            throw e
        }

        val aptName = SeedCatalog.apartments.find { it.id == apartmentId }?.name ?: ""
        return CustomerProfile(
            id = fbUser.uid,
            name = cleanName,
            phone = cleanPhone,
            email = fbUser.email ?: cleanEmail,
            role = "customer",
            apartmentId = apartmentId,
            apartmentName = aptName,
            block = block.trim().ifEmpty { "Tower A" },
            flatNumber = flatNumber.trim().ifEmpty { "101" },
            isVerified = true,
            createdAt = now,
            updatedAt = now
        )
    }

    suspend fun loadOrCreateCustomerProfile(fbUser: FirebaseUser): CustomerProfile {
        val docRef = db.collection("users").document(fbUser.uid)
        val snap = try {
            docRef.get().await()
        } catch (e: Exception) {
            handleFirestoreError(e, "get", "users/${fbUser.uid}")
            throw e
        }

        if (snap.exists()) {
            val role = snap.getString("role") ?: "customer"
            if (role != "customer") {
                auth.signOut()
                throw IllegalStateException(
                    "This account is registered as \"$role\". Please sign in with a Customer account."
                )
            }
            val aptId = snap.getString("apartmentId") ?: SeedCatalog.apartments.first().id
            return CustomerProfile(
                id = fbUser.uid,
                name = snap.getString("name") ?: fbUser.displayName ?: "Customer",
                phone = snap.getString("phone") ?: "+91 90000 00000",
                email = snap.getString("email") ?: fbUser.email ?: "",
                role = "customer",
                apartmentId = aptId,
                apartmentName = SeedCatalog.apartments.find { it.id == aptId }?.name ?: "",
                block = snap.getString("block") ?: "Tower A",
                flatNumber = snap.getString("flatNumber") ?: "101",
                isVerified = snap.getBoolean("isVerified") ?: true,
                createdAt = snap.getString("createdAt") ?: isoNow(),
                updatedAt = snap.getString("updatedAt") ?: ""
            )
        } else {
            val defaultApt = SeedCatalog.apartments.first()
            val now = isoNow()
            val newDoc = hashMapOf<String, Any>(
                "id" to fbUser.uid,
                "phone" to (fbUser.phoneNumber ?: "+91 90000 00000"),
                "name" to (fbUser.displayName ?: fbUser.email?.substringBefore("@") ?: "Customer"),
                "email" to (fbUser.email ?: ""),
                "role" to "customer",
                "apartmentId" to defaultApt.id,
                "flatNumber" to "101",
                "block" to "Tower A",
                "isVerified" to true,
                "createdAt" to now,
                "updatedAt" to now
            )
            try {
                docRef.set(newDoc).await()
            } catch (e: Exception) {
                handleFirestoreError(e, "create", "users/${fbUser.uid}")
                throw e
            }
            return CustomerProfile(
                id = fbUser.uid,
                name = newDoc["name"] as String,
                phone = newDoc["phone"] as String,
                email = newDoc["email"] as String,
                role = "customer",
                apartmentId = defaultApt.id,
                apartmentName = defaultApt.name,
                block = "Tower A",
                flatNumber = "101",
                isVerified = true,
                createdAt = now,
                updatedAt = now
            )
        }
    }

    suspend fun updateCustomerProfile(
        uid: String,
        name: String,
        phone: String,
        apartmentId: String,
        block: String,
        flatNumber: String
    ) {
        val updates = hashMapOf<String, Any>(
            "name" to name.trim(),
            "phone" to phone.trim().take(20),
            "apartmentId" to apartmentId,
            "block" to block.trim(),
            "flatNumber" to flatNumber.trim(),
            "updatedAt" to isoNow()
        )
        try {
            db.collection("users").document(uid).update(updates).await()
        } catch (e: Exception) {
            handleFirestoreError(e, "update", "users/$uid")
            throw e
        }
    }

    fun observeApartments(): Flow<List<Apartment>> = callbackFlow {
        val reg = db.collection("apartments").addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.w(tag, "Apartments listener warning: ${error.message}")
                return@addSnapshotListener
            }
            if (snapshot != null && !snapshot.isEmpty) {
                val merged = LinkedHashMap<String, Apartment>()
                SeedCatalog.apartments.forEach { merged[it.id] = it }
                snapshot.documents.forEach { doc ->
                    doc.toApartmentOrNull()?.let { merged[it.id] = it }
                }
                trySend(merged.values.toList())
            }
        }
        trySend(SeedCatalog.apartments)
        awaitClose { reg.remove() }
    }

    fun observeStores(): Flow<List<Store>> = callbackFlow {
        val reg = db.collection("stores").addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.w(tag, "Stores listener warning: ${error.message}")
                return@addSnapshotListener
            }
            if (snapshot != null && !snapshot.isEmpty) {
                val merged = LinkedHashMap<String, Store>()
                SeedCatalog.stores.forEach { merged[it.id] = it }
                snapshot.documents.forEach { doc ->
                    doc.toStoreOrNull()?.let { merged[it.id] = it }
                }
                trySend(merged.values.toList())
            }
        }
        trySend(SeedCatalog.stores)
        awaitClose { reg.remove() }
    }

    fun observeProducts(): Flow<List<Product>> = callbackFlow {
        val reg = db.collection("products").addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.w(tag, "Products listener warning: ${error.message}")
                return@addSnapshotListener
            }
            if (snapshot != null && !snapshot.isEmpty) {
                val merged = LinkedHashMap<String, Product>()
                SeedCatalog.products.forEach { merged[it.id] = it }
                snapshot.documents.forEach { doc ->
                    doc.toProductOrNull()?.let { merged[it.id] = it }
                }
                trySend(merged.values.toList())
            }
        }
        trySend(SeedCatalog.products)
        awaitClose { reg.remove() }
    }

    fun observeCustomerOrders(uid: String): Flow<List<Order>> = callbackFlow {
        val reg = db.collection("orders")
            .whereEqualTo("customerId", uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(tag, "Orders listener warning: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents
                        .mapNotNull { it.toOrderOrNull() }
                        .sortedByDescending { it.createdAt }
                    trySend(list)
                }
            }
        awaitClose { reg.remove() }
    }

    suspend fun placeOrder(
        profile: CustomerProfile,
        apartment: Apartment,
        store: Store,
        cart: List<CartItem>,
        paymentMethod: String,
        block: String,
        flatNumber: String
    ): Order {
        val uid = auth.currentUser?.uid ?: throw IllegalStateException("Please sign in first.")
        val subtotal = cart.sumOf { it.lineTotal }
        val deliveryFee = if (subtotal >= 199.0) 0.0 else 25.0
        val handlingFee = 5.0
        val totalAmount = subtotal + deliveryFee + handlingFee
        val orderId = "ord-${System.currentTimeMillis() % 100000}"
        val otp = Random.nextInt(1000, 9999).toString()
        val now = isoNow()
        val itemCount = cart.sumOf { it.quantity }

        val orderItems = cart.mapIndexed { idx, item ->
            OrderItem(
                id = "item-$orderId-$idx",
                orderId = orderId,
                productId = item.product.id,
                name = item.product.name,
                imageUrl = item.product.imageUrl,
                unit = item.product.unit,
                unitPrice = item.product.price,
                mrp = item.product.mrp,
                quantity = item.quantity,
                totalPrice = item.lineTotal
            )
        }

        val deliveryAddress = "${block.trim()}, Flat ${flatNumber.trim()}, ${apartment.name}, ${apartment.address}"
        val order = Order(
            id = orderId,
            customerId = uid,
            customerName = profile.name,
            customerPhone = profile.phone,
            apartmentId = apartment.id,
            apartmentName = apartment.name,
            deliveryAddress = deliveryAddress,
            storeId = store.id,
            storeName = store.name,
            status = "placed",
            paymentMethod = paymentMethod,
            paymentStatus = "pending",
            subtotal = subtotal,
            deliveryFee = deliveryFee,
            handlingFee = handlingFee,
            totalAmount = totalAmount,
            itemCount = itemCount,
            deliveryOtp = otp,
            items = orderItems,
            createdAt = now,
            updatedAt = now
        )

        val itemMaps = orderItems.map { oi ->
            hashMapOf<String, Any>(
                "id" to oi.id,
                "orderId" to oi.orderId,
                "productId" to oi.productId,
                "name" to oi.name,
                "imageUrl" to oi.imageUrl,
                "unit" to oi.unit,
                "unitPrice" to oi.unitPrice,
                "mrp" to oi.mrp,
                "quantity" to oi.quantity,
                "totalPrice" to oi.totalPrice
            )
        }

        val orderDoc = hashMapOf<String, Any>(
            "id" to order.id,
            "customerId" to order.customerId,
            "customerName" to order.customerName,
            "customerPhone" to order.customerPhone,
            "apartmentId" to order.apartmentId,
            "apartmentName" to order.apartmentName,
            "deliveryAddress" to order.deliveryAddress,
            "storeId" to order.storeId,
            "storeName" to order.storeName,
            "status" to order.status,
            "paymentMethod" to order.paymentMethod,
            "paymentStatus" to order.paymentStatus,
            "subtotal" to order.subtotal,
            "deliveryFee" to order.deliveryFee,
            "handlingFee" to order.handlingFee,
            "totalAmount" to order.totalAmount,
            "itemCount" to order.itemCount,
            "deliveryOtp" to order.deliveryOtp,
            "items" to itemMaps,
            "createdAt" to order.createdAt,
            "updatedAt" to order.updatedAt
        )

        try {
            db.collection("orders").document(orderId).set(orderDoc).await()
        } catch (e: Exception) {
            handleFirestoreError(e, "create", "orders/$orderId")
            throw e
        }

        return order
    }

    suspend fun verifyOnlinePayment(orderId: String): String {
        val txnId = "TXN-${Random.nextInt(10000000, 99999999)}"
        val updates = hashMapOf<String, Any>(
            "paymentStatus" to "paid",
            "transactionId" to txnId,
            "status" to "accepted",
            "updatedAt" to isoNow()
        )
        try {
            db.collection("orders").document(orderId).update(updates).await()
        } catch (e: Exception) {
            handleFirestoreError(e, "update", "orders/$orderId")
            throw e
        }
        return txnId
    }

    fun signOut() {
        auth.signOut()
    }

    fun mapAuthError(e: Exception): String {
        if (e is FirebaseAuthException) {
            return when (e.errorCode) {
                "ERROR_INVALID_CREDENTIAL", "ERROR_WRONG_PASSWORD", "ERROR_USER_NOT_FOUND" ->
                    "Invalid email or password. Please check your credentials."
                "ERROR_EMAIL_ALREADY_IN_USE" ->
                    "An account with this email already exists. Please log in instead."
                "ERROR_WEAK_PASSWORD" ->
                    "Password must be at least 6 characters long."
                "ERROR_INVALID_EMAIL" ->
                    "Please enter a valid email address."
                "ERROR_OPERATION_NOT_ALLOWED" ->
                    "Email/Password login is not enabled in Firebase Console (Authentication -> Sign-in method)."
                else -> e.localizedMessage ?: "Authentication error."
            }
        }
        return e.localizedMessage ?: "Request failed. Please check your internet connection."
    }

    private fun handleFirestoreError(error: Exception, operation: String, path: String) {
        val user = auth.currentUser
        val json = """{"error":"${error.message?.replace("\"", "'")}","operationType":"$operation","path":"$path","userId":"${user?.uid}"}"""
        Log.e(tag, "Firestore Error: $json")
    }

    private fun DocumentSnapshot.toApartmentOrNull(): Apartment? {
        val docId = getString("id") ?: id
        val name = getString("name") ?: return null
        return Apartment(
            id = docId,
            name = name,
            address = getString("address") ?: "",
            city = getString("city") ?: "",
            pincode = getString("pincode") ?: "",
            totalTowers = getLong("totalTowers")?.toInt() ?: 0,
            totalFlats = getLong("totalFlats")?.toInt() ?: 0,
            activeStoreId = getString("activeStoreId"),
            activeStoreName = getString("activeStoreName"),
            status = getString("status") ?: "active",
            createdAt = getString("createdAt") ?: ""
        )
    }

    private fun DocumentSnapshot.toStoreOrNull(): Store? {
        val docId = getString("id") ?: id
        val name = getString("name") ?: return null
        return Store(
            id = docId,
            name = name,
            ownerId = getString("ownerId") ?: "",
            ownerName = getString("ownerName") ?: "",
            ownerPhone = getString("ownerPhone") ?: "",
            apartmentId = getString("apartmentId") ?: "",
            apartmentName = getString("apartmentName") ?: "",
            address = getString("address") ?: "",
            description = getString("description") ?: "",
            logoUrl = getString("logoUrl") ?: "",
            status = getString("status") ?: "active",
            openingTime = getString("openingTime") ?: "07:00 AM",
            closingTime = getString("closingTime") ?: "10:30 PM",
            deliveryTimeMinutes = getLong("deliveryTimeMinutes")?.toInt() ?: 15,
            minOrderAmount = getLong("minOrderAmount")?.toInt() ?: 99,
            rating = getDouble("rating") ?: 4.8,
            totalOrders = getLong("totalOrders")?.toInt() ?: 0
        )
    }

    private fun DocumentSnapshot.toProductOrNull(): Product? {
        val docId = getString("id") ?: id
        val name = getString("name") ?: return null
        return Product(
            id = docId,
            storeId = getString("storeId") ?: "",
            apartmentId = getString("apartmentId") ?: "",
            name = name,
            brand = getString("brand") ?: "",
            description = getString("description") ?: "",
            category = getString("category") ?: "cat-all",
            imageUrl = getString("imageUrl") ?: "",
            price = getDouble("price") ?: (getLong("price")?.toDouble() ?: 0.0),
            mrp = getDouble("mrp") ?: (getLong("mrp")?.toDouble() ?: 0.0),
            unit = getString("unit") ?: "",
            inStock = getBoolean("inStock") ?: true,
            stockCount = getLong("stockCount")?.toInt() ?: 0,
            barcode = getString("barcode") ?: "",
            isPopular = getBoolean("isPopular") ?: false,
            createdAt = getString("createdAt") ?: ""
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun DocumentSnapshot.toOrderOrNull(): Order? {
        val docId = getString("id") ?: id
        val rawItems = get("items") as? List<Map<String, Any?>> ?: emptyList()
        val parsedItems = rawItems.map { m ->
            OrderItem(
                id = (m["id"] as? String) ?: "",
                orderId = (m["orderId"] as? String) ?: docId,
                productId = (m["productId"] as? String) ?: "",
                name = (m["name"] as? String) ?: "",
                imageUrl = (m["imageUrl"] as? String) ?: "",
                unit = (m["unit"] as? String) ?: "",
                unitPrice = (m["unitPrice"] as? Number)?.toDouble() ?: 0.0,
                mrp = (m["mrp"] as? Number)?.toDouble() ?: 0.0,
                quantity = (m["quantity"] as? Number)?.toInt() ?: 1,
                totalPrice = (m["totalPrice"] as? Number)?.toDouble() ?: 0.0
            )
        }
        return Order(
            id = docId,
            customerId = getString("customerId") ?: "",
            customerName = getString("customerName") ?: "",
            customerPhone = getString("customerPhone") ?: "",
            apartmentId = getString("apartmentId") ?: "",
            apartmentName = getString("apartmentName") ?: "",
            deliveryAddress = getString("deliveryAddress") ?: "",
            storeId = getString("storeId") ?: "",
            storeName = getString("storeName") ?: "",
            status = getString("status") ?: "placed",
            paymentMethod = getString("paymentMethod") ?: "ONLINE",
            paymentStatus = getString("paymentStatus") ?: "pending",
            transactionId = getString("transactionId") ?: "",
            subtotal = getDouble("subtotal") ?: (getLong("subtotal")?.toDouble() ?: 0.0),
            deliveryFee = getDouble("deliveryFee") ?: (getLong("deliveryFee")?.toDouble() ?: 0.0),
            handlingFee = getDouble("handlingFee") ?: (getLong("handlingFee")?.toDouble() ?: 5.0),
            totalAmount = getDouble("totalAmount") ?: (getLong("totalAmount")?.toDouble() ?: 0.0),
            itemCount = getLong("itemCount")?.toInt() ?: parsedItems.sumOf { it.quantity },
            deliveryOtp = getString("deliveryOtp") ?: "",
            items = parsedItems,
            createdAt = getString("createdAt") ?: "",
            updatedAt = getString("updatedAt") ?: ""
        )
    }
}
