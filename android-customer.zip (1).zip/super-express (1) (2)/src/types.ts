export type UserRole = 'customer' | 'store_owner' | 'delivery_partner' | 'admin';

export interface UserProfile {
  id: string;
  phone: string;
  name: string;
  email?: string;
  role: UserRole;
  apartmentId?: string;
  apartmentName?: string;
  flatNumber?: string;
  block?: string;
  isVerified: boolean;
  storeId?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Apartment {
  id: string;
  name: string;
  address: string;
  city: string;
  pincode: string;
  totalTowers: number;
  totalFlats: number;
  activeStoreId?: string;
  activeStoreName?: string;
  status: 'active' | 'pending' | 'suspended';
  createdAt: string;
}

export interface DeliveryBoy {
  id: string;
  name: string;
  phone: string;
  active: boolean;
  totalDeliveries?: number;
}

export interface Store {
  id: string;
  name: string;
  ownerId: string;
  ownerName: string;
  ownerPhone: string;
  ownerEmail?: string;
  apartmentId: string;
  apartmentName: string;
  address?: string;
  description?: string;
  logoUrl?: string;
  rejectionReason?: string;
  status: 'pending_approval' | 'active' | 'suspended' | 'rejected' | 'inactive';
  monthlyFee: number; // 199
  subscriptionStatus: 'active' | 'grace' | 'expired' | 'pending';
  subscriptionExpiresAt: string;
  openingTime: string;
  closingTime: string;
  deliveryTimeMinutes: number;
  minOrderAmount: number;
  rating: number;
  totalOrders: number;
  deliveryBoys?: DeliveryBoy[];
  createdAt: string;
  appliedAt?: string;
}

export interface Product {
  id: string;
  storeId: string;
  apartmentId: string;
  name: string;
  brand?: string;
  description: string;
  category: string;
  imageUrl: string;
  imagePublicId?: string;
  price: number;
  mrp: number;
  unit: string;
  inStock: boolean;
  stockCount: number;
  barcode?: string;
  barcodeAliases?: string[];
  isPopular?: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  imageUrl: string;
  sortOrder: number;
  isActive: boolean;
}

export type OrderStatus =
  | 'placed'
  | 'accepted'
  | 'packing'
  | 'out_for_delivery'
  | 'delivered'
  | 'rejected'
  | 'cancelled';

export type PaymentMethod = 'COD' | 'ONLINE' | 'CASH' | 'UPI' | 'CARD' | 'SPLIT';
export type PosPaymentMethod = 'CASH' | 'UPI' | 'CARD' | 'SPLIT';
export type PaymentStatus = 'pending' | 'paid' | 'failed' | 'refunded';

export interface SplitPaymentDetails {
  cash: number;
  upi: number;
  card: number;
}

export interface OrderItem {
  id: string;
  orderId: string;
  productId: string;
  name: string;
  imageUrl: string;
  unit: string;
  unitPrice: number;
  mrp: number;
  quantity: number;
  totalPrice: number;
}

export interface Order {
  id: string;
  orderType?: 'DELIVERY' | 'POS';
  customerId: string;
  customerName: string;
  customerPhone: string;
  apartmentId: string;
  apartmentName: string;
  deliveryAddress: string;
  storeId: string;
  storeName: string;
  deliveryPartnerId?: string;
  deliveryPartnerName?: string;
  deliveryPartnerPhone?: string;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  splitPaymentDetails?: SplitPaymentDetails;
  discountAmount?: number;
  transactionId?: string;
  subtotal: number;
  deliveryFee: number;
  handlingFee: number;
  totalAmount: number;
  itemCount: number;
  deliveryOtp: string;
  items?: OrderItem[];
  createdAt: string;
  updatedAt?: string;
}

export interface PaymentRecord {
  id: string;
  orderId?: string;
  storeId?: string;
  type: 'order' | 'subscription' | 'pos_sale';
  amount: number;
  currency: string;
  status: 'created' | 'verified' | 'failed';
  method: 'UPI' | 'CARD' | 'NETBANKING' | 'COD' | 'CASH' | 'SPLIT';
  splitPaymentDetails?: SplitPaymentDetails;
  transactionReference: string;
  paidAt: string;
  createdAt: string;
}

export interface Subscription {
  id: string;
  storeId: string;
  storeName: string;
  ownerId: string;
  amount: number; // ₹199
  periodMonth: string;
  startDate: string;
  endDate: string;
  status: 'active' | 'expired' | 'pending';
  paymentId: string;
  createdAt: string;
}

export interface DeliveryPartner {
  id: string;
  name: string;
  phone: string;
  status: 'active' | 'offline' | 'delivering';
  activeApartmentIds: string[];
  totalDeliveries: number;
  rating: number;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  recipientId: string;
  title: string;
  message: string;
  type: 'order_status' | 'subscription' | 'alert';
  relatedId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
