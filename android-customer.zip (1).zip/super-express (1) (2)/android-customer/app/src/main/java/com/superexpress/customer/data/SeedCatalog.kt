package com.superexpress.customer.data

import com.superexpress.customer.data.model.Apartment
import com.superexpress.customer.data.model.Category
import com.superexpress.customer.data.model.Product
import com.superexpress.customer.data.model.Store

object SeedCatalog {

    val apartments = listOf(
        Apartment(
            id = "apt-emerald-heights",
            name = "Emerald Heights Residences",
            address = "Survey 42, Harlur Main Road, Off Sarjapur Road",
            city = "Bengaluru",
            pincode = "560102",
            totalTowers = 6,
            totalFlats = 840,
            activeStoreId = "store-freshmart",
            activeStoreName = "FreshMart Supermarket",
            status = "active",
            createdAt = "2026-01-01T00:00:00Z"
        ),
        Apartment(
            id = "apt-prestige-falcon",
            name = "Prestige Falcon City",
            address = "Kanakapura Main Road, Anjanadri Layout",
            city = "Bengaluru",
            pincode = "560062",
            totalTowers = 8,
            totalFlats = 1250,
            activeStoreId = "store-greenvalley",
            activeStoreName = "GreenValley Daily Express",
            status = "active",
            createdAt = "2026-01-05T00:00:00Z"
        ),
        Apartment(
            id = "apt-sobha-dream",
            name = "Sobha Dream Acres",
            address = "Panathur Main Road, Balagere",
            city = "Bengaluru",
            pincode = "560087",
            totalTowers = 12,
            totalFlats = 1680,
            activeStoreId = "store-quickmart",
            activeStoreName = "QuickMart Superstore",
            status = "active",
            createdAt = "2026-01-10T00:00:00Z"
        ),
        Apartment(
            id = "apt-brigade-gateway",
            name = "Brigade Gateway",
            address = "Rajajinagar-Malleswaram, Dr Rajkumar Road",
            city = "Bengaluru",
            pincode = "560055",
            totalTowers = 5,
            totalFlats = 920,
            activeStoreId = null,
            activeStoreName = null,
            status = "active",
            createdAt = "2026-02-01T00:00:00Z"
        )
    )

    val stores = listOf(
        Store(
            id = "store-freshmart",
            name = "FreshMart Supermarket",
            ownerId = "owner-freshmart-01",
            ownerName = "Suresh Kumar",
            ownerPhone = "+91 98450 12345",
            apartmentId = "apt-emerald-heights",
            apartmentName = "Emerald Heights Residences",
            status = "active",
            openingTime = "06:30 AM",
            closingTime = "11:00 PM",
            deliveryTimeMinutes = 12,
            minOrderAmount = 99,
            rating = 4.8,
            totalOrders = 642
        ),
        Store(
            id = "store-greenvalley",
            name = "GreenValley Daily Express",
            ownerId = "owner-greenvalley-02",
            ownerName = "Pooja Reddy",
            ownerPhone = "+91 98860 67890",
            apartmentId = "apt-prestige-falcon",
            apartmentName = "Prestige Falcon City",
            status = "active",
            openingTime = "07:00 AM",
            closingTime = "10:30 PM",
            deliveryTimeMinutes = 15,
            minOrderAmount = 149,
            rating = 4.9,
            totalOrders = 498
        ),
        Store(
            id = "store-quickmart",
            name = "QuickMart Superstore",
            ownerId = "owner-quickmart-03",
            ownerName = "Manish Verma",
            ownerPhone = "+91 97400 45678",
            apartmentId = "apt-sobha-dream",
            apartmentName = "Sobha Dream Acres",
            status = "active",
            openingTime = "06:00 AM",
            closingTime = "11:30 PM",
            deliveryTimeMinutes = 10,
            minOrderAmount = 99,
            rating = 4.7,
            totalOrders = 820
        )
    )

    val categories = listOf(
        Category(
            id = "cat-all",
            name = "All Items",
            imageUrl = "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=300&q=80",
            sortOrder = 0
        ),
        Category(
            id = "cat-vegetables",
            name = "Vegetables & Fruits",
            imageUrl = "https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=300&q=80",
            sortOrder = 1
        ),
        Category(
            id = "cat-dairy",
            name = "Dairy, Bread & Eggs",
            imageUrl = "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=300&q=80",
            sortOrder = 2
        ),
        Category(
            id = "cat-snacks",
            name = "Snacks & Munchies",
            imageUrl = "https://images.unsplash.com/photo-1621996346565-e3d5d6281744?auto=format&fit=crop&w=300&q=80",
            sortOrder = 3
        ),
        Category(
            id = "cat-beverages",
            name = "Cold Drinks & Juices",
            imageUrl = "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=300&q=80",
            sortOrder = 4
        ),
        Category(
            id = "cat-staples",
            name = "Atta, Rice & Dal",
            imageUrl = "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=300&q=80",
            sortOrder = 5
        ),
        Category(
            id = "cat-cleaning",
            name = "Household & Cleaning",
            imageUrl = "https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?auto=format&fit=crop&w=300&q=80",
            sortOrder = 6
        )
    )

    val products = listOf(
        Product(
            id = "prod-fm-01",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "Fresh Farm Tomatoes (Hybrid)",
            description = "Juicy, farm-fresh hybrid tomatoes picked daily for rich curries and fresh salads.",
            category = "cat-vegetables",
            imageUrl = "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=500&q=80",
            price = 34.0,
            mrp = 45.0,
            unit = "1 kg",
            inStock = true,
            stockCount = 85,
            isPopular = true
        ),
        Product(
            id = "prod-fm-02",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "Fresh Crisp Red Onions",
            description = "Pungent, dry, medium-sized Nashik red onions essential for Indian cooking.",
            category = "cat-vegetables",
            imageUrl = "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?auto=format&fit=crop&w=500&q=80",
            price = 42.0,
            mrp = 55.0,
            unit = "1 kg",
            inStock = true,
            stockCount = 110,
            isPopular = true
        ),
        Product(
            id = "prod-fm-03",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "Robusta Golden Bananas",
            description = "Naturally ripened, sweet and energy-packed bananas.",
            category = "cat-vegetables",
            imageUrl = "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=500&q=80",
            price = 48.0,
            mrp = 60.0,
            unit = "500 g (4-5 pcs)",
            inStock = true,
            stockCount = 40,
            isPopular = true
        ),
        Product(
            id = "prod-fm-04",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "Amul Taaza Homogenised Toned Milk",
            brand = "Amul",
            description = "Pasteurised, fresh toned milk, rich in calcium and vitamin A & D.",
            category = "cat-dairy",
            imageUrl = "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=500&q=80",
            price = 27.0,
            mrp = 28.0,
            unit = "500 ml pouch",
            inStock = true,
            stockCount = 120,
            isPopular = true
        ),
        Product(
            id = "prod-fm-05",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "Fresh Whole Wheat Brown Bread",
            description = "100% whole wheat bread loaf baked fresh with zero maida and high fiber.",
            category = "cat-dairy",
            imageUrl = "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=500&q=80",
            price = 45.0,
            mrp = 50.0,
            unit = "400 g",
            inStock = true,
            stockCount = 30,
            isPopular = true
        ),
        Product(
            id = "prod-fm-06",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "Farm Fresh White Eggs (Pack of 6)",
            description = "Grade A sanitized farm eggs rich in protein and nutrients.",
            category = "cat-dairy",
            imageUrl = "https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?auto=format&fit=crop&w=500&q=80",
            price = 52.0,
            mrp = 65.0,
            unit = "6 pcs pack",
            inStock = true,
            stockCount = 50,
            isPopular = true
        ),
        Product(
            id = "prod-fm-07",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "Aashirvaad Shudh Chakki Atta",
            brand = "Aashirvaad",
            description = "100% whole wheat flour ground to perfection for soft, fluffy rotis.",
            category = "cat-staples",
            imageUrl = "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=500&q=80",
            price = 245.0,
            mrp = 290.0,
            unit = "5 kg",
            inStock = true,
            stockCount = 25,
            isPopular = true
        ),
        Product(
            id = "prod-fm-08",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "India Gate Basmati Rice Rozzana",
            brand = "India Gate",
            description = "Aromatic, long grain aged basmati rice for daily biryani and pulao.",
            category = "cat-staples",
            imageUrl = "https://images.unsplash.com/photo-1568600891621-50f697b9a1c7?auto=format&fit=crop&w=500&q=80",
            price = 135.0,
            mrp = 165.0,
            unit = "1 kg",
            inStock = true,
            stockCount = 40
        ),
        Product(
            id = "prod-fm-09",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "Lay's India's Magic Masala Chips",
            brand = "Lay's",
            description = "Crunchy potato chips seasoned with authentic hot Indian spices.",
            category = "cat-snacks",
            imageUrl = "https://images.unsplash.com/photo-1566478989037-eec170784d0b?auto=format&fit=crop&w=500&q=80",
            price = 20.0,
            mrp = 20.0,
            unit = "50 g",
            inStock = true,
            stockCount = 75,
            isPopular = true
        ),
        Product(
            id = "prod-fm-10",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "Cadbury Dairy Milk Silk Chocolate",
            brand = "Cadbury",
            description = "Smooth, creamy melt-in-mouth milk chocolate treat.",
            category = "cat-snacks",
            imageUrl = "https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=500&q=80",
            price = 75.0,
            mrp = 85.0,
            unit = "60 g bar",
            inStock = true,
            stockCount = 60,
            isPopular = true
        ),
        Product(
            id = "prod-fm-11",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "Coca-Cola Zero Sugar Can",
            brand = "Coca-Cola",
            description = "Refreshing sparkling cola drink with zero sugar and crisp taste.",
            category = "cat-beverages",
            imageUrl = "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=500&q=80",
            price = 40.0,
            mrp = 40.0,
            unit = "300 ml can",
            inStock = true,
            stockCount = 90,
            isPopular = true
        ),
        Product(
            id = "prod-fm-12",
            storeId = "store-freshmart",
            apartmentId = "apt-emerald-heights",
            name = "Surf Excel Matic Liquid Detergent",
            brand = "Surf Excel",
            description = "Advanced stain removal liquid detergent for bright and fragrant clothes.",
            category = "cat-cleaning",
            imageUrl = "https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?auto=format&fit=crop&w=500&q=80",
            price = 215.0,
            mrp = 240.0,
            unit = "1 Litre bottle",
            inStock = true,
            stockCount = 20
        ),
        Product(
            id = "prod-gv-01",
            storeId = "store-greenvalley",
            apartmentId = "apt-prestige-falcon",
            name = "Organic Shimla Apples (Pack of 4)",
            description = "Crisp, sweet, organic Himalayan red apples packed with antioxidants.",
            category = "cat-vegetables",
            imageUrl = "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=500&q=80",
            price = 160.0,
            mrp = 199.0,
            unit = "500 g (4 pcs)",
            inStock = true,
            stockCount = 35,
            isPopular = true
        ),
        Product(
            id = "prod-gv-02",
            storeId = "store-greenvalley",
            apartmentId = "apt-prestige-falcon",
            name = "Fresh Cow Milk (Nandini Special)",
            brand = "Nandini",
            description = "Pasteurised homogenized cow milk with rich cream and pure taste.",
            category = "cat-dairy",
            imageUrl = "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=500&q=80",
            price = 26.0,
            mrp = 27.0,
            unit = "500 ml",
            inStock = true,
            stockCount = 150,
            isPopular = true
        ),
        Product(
            id = "prod-gv-03",
            storeId = "store-greenvalley",
            apartmentId = "apt-prestige-falcon",
            name = "Tender Green Coconut",
            description = "Sweet, natural hydrating coconut water with soft malai.",
            category = "cat-beverages",
            imageUrl = "https://images.unsplash.com/photo-1525385133512-2f3bdd039054?auto=format&fit=crop&w=500&q=80",
            price = 55.0,
            mrp = 65.0,
            unit = "1 pc (approx 250ml)",
            inStock = true,
            stockCount = 45,
            isPopular = true
        ),
        Product(
            id = "prod-gv-04",
            storeId = "store-greenvalley",
            apartmentId = "apt-prestige-falcon",
            name = "Fortune Sunlite Refined Sunflower Oil",
            brand = "Fortune",
            description = "Light, healthy cooking oil enriched with Vitamin A & D.",
            category = "cat-staples",
            imageUrl = "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=500&q=80",
            price = 148.0,
            mrp = 175.0,
            unit = "1 Litre pouch",
            inStock = true,
            stockCount = 50,
            isPopular = true
        )
    )
}
