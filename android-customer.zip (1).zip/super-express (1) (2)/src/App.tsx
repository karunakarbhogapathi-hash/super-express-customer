import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { RoleSwitcher } from './components/RoleSwitcher';
import { Header } from './components/Header';
import { CustomerApp } from './components/customer/CustomerApp';
import { StoreOwnerPanel } from './components/owner/StoreOwnerPanel';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { DeliveryPartnerPanel } from './components/delivery/DeliveryPartnerPanel';
import { NotificationDrawer } from './components/NotificationDrawer';
import { SplashScreen } from './components/SplashScreen';

function MainApp() {
  const { role } = useApp();
  const [showSplash, setShowSplash] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased selection:bg-emerald-500 selection:text-white">
      {showSplash && <SplashScreen onEnter={() => setShowSplash(false)} />}

      {/* Role testing switcher: Seamlessly switch between Customer, Store Owner, Delivery, and Admin */}
      <RoleSwitcher />

      {/* Top Header */}
      <Header
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        openCart={() => setIsCartOpen(true)}
        openNotifications={() => setIsNotificationOpen(true)}
        openProfile={() => {
          // If in customer view, this can switch to profile tab
        }}
      />

      {/* Role-Specific Application Engine */}
      <main>
        {role === 'customer' && (
          <CustomerApp
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            isCartOpen={isCartOpen}
            setIsCartOpen={setIsCartOpen}
          />
        )}

        {role === 'store_owner' && <StoreOwnerPanel />}

        {role === 'delivery_partner' && <DeliveryPartnerPanel />}

        {role === 'admin' && <AdminDashboard />}
      </main>

      {/* Slide-out notification center */}
      <NotificationDrawer
        isOpen={isNotificationOpen}
        onClose={() => setIsNotificationOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
