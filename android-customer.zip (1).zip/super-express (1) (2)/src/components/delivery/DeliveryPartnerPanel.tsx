import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bike,
  Package,
  MapPin,
  CheckCircle2,
  Clock,
  Phone,
  ShieldCheck,
  Building2,
  Lock,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const DeliveryPartnerPanel: React.FC = () => {
  const {
    orders,
    currentUser,
    deliveryPartners,
    updateOrderStatus,
    verifyDeliveryOtp,
  } = useApp();

  const partner = deliveryPartners[0]; // Active demo partner Raju Kumar
  const [otpInputs, setOtpInputs] = useState<Record<string, string>>({});
  const [otpError, setOtpError] = useState<Record<string, string>>({});

  // Delivery partner sees assigned orders only:
  // "Delivery partner sees assigned orders only."
  const assignedOrders = orders.filter(
    (o) =>
      o.deliveryPartnerId === partner.id ||
      (o.status === 'out_for_delivery' && (!o.deliveryPartnerId || o.deliveryPartnerId === partner.id))
  );

  const activeDeliveries = assignedOrders.filter(
    (o) => ['packing', 'out_for_delivery'].includes(o.status)
  );
  const completedDeliveries = assignedOrders.filter((o) => o.status === 'delivered');

  const handlePickup = async (orderId: string) => {
    await updateOrderStatus(orderId, 'out_for_delivery', partner.id);
  };

  const handleVerifyAndDeliver = async (orderId: string) => {
    const inputOtp = otpInputs[orderId] || '';
    if (!inputOtp.trim()) {
      setOtpError((prev) => ({ ...prev, [orderId]: 'Please ask customer for their 4-digit OTP' }));
      return;
    }

    const isValid = await verifyDeliveryOtp(orderId, inputOtp.trim());
    if (isValid) {
      setOtpError((prev) => ({ ...prev, [orderId]: '' }));
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
    } else {
      setOtpError((prev) => ({
        ...prev,
        [orderId]: 'Invalid OTP code! Please verify with customer at the flat door.',
      }));
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 p-4 sm:p-6 pb-20">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Courier Profile Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-black text-white rounded-3xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shadow-lg">
              <Bike className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black">{partner?.name}</h1>
                <span className="bg-emerald-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded uppercase">
                  Available
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Contact: {partner?.phone} • Super Express Certified Runner
              </p>
              <div className="flex items-center gap-2 mt-1 text-xs text-emerald-300 font-semibold">
                <Building2 className="w-3.5 h-3.5" />
                <span>Assigned Societies: Emerald Heights & Prestige Falcon City</span>
              </div>
            </div>
          </div>

          <div className="bg-white/10 p-3 rounded-2xl border border-white/15 text-right">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">
              Today's Completed
            </span>
            <span className="text-xl font-black text-emerald-400">
              {completedDeliveries.length + 18} Deliveries
            </span>
          </div>
        </div>

        {/* Active Deliveries Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
              <Package className="w-5 h-5 text-emerald-600" />
              Assigned Apartment Deliveries ({activeDeliveries.length})
            </h2>
            <span className="text-xs text-slate-500 font-medium">
              10-15 Min Society SLA
            </span>
          </div>

          {activeDeliveries.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
              <h3 className="font-bold text-sm text-slate-800">All current orders delivered!</h3>
              <p className="text-xs text-slate-500 mt-1">
                You will be notified as soon as store owners hand over packed orders.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {activeDeliveries.map((order) => {
                const isOut = order.status === 'out_for_delivery';

                return (
                  <div
                    key={order.id}
                    className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-black text-sm text-slate-900">
                            Order #{order.id}
                          </span>
                          <span className="text-xs text-slate-400">•</span>
                          <span className="text-xs font-bold text-emerald-800">
                            ₹{order.totalAmount}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          From: <span className="font-bold text-slate-800">{order.storeName}</span>
                        </p>
                      </div>

                      <span
                        className={`text-[10px] font-black px-2.5 py-1 rounded-full uppercase ${
                          isOut
                            ? 'bg-amber-100 text-amber-800 animate-pulse'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {order.status.replace(/_/g, ' ')}
                      </span>
                    </div>

                    {/* Apartment & Flat info */}
                    <div className="bg-emerald-50/70 p-3.5 rounded-xl border border-emerald-100 flex items-start gap-3">
                      <MapPin className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <div className="text-[10px] uppercase font-bold text-emerald-800">
                          Deliver to Flat:
                        </div>
                        <h4 className="font-extrabold text-sm text-slate-900 mt-0.5">
                          {order.deliveryAddress}
                        </h4>
                        <div className="flex items-center gap-3 mt-1 text-xs">
                          <span className="text-slate-600 font-semibold">
                            Recipient: {order.customerName}
                          </span>
                          <a
                            href={`tel:${order.customerPhone}`}
                            className="font-bold text-emerald-700 flex items-center gap-1 hover:underline"
                          >
                            <Phone className="w-3 h-3" /> Call Customer
                          </a>
                        </div>
                      </div>
                    </div>

                    {/* Courier Flow Actions */}
                    {!isOut ? (
                      <button
                        onClick={() => handlePickup(order.id)}
                        className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
                      >
                        <Bike className="w-4 h-4" />
                        <span>Pick Up from Store & Start Delivery</span>
                      </button>
                    ) : (
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                        <div className="flex items-center gap-2">
                          <Lock className="w-4 h-4 text-emerald-600" />
                          <div>
                            <h5 className="font-bold text-xs text-slate-900">
                              Customer Delivery Verification
                            </h5>
                            <p className="text-[11px] text-slate-500">
                              Ask customer for their 4-digit OTP on delivery handover
                            </p>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <input
                            type="text"
                            maxLength={4}
                            placeholder="Enter 4-digit OTP (e.g. 4821)"
                            value={otpInputs[order.id] || ''}
                            onChange={(e) =>
                              setOtpInputs({ ...otpInputs, [order.id]: e.target.value })
                            }
                            className="flex-1 bg-white font-mono font-bold text-center tracking-widest text-sm border border-slate-300 rounded-xl p-2 outline-none focus:border-emerald-500"
                          />
                          <button
                            onClick={() => handleVerifyAndDeliver(order.id)}
                            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-sm cursor-pointer"
                          >
                            Verify & Complete Delivery
                          </button>
                        </div>

                        {otpError[order.id] && (
                          <p className="text-xs font-semibold text-red-600">
                            {otpError[order.id]}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Delivery Partner History */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
          <h3 className="font-bold text-sm text-slate-900">Recent Completed Deliveries</h3>
          <div className="divide-y divide-slate-100 text-xs">
            {completedDeliveries.map((cd) => (
              <div key={cd.id} className="py-2.5 flex justify-between items-center">
                <div>
                  <span className="font-bold text-slate-800">Order #{cd.id}</span>
                  <span className="text-slate-400 ml-2">{cd.apartmentName}</span>
                </div>
                <span className="font-bold text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Delivered
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
