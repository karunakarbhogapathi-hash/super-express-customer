package com.superexpress.customer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val EmeraldPrimary = Color(0xFF059669)
val EmeraldDark = Color(0xFF064E3B)
val EmeraldDeep = Color(0xFF022C22)
val EmeraldLight = Color(0xFFD1FAE5)
val AmberAccent = Color(0xFFF59E0B)
val SlateSurface = Color(0xFFF8FAFC)
val SlateInk = Color(0xFF0F172A)
val SlateMuted = Color(0xFF64748B)
val RoseDanger = Color(0xFFE11D48)

private val SuperExpressColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldLight,
    onPrimaryContainer = EmeraldDark,
    secondary = AmberAccent,
    onSecondary = EmeraldDeep,
    background = SlateSurface,
    onBackground = SlateInk,
    surface = Color.White,
    onSurface = SlateInk,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = SlateMuted,
    outline = Color(0xFFE2E8F0),
    error = RoseDanger,
    onError = Color.White
)

private val SuperExpressTypography = Typography(
    headlineMedium = TextStyle(
        fontWeight = FontWeight.ExtraBold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = (-0.5).sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        lineHeight = 20.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun SuperExpressTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SuperExpressColorScheme,
        typography = SuperExpressTypography,
        content = content
    )
}
