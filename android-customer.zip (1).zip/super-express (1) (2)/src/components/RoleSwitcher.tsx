import React from 'react';
import { useApp } from '../context/AppContext';
import { ShoppingBag, Store, Bike, ShieldCheck } from 'lucide-react';
import { UserRole } from '../types';

export const RoleSwitcher: React.FC = () => {
  const { role, setRole, activeApartment, activeStore } = useApp();

  const roles: { id: UserRole; label: string; icon: React.ReactNode; desc: string }[] = [
    {
      id: 'customer',
      label: 'Customer Shopping App',
      icon: <ShoppingBag className="w-4 h-4" />,
      desc: activeApartment?.name || 'Apartment Shopper',
    },
    {
      id: 'store_owner',
      label: 'Supermarket Owner Portal',
      icon: <Store className="w-4 h-4" />,
      desc: activeStore?.name || 'Register / Login / Dashboard',
    },
    {
      id: 'admin',
      label: 'Admin Platform HQ',
      icon: <ShieldCheck className="w-4 h-4" />,
      desc: 'Approvals & Governance',
    },
  ];

  return (
    <div className="bg-slate-900 text-white text-xs border-b border-slate-800 px-3 py-1.5 flex flex-wrap items-center justify-between gap-2 shadow-inner">
      <div className="flex items-center gap-2">
        <span className="inline-flex items-center gap-1 font-semibold text-emerald-400 uppercase tracking-wider text-[10px] bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          Role Switcher
        </span>
        <span className="hidden sm:inline text-slate-400 text-[11px]">
          Seamlessly test Customer, Supermarket Owner & Admin workflows:
        </span>
      </div>

      <div className="flex items-center gap-1.5 overflow-x-auto">
        {roles.map((r) => {
          const isActive = role === r.id;
          return (
            <button
              key={r.id}
              onClick={() => setRole(r.id)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-all cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-sm ring-1 ring-emerald-400 font-semibold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
            >
              {r.icon}
              <span>{r.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
