import React, { useState } from 'react';
import { Order } from '../../types';
import {
  Bell,
  CheckCircle2,
  XCircle,
  Volume2,
  VolumeX,
  Phone,
  MapPin,
  ShoppingBag,
  CreditCard,
  Clock,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface NewOrderAlertModalProps {
  orders: Order[];
  onAccept: (orderId: string) => Promise<void>;
  onReject: (orderId: string) => Promise<void>;
  onAcknowledge: (orderId: string) => void;
  isSoundMuted: boolean;
  onToggleSound: () => void;
}

export const NewOrderAlertModal: React.FC<NewOrderAlertModalProps> = ({
  orders,
  onAccept,
  onReject,
  onAcknowledge,
  isSoundMuted,
  onToggleSound,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [processingId, setProcessingId] = useState<string | null>(null);

  if (!orders || orders.length === 0) return null;

  // Safe index bounds
  const activeIndex = Math.min(currentIndex, orders.length - 1);
  const currentOrder = orders[activeIndex] || orders[0];

  const handleAccept = async () => {
    if (!currentOrder) return;
    setProcessingId(currentOrder.id);
    try {
      await onAccept(currentOrder.id);
      if (currentIndex > 0) setCurrentIndex(currentIndex - 1);
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async () => {
    if (!currentOrder) return;
    const confirmReject = window.confirm(
      `Are you sure you want to reject Order #${currentOrder.id} for ${currentOrder.customerName}?`
    );
    if (!confirmReject) return;

    setProcessingId(currentOrder.id);
    try {
      await onReject(currentOrder.id);
      if (currentIndex > 0) setCurrentIndex(currentIndex - 1);
    } finally {
      setProcessingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in-50 duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border-4 border-amber-500 overflow-hidden my-6 ring-8 ring-amber-400/20 animate-in zoom-in-95 duration-150">
        {/* Urgent Alert Banner Header */}
        <div className="bg-gradient-to-r from-red-600 via-amber-600 to-red-600 text-white p-4 sm:p-5 text-center relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 bg-black/30 backdrop-blur-xs px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-red-400 animate-ping inline-block" />
              Live Order Alert
            </div>

            {/* Sound Mute / Unmute Button */}
            <button
              onClick={onToggleSound}
              className="flex items-center gap-1 bg-white/20 hover:bg-white/30 text-white px-2.5 py-1 rounded-full text-[11px] font-bold transition cursor-pointer"
              title={isSoundMuted ? 'Unmute Sound' : 'Mute Sound'}
            >
              {isSoundMuted ? (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-white" />
                  <span>Muted</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-white animate-pulse" />
                  <span>Sound Beeping</span>
                </>
              )}
            </button>
          </div>

          <div className="flex items-center justify-center gap-2">
            <Bell className="w-7 h-7 sm:w-8 sm:h-8 text-amber-200 animate-bounce" />
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white uppercase drop-shadow-sm">
              🔔 NEW ORDER RECEIVED!
            </h2>
          </div>

          <p className="text-xs text-amber-100 mt-1 font-semibold">
            Order #{currentOrder.id} • Please accept or reject to process shipment
          </p>

          {/* Multiple Orders Pager if more than 1 order pending */}
          {orders.length > 1 && (
            <div className="flex items-center justify-center gap-2 mt-2 pt-2 border-t border-white/20 text-xs font-bold">
              <span>
                Pending Orders: {activeIndex + 1} of {orders.length}
              </span>
              <div className="flex gap-1">
                <button
                  disabled={activeIndex === 0}
                  onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
                  className="px-2 py-0.5 bg-white/20 hover:bg-white/30 rounded text-[11px] disabled:opacity-40"
                >
                  Prev
                </button>
                <button
                  disabled={activeIndex >= orders.length - 1}
                  onClick={() => setCurrentIndex((prev) => Math.min(orders.length - 1, prev + 1))}
                  className="px-2 py-0.5 bg-white/20 hover:bg-white/30 rounded text-[11px] disabled:opacity-40"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-4 text-xs">
          {/* Customer & Destination Card */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2">
            <div className="flex items-center justify-between border-b border-slate-200/80 pb-2">
              <div>
                <span className="text-[10px] font-black uppercase text-slate-400 block">Customer</span>
                <span className="text-sm font-extrabold text-slate-900">{currentOrder.customerName}</span>
              </div>
              <a
                href={`tel:${currentOrder.customerPhone}`}
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl font-bold border border-emerald-200 transition"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span>{currentOrder.customerPhone}</span>
              </a>
            </div>

            <div className="flex items-start gap-2 pt-1">
              <MapPin className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-900 block">{currentOrder.deliveryAddress}</span>
                <span className="text-[11px] text-slate-500">10-15 Min Apartment Doorstep Delivery</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1 border-t border-slate-200/80 text-[11px]">
              <span className="text-slate-600 font-medium">Payment Mode:</span>
              <span
                className={`font-black uppercase px-2 py-0.5 rounded-md ${
                  currentOrder.paymentStatus === 'paid'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {currentOrder.paymentMethod} ({currentOrder.paymentStatus})
              </span>
            </div>
          </div>

          {/* Ordered Products List */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <h4 className="font-extrabold text-slate-800 flex items-center gap-1.5">
                <ShoppingBag className="w-3.5 h-3.5 text-emerald-600" />
                Ordered Grocery Items ({currentOrder.itemCount || currentOrder.items?.length || 0})
              </h4>
              <span className="text-[10px] text-slate-400 font-bold uppercase">Itemized</span>
            </div>

            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
              {currentOrder.items && currentOrder.items.length > 0 ? (
                currentOrder.items.map((item) => (
                  <div
                    key={item.id}
                    className="p-2 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-2 shadow-2xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {item.imageUrl && (
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-9 h-9 rounded-lg object-cover bg-slate-100 shrink-0 border border-slate-100"
                        />
                      )}
                      <div className="min-w-0">
                        <p className="font-bold text-slate-900 truncate">{item.name}</p>
                        <p className="text-[10px] text-slate-500">
                          Qty: <strong className="text-emerald-700">{item.quantity}</strong> • {item.unit}
                        </p>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="font-extrabold text-slate-900">₹{item.totalPrice}</span>
                      {item.mrp > item.unitPrice && (
                        <span className="text-[9px] text-slate-400 line-through block">
                          ₹{item.mrp * item.quantity}
                        </span>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-3 bg-slate-50 rounded-xl text-center text-slate-500 font-medium">
                  {currentOrder.itemCount} items ordered
                </div>
              )}
            </div>
          </div>

          {/* Total Amount Card */}
          <div className="p-3.5 bg-emerald-50/80 rounded-2xl border border-emerald-200 flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-emerald-800 block">Total Payable Amount:</span>
              <span className="text-[11px] text-slate-500">Includes delivery & handling charges</span>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black text-emerald-800">₹{currentOrder.totalAmount}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 space-y-2">
            <div className="grid grid-cols-2 gap-2.5">
              {/* Accept Order Button */}
              <button
                disabled={Boolean(processingId)}
                onClick={handleAccept}
                className="py-3.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black text-xs sm:text-sm rounded-2xl shadow-lg shadow-emerald-700/25 flex items-center justify-center gap-1.5 transition transform active:scale-98 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{processingId === currentOrder.id ? 'Accepting...' : 'Accept Order'}</span>
              </button>

              {/* Reject Order Button */}
              <button
                disabled={Boolean(processingId)}
                onClick={handleReject}
                className="py-3.5 bg-rose-50 hover:bg-rose-100 text-rose-700 disabled:opacity-50 font-black text-xs sm:text-sm rounded-2xl border border-rose-200 transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                <XCircle className="w-4 h-4" />
                <span>Reject Order</span>
              </button>
            </div>

            {/* Acknowledge / View in Queue Button */}
            <button
              onClick={() => onAcknowledge(currentOrder.id)}
              className="w-full py-2.5 text-slate-500 hover:text-slate-800 font-bold text-xs rounded-xl hover:bg-slate-100 transition cursor-pointer text-center"
            >
              Acknowledge & View in Orders Queue (Silence Alarm)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
