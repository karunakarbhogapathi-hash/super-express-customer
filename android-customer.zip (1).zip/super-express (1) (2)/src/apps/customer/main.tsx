import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { AppProvider } from '../../context/AppContext';
import { CustomerAppShell } from './CustomerAppShell';
import '../../index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AppProvider appMode="customer">
      <CustomerAppShell />
    </AppProvider>
  </StrictMode>
);
