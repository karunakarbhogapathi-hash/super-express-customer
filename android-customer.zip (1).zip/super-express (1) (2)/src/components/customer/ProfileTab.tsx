import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  Phone,
  Building2,
  ShieldCheck,
  Headphones,
  CheckCircle2,
  MapPin,
  Clock,
  Sparkles,
  HelpCircle,
} from 'lucide-react';

export const ProfileTab: React.FC = () => {
  const { currentUser, activeApartment, setCurrentUser } = useApp();
  const [phoneInput, setPhoneInput] = useState(currentUser.phone);
  const [nameInput, setNameInput] = useState(currentUser.name);
  const [flatInput, setFlatInput] = useState(currentUser.flatNumber || '402');
  const [blockInput, setBlockInput] = useState(currentUser.block || 'Tower B');
  const [otpCode, setOtpCode] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [isVerified, setIsVerified] = useState(currentUser.isVerified);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSendOtp = () => {
    if (!phoneInput) return;
    setIsOtpSent(true);
  };

  const handleVerifyOtp = () => {
    if (otpCode.length >= 4) {
      setIsVerified(true);
      setCurrentUser((prev) => ({
        ...prev,
        phone: phoneInput,
        name: nameInput,
        flatNumber: flatInput,
        block: blockInput,
        isVerified: true,
      }));
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentUser((prev) => ({
      ...prev,
      name: nameInput,
      flatNumber: flatInput,
      block: blockInput,
    }));
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
      {/* Profile Header */}
      <div className="bg-gradient-to-br from-emerald-900 to-slate-900 text-white p-6 rounded-3xl shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500/30 border border-emerald-400/40 flex items-center justify-center font-black text-2xl text-emerald-300">
            {currentUser.name ? currentUser.name[0] : 'U'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black">{currentUser.name}</h2>
              {isVerified && (
                <span className="inline-flex items-center gap-1 text-[11px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-400/30 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5" /> Verified Resident
                </span>
              )}
            </div>
            <p className="text-xs text-emerald-200 mt-0.5">{currentUser.phone}</p>
            <p className="text-xs text-slate-300 mt-1 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-emerald-400" />
              {activeApartment?.name} ({currentUser.block || 'Tower B'} - Flat {currentUser.flatNumber || '402'})
            </p>
          </div>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-100 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          Profile and apartment residence details saved!
        </div>
      )}

      {/* Apartment Residence Verification Form */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Building2 className="w-5 h-5 text-emerald-600" />
          <div>
            <h3 className="font-bold text-sm text-slate-900">Apartment & Resident Details</h3>
            <p className="text-xs text-slate-500">
              Only verified residents receive grocery deliveries within this society
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
          <div>
            <label className="text-slate-600 font-semibold block mb-1">Full Name</label>
            <input
              type="text"
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-medium outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-600 font-semibold block mb-1">Tower / Block</label>
              <input
                type="text"
                value={blockInput}
                onChange={(e) => setBlockInput(e.target.value)}
                placeholder="Tower B"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-medium outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="text-slate-600 font-semibold block mb-1">Flat / Unit Number</label>
              <input
                type="text"
                value={flatInput}
                onChange={(e) => setFlatInput(e.target.value)}
                placeholder="402"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-medium outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-600 font-semibold block mb-1">
              Mobile Number (OTP Verification)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={phoneInput}
                onChange={(e) => setPhoneInput(e.target.value)}
                className="flex-1 bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-medium outline-none focus:border-emerald-500"
              />
              <button
                type="button"
                onClick={handleSendOtp}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl cursor-pointer"
              >
                {isOtpSent ? 'Resend OTP' : 'Send OTP'}
              </button>
            </div>
          </div>

          {isOtpSent && (
            <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-emerald-900">
                  Enter 4-digit SMS OTP sent to {phoneInput}
                </span>
                <span className="text-[10px] bg-emerald-200 text-emerald-800 px-1.5 py-0.5 rounded font-mono font-bold">
                  Demo OTP: 5824
                </span>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  maxLength={4}
                  placeholder="5824"
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  className="w-32 bg-white text-center font-mono font-bold text-base tracking-widest border border-emerald-300 rounded-lg p-2"
                />
                <button
                  type="button"
                  onClick={handleVerifyOtp}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg"
                >
                  Verify OTP
                </button>
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full py-3 bg-slate-900 hover:bg-black text-white font-bold rounded-xl cursor-pointer"
          >
            Update Resident Profile
          </button>
        </form>
      </div>

      {/* Customer Support & FAQs */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <Headphones className="w-5 h-5 text-emerald-600" />
          <h3 className="font-bold text-sm text-slate-900">Super Express Apartment Support</h3>
        </div>

        <div className="space-y-2 text-xs">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <h4 className="font-bold text-slate-800">⚡ How does single-store delivery work?</h4>
            <p className="text-slate-600 mt-1">
              Your residential community has exactly one active authorized supermarket dedicated exclusively to your apartment. Orders are handpicked and delivered in 10-15 minutes directly to your flat door.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <h4 className="font-bold text-slate-800">📦 What is the delivery OTP?</h4>
            <p className="text-slate-600 mt-1">
              When your order arrives at your flat door, please share the 4-digit verification code with the delivery partner to confirm handover.
            </p>
          </div>

          <div className="flex items-center justify-between pt-2">
            <span className="text-slate-500 font-medium">Need immediate assistance?</span>
            <a
              href="mailto:support@superexpress.delivery"
              className="font-bold text-emerald-700 hover:underline"
            >
              Contact Society Helpdesk
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
