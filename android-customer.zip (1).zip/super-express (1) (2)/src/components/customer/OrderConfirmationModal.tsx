import React from 'react';
import { CheckCircle2, Zap, Clock, ShieldCheck, X, ArrowRight, Phone } from 'lucide-react';
import { Order } from '../../types';

interface OrderConfirmationModalProps {
  order: Order | null;
  onClose: () => void;
  onViewOrders: () => void;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  order,
  onClose,
  onViewOrders,
}) => {
  if (!order) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-emerald-100 text-center animate-in zoom-in-95 duration-200">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center mb-4 ring-8 ring-emerald-50">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 mb-2">
          <Zap className="w-3.5 h-3.5 fill-emerald-600 text-emerald-600" />
          Order Confirmed • #{order.id}
        </div>

        <h3 className="text-xl font-black text-slate-900 tracking-tight">
          Packing Your Groceries!
        </h3>
        <p className="text-xs text-slate-500 mt-1">
          {order.storeName} is handpicking fresh items for {order.apartmentName}
        </p>

        {/* Delivery OTP Security Card */}
        <div className="my-5 p-4 rounded-2xl bg-gradient-to-br from-emerald-900 to-slate-900 text-white shadow-lg">
          <div className="text-[11px] uppercase tracking-wider text-emerald-300 font-bold mb-1">
            Delivery Verification OTP
          </div>
          <div className="font-mono text-3xl font-black tracking-widest text-yellow-300 py-1">
            {order.deliveryOtp}
          </div>
          <p className="text-[11px] text-emerald-100 mt-1">
            Share this 4-digit code with your Super Express delivery rider at your doorstep.
          </p>
        </div>

        {/* Arrival info */}
        <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 text-left text-xs space-y-1.5 mb-5">
          <div className="flex items-center justify-between text-slate-700">
            <span className="flex items-center gap-1.5 text-slate-500">
              <Clock className="w-4 h-4 text-emerald-600" /> Estimated Arrival
            </span>
            <span className="font-bold text-slate-900">10-15 Minutes</span>
          </div>
          <div className="flex items-center justify-between text-slate-700">
            <span className="text-slate-500">Delivery Location</span>
            <span className="font-semibold text-slate-900 truncate max-w-[200px]">
              {order.deliveryAddress}
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-700">
            <span className="text-slate-500">Payment Status</span>
            <span className={`font-bold uppercase text-[11px] ${order.paymentStatus === 'paid' ? 'text-emerald-600' : 'text-amber-600'}`}>
              {order.paymentStatus === 'paid' ? 'PAID ONLINE (VERIFIED)' : 'CASH ON DELIVERY'}
            </span>
          </div>
        </div>

        <div className="flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 py-3 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
          >
            Continue Shopping
          </button>
          <button
            onClick={() => {
              onClose();
              onViewOrders();
            }}
            className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>Track Order</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
