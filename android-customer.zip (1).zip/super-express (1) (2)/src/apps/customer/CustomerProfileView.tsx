import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Building2,
  ShieldCheck,
  Headphones,
  CheckCircle2,
  LogOut,
  Mail,
} from 'lucide-react';

export const CustomerProfileView: React.FC = () => {
  const {
    currentUser,
    activeApartment,
    apartments,
    updateCustomerProfile,
    logoutCustomer,
    selectApartment,
  } = useApp();

  const [nameInput, setNameInput] = useState(currentUser.name);
  const [phoneInput, setPhoneInput] = useState(currentUser.phone);
  const [apartmentInput, setApartmentInput] = useState(currentUser.apartmentId || apartments[0]?.id || '');
  const [blockInput, setBlockInput] = useState(currentUser.block || 'Tower A');
  const [flatInput, setFlatInput] = useState(currentUser.flatNumber || '101');
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    setNameInput(currentUser.name);
    setPhoneInput(currentUser.phone);
    setApartmentInput(currentUser.apartmentId || apartments[0]?.id || '');
    setBlockInput(currentUser.block || 'Tower A');
    setFlatInput(currentUser.flatNumber || '101');
  }, [currentUser, apartments]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (apartmentInput && apartmentInput !== currentUser.apartmentId) {
        selectApartment(apartmentInput);
      }
      await updateCustomerProfile({
        name: nameInput,
        phone: phoneInput,
        apartmentId: apartmentInput,
        block: blockInput,
        flatNumber: flatInput,
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
      {/* Profile Header */}
      <div className="bg-gradient-to-br from-emerald-900 to-slate-900 text-white p-6 rounded-3xl shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500/30 border border-emerald-400/40 flex items-center justify-center font-black text-2xl text-emerald-300">
            {currentUser.name ? currentUser.name[0].toUpperCase() : 'C'}
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-lg font-black">{currentUser.name}</h2>
              <span className="inline-flex items-center gap-1 text-[11px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-400/30 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" /> Customer Account
              </span>
            </div>
            {currentUser.email && (
              <p className="text-xs text-emerald-200 mt-0.5 flex items-center gap-1">
                <Mail className="w-3 h-3" /> {currentUser.email}
              </p>
            )}
            <p className="text-xs text-slate-300 mt-1 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-emerald-400" />
              {activeApartment?.name} ({currentUser.block || 'Tower A'} - Flat{' '}
              {currentUser.flatNumber || '101'})
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => void logoutCustomer()}
          className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </button>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-100 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          Profile and apartment residence details saved to Firebase!
        </div>
      )}

      {/* Residence Details Form */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Building2 className="w-5 h-5 text-emerald-600" />
          <div>
            <h3 className="font-bold text-sm text-slate-900">Apartment & Delivery Profile</h3>
            <p className="text-xs text-slate-500">
              Saved directly to your Super Express customer account
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
          <div>
            <label className="text-slate-600 font-semibold block mb-1">Full Name</label>
            <input
              type="text"
              required
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-medium outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="text-slate-600 font-semibold block mb-1">Mobile Number</label>
            <input
              type="tel"
              required
              value={phoneInput}
              onChange={(e) => setPhoneInput(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-medium outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="text-slate-600 font-semibold block mb-1">Apartment Society</label>
            <select
              value={apartmentInput}
              onChange={(e) => setApartmentInput(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-semibold outline-none focus:border-emerald-500"
            >
              {apartments.map((apt) => (
                <option key={apt.id} value={apt.id}>
                  {apt.name} ({apt.city})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-600 font-semibold block mb-1">Tower / Block</label>
              <input
                type="text"
                required
                value={blockInput}
                onChange={(e) => setBlockInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-medium outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="text-slate-600 font-semibold block mb-1">Flat / Door Number</label>
              <input
                type="text"
                required
                value={flatInput}
                onChange={(e) => setFlatInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-medium outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full py-3 bg-slate-900 hover:bg-black disabled:opacity-50 text-white font-bold rounded-xl cursor-pointer transition"
          >
            {saving ? 'Saving Profile...' : 'Save Customer Profile'}
          </button>
        </form>
      </div>

      {/* Customer Support */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <Headphones className="w-5 h-5 text-emerald-600" />
          <h3 className="font-bold text-sm text-slate-900">Super Express Customer Support</h3>
        </div>
        <p className="text-xs text-slate-600">
          Orders are handpicked by your apartment&apos;s verified supermarket and delivered directly to your flat door in 10–15 minutes.
        </p>
      </div>
    </div>
  );
};
