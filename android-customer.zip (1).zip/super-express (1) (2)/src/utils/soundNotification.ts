/**
 * Real-Time Order Sound & Alert Notification Utility
 * Handles Web Audio API synthesized loud chimes, browser autoplay unlock,
 * repeating alarm loops until order acceptance, and system push notifications.
 */

let audioCtx: AudioContext | null = null;
let alarmIntervalId: any = null;
let isAlarmCurrentlyPlaying = false;
let audioUnlocked = false;

/**
 * Initializes or retrieves the singleton AudioContext.
 */
function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  return audioCtx;
}

/**
 * Unlocks the Web Audio API on user interaction.
 * Handles browser autoplay restrictions seamlessly.
 */
export async function unlockAudioContext(): Promise<boolean> {
  const ctx = getAudioContext();
  if (!ctx) return false;

  try {
    if (ctx.state === 'suspended') {
      await ctx.resume();
    }
    // Play a tiny silent buffer to warm up mobile audio hardware
    const buffer = ctx.createBuffer(1, 1, 22050);
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.start(0);

    audioUnlocked = true;
    return true;
  } catch (err) {
    console.warn('Audio unlock warning:', err);
    return false;
  }
}

/**
 * Check if audio context is active and unlocked
 */
export function isAudioReady(): boolean {
  const ctx = getAudioContext();
  return Boolean(ctx && (ctx.state === 'running' || audioUnlocked));
}

/**
 * Automatically attach user-interaction listeners to unlock audio
 * on the first click, tap, or keypress anywhere on the page.
 */
if (typeof window !== 'undefined') {
  const tryAutoUnlock = () => {
    unlockAudioContext().then((success) => {
      if (success) {
        window.removeEventListener('click', tryAutoUnlock);
        window.removeEventListener('touchstart', tryAutoUnlock);
        window.removeEventListener('keydown', tryAutoUnlock);
      }
    });
  };

  window.addEventListener('click', tryAutoUnlock, { once: true, passive: true });
  window.addEventListener('touchstart', tryAutoUnlock, { once: true, passive: true });
  window.addEventListener('keydown', tryAutoUnlock, { once: true, passive: true });
}

/**
 * Synthesizes a loud, high-clarity dual-tone delivery alert chime.
 * Emulates the urgent POS alert sounds used by commercial delivery apps.
 */
export function playSingleBeepSequence(volume = 0.85): void {
  const ctx = getAudioContext();
  if (!ctx) return;

  if (ctx.state === 'suspended') {
    ctx.resume().catch(() => {});
  }

  const now = ctx.currentTime;

  // Tone 1: High alert chirp (950 Hz)
  const osc1 = ctx.createOscillator();
  const gain1 = ctx.createGain();
  osc1.type = 'sine';
  osc1.frequency.setValueAtTime(950, now);
  osc1.frequency.exponentialRampToValueAtTime(1250, now + 0.12);

  gain1.gain.setValueAtTime(0.001, now);
  gain1.gain.linearRampToValueAtTime(volume, now + 0.02);
  gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

  osc1.connect(gain1);
  gain1.connect(ctx.destination);
  osc1.start(now);
  osc1.stop(now + 0.15);

  // Tone 2: Mid-accent (1200 Hz)
  const osc2 = ctx.createOscillator();
  const gain2 = ctx.createGain();
  osc2.type = 'triangle';
  osc2.frequency.setValueAtTime(1200, now + 0.16);
  osc2.frequency.exponentialRampToValueAtTime(1550, now + 0.28);

  gain2.gain.setValueAtTime(0.001, now + 0.16);
  gain2.gain.linearRampToValueAtTime(volume * 0.9, now + 0.18);
  gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

  osc2.connect(gain2);
  gain2.connect(ctx.destination);
  osc2.start(now + 0.16);
  osc2.stop(now + 0.32);

  // Tone 3: Urgent high bell (1650 Hz with harmonics)
  const osc3 = ctx.createOscillator();
  const gain3 = ctx.createGain();
  osc3.type = 'sine';
  osc3.frequency.setValueAtTime(1650, now + 0.34);
  osc3.frequency.exponentialRampToValueAtTime(1850, now + 0.55);

  gain3.gain.setValueAtTime(0.001, now + 0.34);
  gain3.gain.linearRampToValueAtTime(volume, now + 0.36);
  gain3.gain.exponentialRampToValueAtTime(0.001, now + 0.65);

  osc3.connect(gain3);
  gain3.connect(ctx.destination);
  osc3.start(now + 0.34);
  osc3.stop(now + 0.68);
}

/**
 * Starts the continuous repeating loud alarm.
 * Repeats every 2.4 seconds until stopped by owner action (Accept, Reject, or Acknowledge).
 */
export function startOrderAlarmSound(): void {
  if (isAlarmCurrentlyPlaying) return;
  isAlarmCurrentlyPlaying = true;

  // Play immediately
  playSingleBeepSequence(0.9);

  // And repeat every 2.4 seconds
  alarmIntervalId = setInterval(() => {
    if (isAlarmCurrentlyPlaying) {
      playSingleBeepSequence(0.9);
    } else {
      clearInterval(alarmIntervalId);
      alarmIntervalId = null;
    }
  }, 2400);
}

/**
 * Stops the continuous repeating alarm sound immediately.
 */
export function stopOrderAlarmSound(): void {
  isAlarmCurrentlyPlaying = false;
  if (alarmIntervalId) {
    clearInterval(alarmIntervalId);
    alarmIntervalId = null;
  }
}

/**
 * Returns true if the order alarm is currently playing.
 */
export function isAlarmPlaying(): boolean {
  return isAlarmCurrentlyPlaying;
}

/**
 * Play a one-shot test notification sound for volume and speaker verification.
 */
export async function playTestNotificationBeep(): Promise<boolean> {
  await unlockAudioContext();
  playSingleBeepSequence(0.9);
  return true;
}

/**
 * Request OS / Browser notification permission.
 */
export async function requestBrowserNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }

  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch (err) {
    console.warn('Notification permission request error:', err);
    return 'denied';
  }
}

/**
 * Triggers a browser desktop / mobile push notification if permitted.
 */
export function triggerSystemNotification(title: string, body: string, tag?: string): void {
  if (typeof window === 'undefined' || !('Notification' in window)) return;

  if (Notification.permission === 'granted') {
    try {
      const notif = new Notification(title, {
        body,
        icon: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=128&q=80',
        tag: tag || 'new-order-alert',
        requireInteraction: true,
      });

      notif.onclick = () => {
        window.focus();
        notif.close();
      };
    } catch (err) {
      console.warn('Error showing system notification:', err);
    }
  }
}

/**
 * Play a crisp POS barcode scanner beep (high beep on match, low error tone on unknown barcode).
 */
export function playScannerBeep(success = true): void {
  const ctx = getAudioContext();
  if (!ctx) return;

  if (ctx.state === 'suspended') {
    ctx.resume().catch(() => {});
  }

  try {
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    if (success) {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1800, now);
      gain.gain.setValueAtTime(0.01, now);
      gain.gain.exponentialRampToValueAtTime(0.35, now + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.12);
    } else {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(260, now);
      osc.frequency.setValueAtTime(190, now + 0.1);
      gain.gain.setValueAtTime(0.01, now);
      gain.gain.exponentialRampToValueAtTime(0.3, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);
    }
  } catch {
    // ignore audio synth errors
  }
}
