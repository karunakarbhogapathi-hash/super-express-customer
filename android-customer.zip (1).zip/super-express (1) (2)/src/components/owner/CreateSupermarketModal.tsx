import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Store,
  Building2,
  Clock,
  MapPin,
  FileText,
  Upload,
  CheckCircle2,
  AlertTriangle,
  X,
  Sparkles,
  Camera,
  RefreshCw,
  Loader2,
} from 'lucide-react';
import { auth, signInWithGoogleForFirebase } from '../../firebase';
import { uploadImageToCloudinary } from '../../services/cloudinary';

interface CreateSupermarketModalProps {
  isOpen?: boolean;
  inline?: boolean;
  onClose?: () => void;
  onCreated: (newStore?: any) => void;
}

export const CreateSupermarketModal: React.FC<CreateSupermarketModalProps> = ({
  isOpen = true,
  inline = false,
  onClose,
  onCreated,
}) => {
  const { ownerUser, apartments, stores, createStoreApplication } = useApp();

  const [supermarketName, setSupermarketName] = useState('');
  const [ownerName, setOwnerName] = useState(ownerUser?.name || '');
  const [contactNumber, setContactNumber] = useState(ownerUser?.phone || '');
  const [ownerEmail, setOwnerEmail] = useState(ownerUser?.email || '');
  const [supermarketAddress, setSupermarketAddress] = useState('');
  const [selectedApartmentId, setSelectedApartmentId] = useState(
    apartments.find((a) => !a.activeStoreId)?.id || apartments[0]?.id || ''
  );
  const [businessDescription, setBusinessDescription] = useState(
    'Daily fresh milk, organic fruits & vegetables, bread, and home essentials with 10-15 min apartment doorstep delivery.'
  );
  const [storeLogoUrl, setStoreLogoUrl] = useState(
    'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=500&q=80'
  );
  const [openingTime, setOpeningTime] = useState('06:30 AM');
  const [closingTime, setClosingTime] = useState('11:00 PM');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const logoInputRef = React.useRef<HTMLInputElement>(null);
  const [isLogoUploading, setIsLogoUploading] = useState(false);
  const [logoProgress, setLogoProgress] = useState(0);
  const [hasUploadedLogoToCloudinary, setHasUploadedLogoToCloudinary] = useState(false);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMsg('');
    if (!auth.currentUser) {
      try {
        await signInWithGoogleForFirebase();
      } catch (authErr: any) {
        setErrorMsg(authErr?.message || 'Firebase authentication is required before uploading images.');
        if (logoInputRef.current) logoInputRef.current.value = '';
        return;
      }
    }
    setLogoProgress(0);
    setIsLogoUploading(true);
    try {
      const result = await uploadImageToCloudinary(
        file,
        (progress) => setLogoProgress(progress)
      );
      setStoreLogoUrl(result.secureUrl);
      setHasUploadedLogoToCloudinary(true);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to upload image');
    } finally {
      setIsLogoUploading(false);
      if (logoInputRef.current) logoInputRef.current.value = '';
    }
  };

  if (!isOpen) return null;

  const targetApt = apartments.find((a) => a.id === selectedApartmentId);
  const existingStoreForApt = stores.find(
    (s) => s.apartmentId === selectedApartmentId && s.status === 'active'
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supermarketName.trim()) {
      setErrorMsg('Please enter supermarket name');
      return;
    }
    if (!supermarketAddress.trim()) {
      setErrorMsg('Please enter store physical address');
      return;
    }
    if (!selectedApartmentId) {
      setErrorMsg('Please select an apartment complex');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');
    try {
      const created = await createStoreApplication({
        name: supermarketName.trim(),
        ownerName: ownerName.trim() || ownerUser?.name || 'Store Owner',
        ownerPhone: contactNumber.trim() || ownerUser?.phone || '',
        ownerEmail: ownerEmail.trim() || ownerUser?.email,
        address: supermarketAddress.trim(),
        apartmentId: selectedApartmentId,
        logoUrl: storeLogoUrl.trim(),
        description: businessDescription.trim(),
        openingTime,
        closingTime,
      });

      setIsSubmitting(false);
      onCreated(created);
    } catch (err) {
      console.error(err);
      setErrorMsg('Could not submit application. Please try again.');
      setIsSubmitting(false);
    }
  };

  const formContent = (
    <div className={`bg-white rounded-3xl ${inline ? 'w-full shadow-md border border-slate-200' : 'max-w-xl w-full shadow-2xl border border-slate-200 my-8'} overflow-hidden animate-in zoom-in-95 duration-200`}>
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-900 text-white p-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center font-bold shadow-md">
            <Store className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-extrabold text-base">Register Your Supermarket</h3>
            <p className="text-xs text-emerald-200">
              Single-store apartment delivery application
            </p>
          </div>
        </div>
        {onClose && !inline && (
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {errorMsg && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl font-medium">
              {errorMsg}
            </div>
          )}

          <div>
            <label className="text-slate-700 font-bold block mb-1">
              Supermarket Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Daily Greens & Groceries"
              value={supermarketName}
              onChange={(e) => setSupermarketName(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-semibold text-slate-900 outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-slate-700 font-bold block mb-1">Owner Name <span className="text-red-500">*</span></label>
              <input
                type="text"
                required
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium text-slate-800 outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="text-slate-700 font-bold block mb-1">Mobile Number <span className="text-red-500">*</span></label>
              <input
                type="tel"
                required
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium text-slate-800 outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-700 font-bold block mb-1">Email Address</label>
            <input
              type="email"
              placeholder="e.g. owner@example.com"
              value={ownerEmail}
              onChange={(e) => setOwnerEmail(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium text-slate-800 outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="text-slate-700 font-bold block mb-1">
              Select Target Apartment Complex <span className="text-red-500">*</span>
            </label>
            <select
              value={selectedApartmentId}
              onChange={(e) => setSelectedApartmentId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-semibold text-slate-800 outline-none focus:border-emerald-500"
            >
              {apartments.map((apt) => {
                const hasStore = stores.some(
                  (s) => s.apartmentId === apt.id && s.status === 'active'
                );
                return (
                  <option key={apt.id} value={apt.id}>
                    {apt.name} ({apt.totalFlats} Flats) {hasStore ? '— [Active Store Present]' : '— [Available for Assignment]'}
                  </option>
                );
              })}
            </select>

            {existingStoreForApt ? (
              <p className="text-[11px] text-amber-700 font-medium mt-1 flex items-center gap-1 bg-amber-50 p-2 rounded-lg border border-amber-200">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>
                  Notice: <strong>{existingStoreForApt.name}</strong> is currently assigned to this society. Applications for this society will require admin review/reassignment.
                </span>
              </p>
            ) : (
              <p className="text-[11px] text-emerald-700 font-medium mt-1 flex items-center gap-1 bg-emerald-50 p-2 rounded-lg border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>
                  Territory Open: No active supermarket is currently serving {targetApt?.name}!
                </span>
              </p>
            )}
          </div>

          <div>
            <label className="text-slate-700 font-bold block mb-1">
              Supermarket Physical Address <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Ground Floor, Commercial Block, Near Gate 1"
              value={supermarketAddress}
              onChange={(e) => setSupermarketAddress(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-700 font-bold block mb-1">Opening Time</label>
              <input
                type="text"
                value={openingTime}
                onChange={(e) => setOpeningTime(e.target.value)}
                placeholder="06:30 AM"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium outline-none"
              />
            </div>
            <div>
              <label className="text-slate-700 font-bold block mb-1">Closing Time</label>
              <input
                type="text"
                value={closingTime}
                onChange={(e) => setClosingTime(e.target.value)}
                placeholder="11:00 PM"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-medium outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-700 font-bold block mb-1">Store Front / Logo Image</label>
            <input
              ref={logoInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"
              className="hidden"
              onChange={handleLogoUpload}
            />

            {storeLogoUrl ? (
              <div className="relative border border-slate-200 rounded-2xl p-2.5 bg-slate-50 flex items-center gap-3">
                <img
                  src={storeLogoUrl}
                  alt="Store Preview"
                  className="w-16 h-16 rounded-xl object-cover border border-slate-200 bg-white"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-slate-800 truncate">
                    {hasUploadedLogoToCloudinary ? 'Uploaded Store Photo' : 'Default Store Cover'}
                  </p>
                  {hasUploadedLogoToCloudinary ? (
                    <p className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Uploaded to Cloudinary
                    </p>
                  ) : (
                    <p className="text-[11px] text-slate-500 font-medium">
                      Tap Change to upload a logo from your phone gallery
                    </p>
                  )}
                  <div className="flex items-center gap-2 mt-1.5">
                    <button
                      type="button"
                      onClick={() => logoInputRef.current?.click()}
                      disabled={isLogoUploading}
                      className="px-2.5 py-1 text-[11px] font-bold bg-white text-slate-700 hover:text-emerald-700 rounded-lg border border-slate-200 shadow-xs flex items-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" /> Change
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setStoreLogoUrl('');
                        setHasUploadedLogoToCloudinary(false);
                      }}
                      disabled={isLogoUploading}
                      className="px-2.5 py-1 text-[11px] font-bold text-rose-600 hover:bg-rose-50 rounded-lg"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => logoInputRef.current?.click()}
                disabled={isLogoUploading}
                className="w-full border-2 border-dashed border-emerald-300 hover:border-emerald-500 bg-emerald-50/50 hover:bg-emerald-50 rounded-2xl p-3.5 flex items-center justify-center gap-2.5 text-emerald-800 font-bold text-xs transition-colors"
              >
                {isLogoUploading ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
                    <span>Uploading photo ({logoProgress}%)...</span>
                  </div>
                ) : (
                  <>
                    <Camera className="w-4 h-4 text-emerald-600" />
                    <span>Upload Store Logo from Phone Gallery</span>
                  </>
                )}
              </button>
            )}

            {isLogoUploading && (
              <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
                <div
                  className="bg-emerald-600 h-1.5 rounded-full transition-all duration-200"
                  style={{ width: `${logoProgress}%` }}
                />
              </div>
            )}
          </div>

          <div>
            <label className="text-slate-700 font-bold block mb-1">Business Description</label>
            <textarea
              rows={2}
              value={businessDescription}
              onChange={(e) => setBusinessDescription(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-700 outline-none resize-none"
            />
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 space-y-1">
            <div className="font-bold text-slate-900">📌 Platform Terms:</div>
            <div>• Monthly store subscription is ₹199 upon approval.</div>
            <div>• Delivery must be fulfilled within 10-15 minutes using your in-house staff.</div>
            <div>• Exactly 1 active supermarket is allowed per residential society.</div>
          </div>

          <div className="flex gap-2 pt-2">
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-3 text-slate-600 hover:bg-slate-100 rounded-xl font-bold cursor-pointer"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              disabled={isSubmitting}
              className={`${onClose ? 'flex-2' : 'w-full'} py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black rounded-xl shadow-md cursor-pointer transition transform active:scale-98`}
            >
              {isSubmitting ? 'Submitting Application...' : 'Submit for Admin Approval'}
            </button>
          </div>
        </form>
      </div>
    );

  if (inline) {
    return formContent;
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      {formContent}
    </div>
  );
};
