import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  ScanBarcode,
  ShoppingCart,
  Trash2,
  Plus,
  Minus,
  CheckCircle2,
  AlertCircle,
  Printer,
  Banknote,
  Smartphone,
  CreditCard,
  Split,
  Search,
  RotateCcw,
  Receipt,
  Package,
  Keyboard,
} from 'lucide-react';
import { Order, PaymentRecord, PosPaymentMethod, Product, Store } from '../../types';
import { useApp } from '../../context/AppContext';
import { CameraBarcodeScanner } from './CameraBarcodeScanner';
import { playScannerBeep, unlockAudioContext } from '../../utils/soundNotification';

interface PosCartItem {
  product: Product;
  quantity: number;
}

interface PosBillingPanelProps {
  store: Store;
  storeProducts: Product[];
}

export const PosBillingPanel: React.FC<PosBillingPanelProps> = ({ store, storeProducts }) => {
  const { findProductByBarcode, completePosSale } = useApp();

  // Scanner states
  const hardwareInputRef = useRef<HTMLInputElement | null>(null);
  const [hardwareInput, setHardwareInput] = useState('');
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [hidAutoCapture, setHidAutoCapture] = useState(true);
  const [scanFeedback, setScanFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
    barcode: string;
  } | null>(null);
  const lastScanEventRef = useRef<{ code: string; time: number }>({ code: '', time: 0 });
  const hidBufferRef = useRef<{ chars: string; lastKeyTime: number }>({
    chars: '',
    lastKeyTime: 0,
  });

  // Cart & catalog search
  const [posCart, setPosCart] = useState<PosCartItem[]>([]);
  const [quickSearch, setQuickSearch] = useState('');
  const [discountAmount, setDiscountAmount] = useState<number>(0);

  // Payment & customer state
  const [paymentMethod, setPaymentMethod] = useState<PosPaymentMethod>('CASH');
  const [cashTendered, setCashTendered] = useState<string>('');
  const [splitCash, setSplitCash] = useState<number>(0);
  const [splitUpi, setSplitUpi] = useState<number>(0);
  const [splitCard, setSplitCard] = useState<number>(0);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentError, setPaymentError] = useState('');

  // Completed receipt state
  const [completedReceipt, setCompletedReceipt] = useState<{
    order: Order;
    payment: PaymentRecord;
    cashTendered?: number;
    changeReturned?: number;
  } | null>(null);

  // Refocus hardware scanner input automatically when panel opens or receipt closes
  const focusHardwareInput = () => {
    window.setTimeout(() => {
      hardwareInputRef.current?.focus();
    }, 60);
  };

  useEffect(() => {
    if (!isCameraOpen && !completedReceipt) {
      focusHardwareInput();
    }
  }, [isCameraOpen, completedReceipt]);

  // Add product to POS cart with stock limit check (never decreases actual inventory before payment!)
  const addProductToPosCart = (product: Product, scannedCode?: string) => {
    if (!product.inStock || product.stockCount <= 0) {
      playScannerBeep(false);
      setScanFeedback({
        type: 'error',
        barcode: scannedCode || product.barcode || product.name,
        message: `"${product.name}" is currently out of stock (0 available).`,
      });
      return;
    }

    setPosCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        if (existing.quantity + 1 > product.stockCount) {
          playScannerBeep(false);
          setScanFeedback({
            type: 'error',
            barcode: scannedCode || product.barcode || '',
            message: `Stock limit reached for "${product.name}" (${product.stockCount} available).`,
          });
          return prev;
        }
        playScannerBeep(true);
        setScanFeedback({
          type: 'success',
          barcode: scannedCode || product.barcode || '',
          message: `Added ${product.name} (Qty: ${existing.quantity + 1})`,
        });
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }

      playScannerBeep(true);
      setScanFeedback({
        type: 'success',
        barcode: scannedCode || product.barcode || '',
        message: `Added ${product.name} — ₹${product.price}`,
      });
      return [...prev, { product, quantity: 1 }];
    });
  };

  // Core barcode lookup restricted strictly to logged-in owner's store
  const processScannedBarcode = (rawCode: string, source: 'camera' | 'hardware') => {
    const code = rawCode.trim();
    if (!code) return;

    const now = Date.now();
    // Prevent duplicate rapid-fire hardware/camera scan events within 150ms
    if (
      source === 'hardware' &&
      lastScanEventRef.current.code === code &&
      now - lastScanEventRef.current.time < 150
    ) {
      return;
    }
    lastScanEventRef.current = { code, time: now };

    unlockAudioContext().catch(() => {});

    const matchedProduct = findProductByBarcode(store.id, code);
    if (!matchedProduct) {
      playScannerBeep(false);
      setScanFeedback({
        type: 'error',
        barcode: code,
        message: `Barcode "${code}" is not registered in ${store.name}'s inventory. Assign it in Manage Products.`,
      });
      return;
    }

    addProductToPosCart(matchedProduct, code);
  };

  // Global USB / Bluetooth HID scanner capture when focus isn't inside another input field
  useEffect(() => {
    if (!hidAutoCapture || isCameraOpen || completedReceipt) return;

    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      const activeEl = document.activeElement as HTMLElement | null;
      const isHardwareFieldFocused = activeEl === hardwareInputRef.current;
      if (isHardwareFieldFocused) return;

      // Do not hijack typing inside other form inputs/textareas/selects
      const tag = activeEl?.tagName?.toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') {
        return;
      }

      const now = Date.now();
      if (now - hidBufferRef.current.lastKeyTime > 180) {
        hidBufferRef.current.chars = '';
      }
      hidBufferRef.current.lastKeyTime = now;

      if (e.key === 'Enter' || e.key === 'Tab') {
        if (hidBufferRef.current.chars.length >= 4) {
          e.preventDefault();
          const captured = hidBufferRef.current.chars;
          hidBufferRef.current.chars = '';
          processScannedBarcode(captured, 'hardware');
          focusHardwareInput();
        } else {
          hidBufferRef.current.chars = '';
        }
        return;
      }

      if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        hidBufferRef.current.chars += e.key;
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [hidAutoCapture, isCameraOpen, completedReceipt, storeProducts, store.id]);

  const handleHardwareKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === 'Tab') {
      e.preventDefault();
      const code = hardwareInput.trim();
      setHardwareInput('');
      if (code) {
        processScannedBarcode(code, 'hardware');
      }
      focusHardwareInput();
    }
  };

  const updateItemQty = (productId: string, nextQty: number) => {
    if (nextQty <= 0) {
      setPosCart((prev) => prev.filter((item) => item.product.id !== productId));
      focusHardwareInput();
      return;
    }

    setPosCart((prev) =>
      prev.map((item) => {
        if (item.product.id !== productId) return item;
        const maxStock = item.product.stockCount;
        if (nextQty > maxStock) {
          setScanFeedback({
            type: 'error',
            barcode: item.product.barcode || '',
            message: `Maximum available stock for "${item.product.name}" is ${maxStock} units.`,
          });
          return { ...item, quantity: maxStock };
        }
        return { ...item, quantity: nextQty };
      })
    );
  };

  const removeItem = (productId: string) => {
    setPosCart((prev) => prev.filter((item) => item.product.id !== productId));
    focusHardwareInput();
  };

  // Totals calculation
  const subtotal = posCart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const effectiveDiscount = Math.max(0, Math.min(subtotal, Number(discountAmount || 0)));
  const grandTotal = Math.max(0, Number((subtotal - effectiveDiscount).toFixed(2)));
  const totalItems = posCart.reduce((sum, item) => sum + item.quantity, 0);
  const splitSum = Number((splitCash + splitUpi + splitCard).toFixed(2));
  const splitRemaining = Number((grandTotal - splitSum).toFixed(2));
  const parsedCashTendered = Number(cashTendered || 0);
  const changeToReturn =
    paymentMethod === 'CASH' && parsedCashTendered > grandTotal
      ? Number((parsedCashTendered - grandTotal).toFixed(2))
      : 0;

  // Quick fill remaining helper for split payments
  const fillRemainingSplit = (target: 'cash' | 'upi' | 'card') => {
    if (splitRemaining <= 0) return;
    if (target === 'cash') setSplitCash(Number((splitCash + splitRemaining).toFixed(2)));
    if (target === 'upi') setSplitUpi(Number((splitUpi + splitRemaining).toFixed(2)));
    if (target === 'card') setSplitCard(Number((splitCard + splitRemaining).toFixed(2)));
  };

  // Complete POS Payment & Update Stock Safely
  const handleCheckout = async () => {
    setPaymentError('');
    if (posCart.length === 0) {
      setPaymentError('Scan or add at least one product to generate a bill.');
      return;
    }

    if (paymentMethod === 'SPLIT' && Math.abs(splitRemaining) > 0.01) {
      setPaymentError(
        `Split payment amounts (₹${splitSum}) must equal Grand Total (₹${grandTotal}). Remaining: ₹${splitRemaining}`
      );
      return;
    }

    if (
      paymentMethod === 'CASH' &&
      cashTendered.trim() !== '' &&
      parsedCashTendered < grandTotal
    ) {
      setPaymentError(
        `Cash tendered (₹${parsedCashTendered}) is less than Grand Total (₹${grandTotal}).`
      );
      return;
    }

    setIsProcessingPayment(true);
    try {
      const result = await completePosSale({
        storeId: store.id,
        items: posCart.map((c) => ({ productId: c.product.id, quantity: c.quantity })),
        discountAmount: effectiveDiscount,
        paymentMethod,
        ...(paymentMethod === 'SPLIT'
          ? {
              splitPaymentDetails: {
                cash: Number(splitCash || 0),
                upi: Number(splitUpi || 0),
                card: Number(splitCard || 0),
              },
            }
          : {}),
        customerName: customerName.trim() || undefined,
        customerPhone: customerPhone.trim() || undefined,
      });

      setCompletedReceipt({
        order: result.order,
        payment: result.payment,
        cashTendered:
          paymentMethod === 'CASH' && parsedCashTendered > 0
            ? parsedCashTendered
            : undefined,
        changeReturned:
          paymentMethod === 'CASH' && changeToReturn > 0 ? changeToReturn : undefined,
      });

      // Reset cart cleanly after confirmed payment
      setPosCart([]);
      setDiscountAmount(0);
      setCashTendered('');
      setSplitCash(0);
      setSplitUpi(0);
      setSplitCard(0);
      setCustomerName('');
      setCustomerPhone('');
      setScanFeedback(null);
    } catch (err: any) {
      setPaymentError(err?.message || 'Payment failed. Inventory was not modified.');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const handleStartNewBill = () => {
    setCompletedReceipt(null);
    setPaymentError('');
    focusHardwareInput();
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  const searchMatches = quickSearch.trim()
    ? storeProducts.filter((p) => {
        const q = quickSearch.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          (p.barcode && p.barcode.toLowerCase().includes(q)) ||
          (p.barcodeAliases && p.barcodeAliases.some((a) => a.toLowerCase().includes(q)))
        );
      })
    : [];

  return (
    <div className="space-y-5 animate-in fade-in-50 duration-150">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              POS Billing & Dual Barcode Scanner
            </h2>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-200">
              LIVE INVENTORY
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Scan products using your phone camera or a USB/Bluetooth HID barcode scanner for {store.name}.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setHidAutoCapture((prev) => !prev)}
            className={`px-3 py-2 rounded-xl text-xs font-bold border flex items-center gap-1.5 cursor-pointer transition ${
              hidAutoCapture
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-slate-50 text-slate-600 border-slate-200'
            }`}
            title="Capture USB / Bluetooth HID scanner input even if cursor is outside the box"
          >
            <Keyboard className="w-3.5 h-3.5 text-emerald-400" />
            <span>HID Auto-Listen: {hidAutoCapture ? 'ON' : 'OFF'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              unlockAudioContext().catch(() => {});
              setIsCameraOpen(true);
            }}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-black text-xs rounded-xl shadow-md flex items-center gap-2 cursor-pointer transition"
          >
            <Camera className="w-4 h-4" />
            <span>Camera Scanner</span>
          </button>
        </div>
      </div>

      {/* Main Responsive Split Grid: Left = Scanners + Cart, Right = Payment & Totals */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* LEFT COLUMN (7 cols on lg): Dual Scanner Controls + Billing Cart */}
        <div className="lg:col-span-7 space-y-4">
          {/* Dual Scanner Strip */}
          <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between gap-2">
              <label
                htmlFor="pos-hardware-barcode-input"
                className="text-xs font-black text-slate-800 flex items-center gap-1.5"
              >
                <ScanBarcode className="w-4 h-4 text-emerald-600" />
                <span>Hardware Scanner Input (USB / Bluetooth HID)</span>
              </label>
              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                Enter / Tab Auto-Add
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <ScanBarcode className="w-4 h-4 text-emerald-600 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="pos-hardware-barcode-input"
                  ref={hardwareInputRef}
                  type="text"
                  value={hardwareInput}
                  onChange={(e) => setHardwareInput(e.target.value)}
                  onKeyDown={handleHardwareKeyDown}
                  placeholder="Scan barcode here (USB / Bluetooth HID) or type & press Enter..."
                  autoComplete="off"
                  className="w-full pl-10 pr-3 py-3 bg-emerald-50/40 focus:bg-white border-2 border-emerald-300 focus:border-emerald-600 rounded-2xl text-xs font-mono font-bold text-slate-900 outline-none transition"
                />
              </div>

              <button
                type="button"
                onClick={() => {
                  const code = hardwareInput.trim();
                  setHardwareInput('');
                  if (code) processScannedBarcode(code, 'hardware');
                  focusHardwareInput();
                }}
                className="px-4 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-2xl cursor-pointer transition shrink-0"
              >
                Add Code
              </button>
            </div>

            {/* Live Scan Feedback Banner */}
            {scanFeedback && (
              <div
                className={`p-3 rounded-2xl text-xs font-bold flex items-center justify-between gap-2 animate-in fade-in-50 duration-150 ${
                  scanFeedback.type === 'success'
                    ? 'bg-emerald-50 border border-emerald-200 text-emerald-900'
                    : 'bg-rose-50 border border-rose-200 text-rose-900'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  {scanFeedback.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  <span className="truncate">{scanFeedback.message}</span>
                </div>
                {scanFeedback.barcode && (
                  <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-white/80 border border-current/15 shrink-0">
                    {scanFeedback.barcode}
                  </span>
                )}
              </div>
            )}

            {/* Quick Store Product Search (Optional fallback for unlabelled loose items) */}
            <div className="pt-1 border-t border-slate-100">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={quickSearch}
                  onChange={(e) => setQuickSearch(e.target.value)}
                  placeholder="Quick search store catalog by item name or barcode..."
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-500"
                />
              </div>

              {quickSearch.trim() && (
                <div className="mt-2 max-h-48 overflow-y-auto divide-y divide-slate-100 border border-slate-200 rounded-2xl bg-white">
                  {searchMatches.length === 0 ? (
                    <div className="p-3 text-center text-xs text-slate-400">
                      No matching products in {store.name}
                    </div>
                  ) : (
                    searchMatches.slice(0, 8).map((prod) => (
                      <button
                        key={prod.id}
                        type="button"
                        onClick={() => {
                          addProductToPosCart(prod);
                          setQuickSearch('');
                          focusHardwareInput();
                        }}
                        className="w-full p-2.5 hover:bg-emerald-50 flex items-center justify-between gap-3 text-left text-xs cursor-pointer transition"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <img
                            src={prod.imageUrl}
                            alt={prod.name}
                            className="w-8 h-8 rounded-lg object-cover bg-slate-100 shrink-0"
                          />
                          <div className="min-w-0">
                            <div className="font-bold text-slate-900 truncate">{prod.name}</div>
                            <div className="text-[10px] text-slate-500 flex items-center gap-2">
                              <span>{prod.unit}</span>
                              <span>• Stock: {prod.stockCount}</span>
                              {prod.barcode && (
                                <span className="font-mono text-slate-400">#{prod.barcode}</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <span className="font-black text-emerald-700 shrink-0">₹{prod.price}</span>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>

          {/* POS Billing Cart Table */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-emerald-600" />
                <h3 className="font-black text-sm text-slate-900">
                  Billing Cart ({totalItems} {totalItems === 1 ? 'item' : 'items'})
                </h3>
              </div>
              {posCart.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    setPosCart([]);
                    setScanFeedback(null);
                    focusHardwareInput();
                  }}
                  className="text-xs font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Clear Bill</span>
                </button>
              )}
            </div>

            {posCart.length === 0 ? (
              <div className="p-10 text-center space-y-2">
                <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                  <ScanBarcode className="w-6 h-6" />
                </div>
                <div className="text-sm font-bold text-slate-700">Ready to Scan Items</div>
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  Scan a product barcode with your USB/Bluetooth scanner or tap &quot;Camera Scanner&quot; above.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {posCart.map(({ product, quantity }) => (
                  <div
                    key={product.id}
                    className="p-3.5 sm:px-5 flex flex-wrap sm:flex-nowrap items-center justify-between gap-3 hover:bg-slate-50/70"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="w-12 h-12 rounded-xl object-cover border border-slate-200 bg-slate-100 shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="font-bold text-xs sm:text-sm text-slate-900 truncate">
                          {product.name}
                        </div>
                        <div className="text-[11px] text-slate-500 flex flex-wrap items-center gap-x-2">
                          <span className="font-semibold text-emerald-700">₹{product.price}</span>
                          <span>/ {product.unit}</span>
                          {product.barcode && (
                            <span className="font-mono text-[10px] text-slate-400">
                              [{product.barcode}]
                            </span>
                          )}
                          <span className="text-[10px] text-slate-400">
                            (Stock: {product.stockCount})
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 ml-auto">
                      {/* Quantity Controls */}
                      <div className="flex items-center border border-slate-200 rounded-xl bg-white overflow-hidden shadow-2xs">
                        <button
                          type="button"
                          onClick={() => updateItemQty(product.id, quantity - 1)}
                          className="p-2 text-slate-600 hover:bg-slate-100 cursor-pointer"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <input
                          type="number"
                          min={1}
                          max={product.stockCount}
                          value={quantity}
                          onChange={(e) =>
                            updateItemQty(product.id, Math.max(1, Number(e.target.value) || 1))
                          }
                          className="w-11 text-center text-xs font-black text-slate-900 outline-none py-1.5"
                        />
                        <button
                          type="button"
                          onClick={() => updateItemQty(product.id, quantity + 1)}
                          className="p-2 text-slate-600 hover:bg-slate-100 cursor-pointer"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Line Total */}
                      <div className="w-16 text-right font-black text-sm text-slate-900">
                        ₹{(product.price * quantity).toFixed(0)}
                      </div>

                      {/* Remove Button */}
                      <button
                        type="button"
                        onClick={() => removeItem(product.id)}
                        className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl cursor-pointer transition"
                        title="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN (5 cols on lg): Totals, Payment Modes & Checkout */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-black text-sm text-slate-900 flex items-center gap-2 pb-3 border-b border-slate-100">
              <Receipt className="w-4 h-4 text-emerald-600" />
              <span>Bill Summary & Payment</span>
            </h3>

            {/* Optional Customer Info */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="text-[11px] font-bold text-slate-500 block mb-1">
                  Customer Name (Opt.)
                </label>
                <input
                  type="text"
                  placeholder="Walk-in Customer"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-500 block mb-1">
                  Mobile No. (Opt.)
                </label>
                <input
                  type="tel"
                  placeholder="10-digit phone"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Calculations */}
            <div className="bg-slate-50 rounded-2xl p-4 space-y-2 text-xs border border-slate-100">
              <div className="flex justify-between text-slate-600">
                <span>Items Subtotal ({totalItems} units)</span>
                <span className="font-bold text-slate-900">₹{subtotal.toFixed(2)}</span>
              </div>

              <div className="flex items-center justify-between text-slate-600">
                <span>Counter Discount (₹)</span>
                <input
                  type="number"
                  min={0}
                  max={subtotal}
                  value={discountAmount || ''}
                  placeholder="0"
                  onChange={(e) => setDiscountAmount(Math.max(0, Number(e.target.value) || 0))}
                  className="w-24 text-right bg-white border border-slate-200 rounded-lg px-2 py-1 font-bold text-slate-900 outline-none focus:border-emerald-500"
                />
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-between items-center">
                <span className="font-black text-sm text-slate-900">Grand Total</span>
                <span className="font-black text-2xl text-emerald-700">₹{grandTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-700 block">Payment Mode</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(
                  [
                    { id: 'CASH', label: 'Cash', icon: <Banknote className="w-4 h-4" /> },
                    { id: 'UPI', label: 'UPI', icon: <Smartphone className="w-4 h-4" /> },
                    { id: 'CARD', label: 'Card', icon: <CreditCard className="w-4 h-4" /> },
                    { id: 'SPLIT', label: 'Split', icon: <Split className="w-4 h-4" /> },
                  ] as const
                ).map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      setPaymentMethod(m.id);
                      setPaymentError('');
                    }}
                    className={`py-2.5 px-2 rounded-xl border text-xs font-black flex flex-col items-center justify-center gap-1 cursor-pointer transition ${
                      paymentMethod === m.id
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {m.icon}
                    <span>{m.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Cash Tendered Helper */}
            {paymentMethod === 'CASH' && grandTotal > 0 && (
              <div className="bg-emerald-50/60 border border-emerald-200 rounded-2xl p-3 space-y-2 text-xs">
                <div className="flex items-center justify-between gap-2">
                  <label className="font-bold text-slate-700">Cash Tendered (₹)</label>
                  <input
                    type="number"
                    min={0}
                    placeholder={grandTotal.toString()}
                    value={cashTendered}
                    onChange={(e) => setCashTendered(e.target.value)}
                    className="w-28 text-right bg-white border border-emerald-300 rounded-xl px-3 py-1.5 font-black text-slate-900 outline-none"
                  />
                </div>
                {changeToReturn > 0 && (
                  <div className="flex justify-between font-black text-emerald-800 pt-1 border-t border-emerald-200">
                    <span>Change to Return:</span>
                    <span>₹{changeToReturn.toFixed(2)}</span>
                  </div>
                )}
              </div>
            )}

            {/* Split Payment Breakdown */}
            {paymentMethod === 'SPLIT' && (
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-2.5 text-xs">
                <div className="flex items-center justify-between font-bold text-slate-700">
                  <span>Split Breakdown</span>
                  <span
                    className={
                      Math.abs(splitRemaining) <= 0.01 ? 'text-emerald-700' : 'text-rose-600'
                    }
                  >
                    {Math.abs(splitRemaining) <= 0.01
                      ? 'Matched ✓'
                      : `Remaining: ₹${splitRemaining.toFixed(2)}`}
                  </span>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-14 font-bold text-slate-600">Cash ₹</span>
                    <input
                      type="number"
                      min={0}
                      value={splitCash || ''}
                      placeholder="0"
                      onChange={(e) => setSplitCash(Math.max(0, Number(e.target.value) || 0))}
                      className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-1.5 font-bold outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => fillRemainingSplit('cash')}
                      className="px-2 py-1 bg-slate-200 hover:bg-slate-300 rounded-lg text-[10px] font-bold cursor-pointer"
                    >
                      Fill
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="w-14 font-bold text-slate-600">UPI ₹</span>
                    <input
                      type="number"
                      min={0}
                      value={splitUpi || ''}
                      placeholder="0"
                      onChange={(e) => setSplitUpi(Math.max(0, Number(e.target.value) || 0))}
                      className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-1.5 font-bold outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => fillRemainingSplit('upi')}
                      className="px-2 py-1 bg-slate-200 hover:bg-slate-300 rounded-lg text-[10px] font-bold cursor-pointer"
                    >
                      Fill
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="w-14 font-bold text-slate-600">Card ₹</span>
                    <input
                      type="number"
                      min={0}
                      value={splitCard || ''}
                      placeholder="0"
                      onChange={(e) => setSplitCard(Math.max(0, Number(e.target.value) || 0))}
                      className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-1.5 font-bold outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => fillRemainingSplit('card')}
                      className="px-2 py-1 bg-slate-200 hover:bg-slate-300 rounded-lg text-[10px] font-bold cursor-pointer"
                    >
                      Fill
                    </button>
                  </div>
                </div>
              </div>
            )}

            {paymentError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>{paymentError}</span>
              </div>
            )}

            <button
              type="button"
              disabled={posCart.length === 0 || isProcessingPayment}
              onClick={handleCheckout}
              className={`w-full py-4 rounded-2xl font-black text-sm shadow-lg transition flex items-center justify-center gap-2 ${
                posCart.length === 0 || isProcessingPayment
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                  : 'bg-emerald-600 hover:bg-emerald-700 active:scale-99 text-white cursor-pointer shadow-emerald-600/20'
              }`}
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>
                {isProcessingPayment
                  ? 'Processing Payment & Updating Stock...'
                  : `Complete ${paymentMethod} Payment • ₹${grandTotal.toFixed(2)}`}
              </span>
            </button>

            <p className="text-[10px] text-center text-slate-400 flex items-center justify-center gap-1">
              <Package className="w-3 h-3" />
              <span>Stock is safely deducted from {store.name} only after payment succeeds.</span>
            </p>
          </div>
        </div>
      </div>

      {/* Camera Barcode Scanner Modal */}
      <CameraBarcodeScanner
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onDetected={(code) => processScannedBarcode(code, 'camera')}
        continuous={true}
        title={`Scan Item for ${store.name}`}
      />

      {/* Completed Payment & Printable Receipt Modal */}
      {completedReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4 my-6 animate-in zoom-in-95 duration-150">
            <div className="no-print flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-emerald-700 font-black text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span>Payment Confirmed & Stock Updated</span>
              </div>
            </div>

            {/* Printable Thermal / A4 Receipt Body */}
            <div
              id="pos-printable-receipt"
              className="bg-slate-50 border border-dashed border-slate-300 rounded-2xl p-4 font-mono text-xs text-slate-900 space-y-3"
            >
              <div className="text-center border-b border-dashed border-slate-300 pb-3 space-y-0.5">
                <div className="text-sm font-black uppercase tracking-wide">{store.name}</div>
                {store.address && <div className="text-[10px] text-slate-600">{store.address}</div>}
                <div className="text-[10px] text-slate-600">Ph: {store.ownerPhone}</div>
                <div className="text-[10px] font-bold pt-1">TAX INVOICE / POS RECEIPT</div>
              </div>

              <div className="text-[10px] space-y-0.5 border-b border-dashed border-slate-300 pb-2">
                <div className="flex justify-between">
                  <span>Bill No:</span>
                  <span className="font-bold">{completedReceipt.order.id}</span>
                </div>
                <div className="flex justify-between">
                  <span>Date:</span>
                  <span>{new Date(completedReceipt.order.createdAt).toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span>Customer:</span>
                  <span>
                    {completedReceipt.order.customerName}
                    {completedReceipt.order.customerPhone !== 'Counter Sale'
                      ? ` (${completedReceipt.order.customerPhone})`
                      : ''}
                  </span>
                </div>
              </div>

              <table className="w-full text-[11px]">
                <thead>
                  <tr className="border-b border-slate-300 text-left">
                    <th className="py-1">Item</th>
                    <th className="py-1 text-center">Qty</th>
                    <th className="py-1 text-right">Rate</th>
                    <th className="py-1 text-right">Amt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/70">
                  {(completedReceipt.order.items || []).map((item) => (
                    <tr key={item.id}>
                      <td className="py-1.5 pr-1 font-semibold leading-tight">{item.name}</td>
                      <td className="py-1.5 text-center">{item.quantity}</td>
                      <td className="py-1.5 text-right">{item.unitPrice}</td>
                      <td className="py-1.5 text-right font-bold">{item.totalPrice}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="border-t border-dashed border-slate-300 pt-2 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span>Subtotal ({completedReceipt.order.itemCount} items)</span>
                  <span>₹{completedReceipt.order.subtotal.toFixed(2)}</span>
                </div>
                {completedReceipt.order.discountAmount ? (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount</span>
                    <span>-₹{completedReceipt.order.discountAmount.toFixed(2)}</span>
                  </div>
                ) : null}
                <div className="flex justify-between font-black text-sm pt-1 border-t border-slate-300">
                  <span>NET PAYABLE</span>
                  <span>₹{completedReceipt.order.totalAmount.toFixed(2)}</span>
                </div>
              </div>

              <div className="border-t border-dashed border-slate-300 pt-2 text-[10px] space-y-0.5">
                <div className="flex justify-between font-bold">
                  <span>Payment Mode:</span>
                  <span>{completedReceipt.order.paymentMethod}</span>
                </div>
                {completedReceipt.order.splitPaymentDetails && (
                  <div className="text-[10px] text-slate-600">
                    Cash: ₹{completedReceipt.order.splitPaymentDetails.cash} • UPI: ₹
                    {completedReceipt.order.splitPaymentDetails.upi} • Card: ₹
                    {completedReceipt.order.splitPaymentDetails.card}
                  </div>
                )}
                {completedReceipt.cashTendered !== undefined && (
                  <div className="flex justify-between text-slate-600">
                    <span>Cash Tendered / Change:</span>
                    <span>
                      ₹{completedReceipt.cashTendered} / ₹{completedReceipt.changeReturned || 0}
                    </span>
                  </div>
                )}
                <div className="flex justify-between text-slate-500">
                  <span>Txn Ref:</span>
                  <span>{completedReceipt.payment.transactionReference}</span>
                </div>
              </div>

              <div className="text-center text-[10px] text-slate-500 pt-2 border-t border-dashed border-slate-300">
                Thank you for shopping at {store.name}!
              </div>
            </div>

            <div className="no-print flex gap-2.5 pt-1">
              <button
                type="button"
                onClick={handlePrintReceipt}
                className="flex-1 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Receipt</span>
              </button>
              <button
                type="button"
                onClick={handleStartNewBill}
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer"
              >
                <ScanBarcode className="w-4 h-4" />
                <span>New Bill</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
