import { auth } from '../firebase';

export interface CloudinaryUploadProgress {
  progress: number;
  bytesTransferred: number;
  totalBytes: number;
}

export interface CloudinaryUploadResult {
  secureUrl: string;
  publicId: string;
}

const MAX_IMAGE_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB

export function resolveImageMimeType(file: File): string {
  const rawType = (file.type || '').toLowerCase();
  if (['image/jpeg', 'image/jpg', 'image/png', 'image/webp'].includes(rawType)) {
    return rawType === 'image/jpg' ? 'image/jpeg' : rawType;
  }
  const ext = file.name.split('.').pop()?.toLowerCase() || '';
  if (ext === 'jpg' || ext === 'jpeg') return 'image/jpeg';
  if (ext === 'png') return 'image/png';
  if (ext === 'webp') return 'image/webp';
  return '';
}

export function getCloudinaryConfig(): {
  cloudName: string;
  uploadPreset: string;
  isConfigured: boolean;
} {
  const runtimeCfg =
    typeof window !== 'undefined'
      ? ((window as unknown as { __CLOUDINARY_CONFIG__?: { cloudName?: string; uploadPreset?: string } })
          .__CLOUDINARY_CONFIG__)
      : undefined;
  const cloudName = String(
    runtimeCfg?.cloudName || import.meta.env?.VITE_CLOUDINARY_CLOUD_NAME || ''
  ).trim();
  const uploadPreset = String(
    runtimeCfg?.uploadPreset || import.meta.env?.VITE_CLOUDINARY_UPLOAD_PRESET || ''
  ).trim();

  const isPlaceholder =
    !cloudName ||
    !uploadPreset ||
    cloudName.startsWith('VITE_') ||
    uploadPreset.startsWith('VITE_') ||
    cloudName === 'your_cloudinary_cloud_name' ||
    uploadPreset === 'your_unsigned_upload_preset';

  return {
    cloudName,
    uploadPreset,
    isConfigured: !isPlaceholder,
  };
}

export async function uploadImageToCloudinary(
  file: File,
  onProgress?: (progress: number, info?: CloudinaryUploadProgress) => void
): Promise<CloudinaryUploadResult> {
  // 1. Require Firebase Authentication before allowing any upload
  if (!auth.currentUser) {
    throw new Error(
      'Firebase authentication is required before uploading images. Please click "Sign in with Google (Firebase Auth)" first.'
    );
  }

  // 2. Validate Cloudinary public environment configuration (never expose API Secret)
  const { cloudName, uploadPreset, isConfigured } = getCloudinaryConfig();
  if (!isConfigured) {
    throw new Error(
      'Cloudinary is not configured yet. Set VITE_CLOUDINARY_CLOUD_NAME and VITE_CLOUDINARY_UPLOAD_PRESET in your environment variables.'
    );
  }

  // 3. Validate image format (JPG, JPEG, PNG, WEBP)
  const mimeType = resolveImageMimeType(file);
  if (!mimeType) {
    throw new Error('Unsupported format. Please select a JPG, JPEG, PNG, or WEBP image.');
  }

  // 4. Validate image size on client before upload (max 5 MB)
  if (file.size > MAX_IMAGE_SIZE_BYTES) {
    throw new Error('Image file exceeds 5 MB limit. Please select a smaller photo from your gallery.');
  }

  const endpoint = `https://api.cloudinary.com/v1_1/${encodeURIComponent(cloudName)}/image/upload`;
  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', uploadPreset);

  return new Promise<CloudinaryUploadResult>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', endpoint, true);
    xhr.timeout = 45000;

    xhr.upload.addEventListener('progress', (event) => {
      if (event.lengthComputable && event.total > 0) {
        const progress = Math.min(99, Math.round((event.loaded / event.total) * 100));
        onProgress?.(progress, {
          progress,
          bytesTransferred: event.loaded,
          totalBytes: event.total,
        });
      }
    });

    xhr.addEventListener('load', () => {
      let parsed: any = null;
      try {
        parsed = JSON.parse(xhr.responseText);
      } catch {
        parsed = null;
      }

      if (xhr.status >= 200 && xhr.status < 300 && parsed?.secure_url && parsed?.public_id) {
        onProgress?.(100, {
          progress: 100,
          bytesTransferred: file.size,
          totalBytes: file.size,
        });
        resolve({
          secureUrl: String(parsed.secure_url),
          publicId: String(parsed.public_id),
        });
        return;
      }

      const rawMessage = parsed?.error?.message ? String(parsed.error.message) : '';
      let apiMessage =
        rawMessage ||
        `Cloudinary upload failed (HTTP ${xhr.status}). Verify your Cloud Name and Unsigned Upload Preset settings.`;

      if (/upload preset not found/i.test(rawMessage)) {
        apiMessage = `Cloudinary upload preset "${uploadPreset}" does not exist in cloud "${cloudName}". Create it in Cloudinary Dashboard -> Settings -> Upload -> Upload presets with Signing Mode set to "Unsigned".`;
      } else if (
        /whitelisted for unsigned|must be unsigned|unknown api key|missing required parameter.*api_key/i.test(
          rawMessage
        )
      ) {
        apiMessage = `Cloudinary rejected the unsigned upload ("${rawMessage}"). Open Cloudinary Dashboard -> Settings -> Upload -> Upload presets -> "${uploadPreset}" and change Signing Mode from "Signed" to "Unsigned".`;
      } else if (/invalid cloud_name|disabled/i.test(rawMessage) || xhr.status === 404) {
        apiMessage = `Cloudinary cloud name "${cloudName}" was not found or is disabled (${rawMessage || `HTTP ${xhr.status}`}).`;
      }

      reject(new Error(apiMessage));
    });

    xhr.addEventListener('error', () => {
      reject(new Error('Network error while uploading to Cloudinary. Please check your internet connection and retry.'));
    });

    xhr.addEventListener('timeout', () => {
      reject(new Error('Upload timed out. Please check your connection and try a smaller photo.'));
    });

    xhr.send(formData);
  });
}
