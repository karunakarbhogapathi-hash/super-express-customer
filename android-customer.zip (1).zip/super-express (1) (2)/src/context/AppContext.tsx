import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserProfile,
  UserRole,
  Apartment,
  Store,
  Category,
  Product,
  Order,
  CartItem,
  Subscription,
  DeliveryPartner,
  NotificationItem,
  PaymentRecord,
  OrderStatus,
  PaymentMethod,
  PosPaymentMethod,
  SplitPaymentDetails,
} from '../types';
import {
  INITIAL_APARTMENTS,
  INITIAL_STORES,
  INITIAL_CATEGORIES,
  INITIAL_PRODUCTS,
  INITIAL_DELIVERY_PARTNERS,
} from '../data/seedData';
import { auth, db, signInWithGoogleForFirebase } from '../firebase';
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  runTransaction,
  onSnapshot,
  query,
  where,
} from 'firebase/firestore';

interface AppContextType {
  role: UserRole;
  setRole: (role: UserRole) => void;
  currentUser: UserProfile;
  setCurrentUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  apartments: Apartment[];
  stores: Store[];
  categories: Category[];
  products: Product[];
  orders: Order[];
  subscriptions: Subscription[];
  deliveryPartners: DeliveryPartner[];
  notifications: NotificationItem[];
  payments: PaymentRecord[];
  cart: CartItem[];
  cartTotal: number;
  cartCount: number;
  activeApartment: Apartment | null;
  activeStore: Store | null;
  selectApartment: (apartmentId: string) => void;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  createOrder: (data: {
    paymentMethod: PaymentMethod;
    deliveryAddress: string;
    flatNumber: string;
    block: string;
    notes?: string;
  }) => Promise<Order>;
  verifyOnlinePayment: (orderId: string, method: 'UPI' | 'CARD' | 'NETBANKING') => Promise<boolean>;
  updateOrderStatus: (orderId: string, status: OrderStatus, deliveryPartnerId?: string) => Promise<void>;
  assignDeliveryPartner: (orderId: string, partnerId: string) => Promise<void>;
  verifyDeliveryOtp: (orderId: string, otp: string) => Promise<boolean>;
  // Supermarket Owner Actions
  ownerUser: UserProfile | null;
  ownerStore: Store | null;
  registerOwner: (name: string, phone: string, email?: string) => Promise<UserProfile>;
  loginOwner: (phone: string) => Promise<UserProfile | null>;
  logoutOwner: () => void;
  createStoreApplication: (data: {
    name: string;
    ownerName: string;
    ownerPhone: string;
    ownerEmail?: string;
    address: string;
    apartmentId: string;
    logoUrl?: string;
    description?: string;
    openingTime: string;
    closingTime: string;
  }) => Promise<Store>;
  approveStoreApplication: (storeId: string) => Promise<{ success: boolean; message?: string }>;
  rejectStoreApplication: (storeId: string, reason: string) => Promise<void>;
  addDeliveryBoy: (storeId: string, name: string, phone: string) => Promise<void>;
  toggleDeliveryBoy: (storeId: string, boyId: string) => Promise<void>;
  toggleStoreAvailability: (storeId: string) => Promise<void>;
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => Promise<void>;
  updateProduct: (productId: string, updates: Partial<Product>) => Promise<void>;
  deleteProduct: (productId: string) => Promise<void>;
  toggleProductStock: (productId: string) => Promise<void>;
  findProductByBarcode: (storeId: string, barcode: string) => Product | undefined;
  checkBarcodeDuplicate: (
    storeId: string,
    barcodes: string[],
    excludeProductId?: string
  ) => { barcode: string; existingProduct: Product } | null;
  completePosSale: (data: {
    storeId: string;
    items: { productId: string; quantity: number }[];
    discountAmount?: number;
    paymentMethod: PosPaymentMethod;
    splitPaymentDetails?: SplitPaymentDetails;
    customerName?: string;
    customerPhone?: string;
  }) => Promise<{ order: Order; payment: PaymentRecord }>;
  paySubscription: (storeId: string, paymentMethod: 'UPI' | 'CARD') => Promise<void>;
  // Admin Actions
  addApartment: (apt: Omit<Apartment, 'id' | 'createdAt'>) => Promise<void>;
  assignStoreToApartment: (apartmentId: string, storeId: string) => Promise<void>;
  updateStoreStatus: (storeId: string, status: Store['status']) => Promise<void>;
  markNotificationAsRead: (id: string) => void;
  addNotification: (item: Omit<NotificationItem, 'id' | 'createdAt' | 'isRead'>) => void;
  // Standalone Customer App Auth & Sync
  appMode: 'unified' | 'customer';
  customerAuthLoading: boolean;
  customerFirebaseUser: User | null;
  customerAuthError: string | null;
  clearCustomerAuthError: () => void;
  loginCustomerWithEmail: (email: string, password: string) => Promise<void>;
  registerCustomerWithEmail: (data: {
    name: string;
    email: string;
    password: string;
    phone: string;
    apartmentId: string;
    block: string;
    flatNumber: string;
  }) => Promise<void>;
  loginCustomerWithGoogle: () => Promise<void>;
  logoutCustomer: () => Promise<void>;
  updateCustomerProfile: (updates: {
    name?: string;
    phone?: string;
    apartmentId?: string;
    block?: string;
    flatNumber?: string;
  }) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'superexpress_';

function getStorageWithPrefix<T>(prefix: string, key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(prefix + key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function setStorageWithPrefix<T>(prefix: string, key: string, value: T) {
  try {
    localStorage.setItem(prefix + key, JSON.stringify(value));
  } catch (e) {
    console.error('Storage write error', e);
  }
}

export const AppProvider: React.FC<{
  children: React.ReactNode;
  appMode?: 'unified' | 'customer';
}> = ({ children, appMode = 'unified' }) => {
  const activePrefix = appMode === 'customer' ? 'superexpress_customer_' : STORAGE_KEY_PREFIX;
  const getInitialStorage = <T,>(key: string, defaultValue: T): T =>
    getStorageWithPrefix(activePrefix, key, defaultValue);
  const setStorage = <T,>(key: string, value: T) => setStorageWithPrefix(activePrefix, key, value);

  const [role, setRoleState] = useState<UserRole>(() =>
    appMode === 'customer' ? 'customer' : getInitialStorage('role', 'customer')
  );
  const [customerAuthLoading, setCustomerAuthLoading] = useState<boolean>(appMode === 'customer');
  const [customerFirebaseUser, setCustomerFirebaseUser] = useState<User | null>(null);
  const [customerAuthError, setCustomerAuthError] = useState<string | null>(null);

  const [currentUser, setCurrentUser] = useState<UserProfile>(() =>
    getInitialStorage('currentUser', {
      id: 'cust-emerald-01',
      name: 'Rohan Sharma',
      phone: '+91 98200 11223',
      email: 'rohan.sharma@example.com',
      role: 'customer',
      apartmentId: 'apt-emerald-heights',
      apartmentName: 'Emerald Heights Residences',
      flatNumber: '402',
      block: 'Tower B',
      isVerified: true,
      createdAt: new Date().toISOString(),
    })
  );

  const [ownerUser, setOwnerUserState] = useState<UserProfile | null>(() =>
    getInitialStorage<UserProfile | null>('ownerUser', {
      id: 'owner-freshmart-01',
      name: 'Suresh Kumar',
      phone: '+91 98450 12345',
      email: 'suresh.freshmart@example.com',
      role: 'store_owner',
      storeId: 'store-freshmart',
      isVerified: true,
      createdAt: '2026-01-02T00:00:00Z',
    })
  );

  const [apartments, setApartments] = useState<Apartment[]>(() =>
    getInitialStorage('apartments', INITIAL_APARTMENTS)
  );

  const [stores, setStores] = useState<Store[]>(() =>
    getInitialStorage('stores', INITIAL_STORES)
  );

  const [categories, setCategories] = useState<Category[]>(() =>
    getInitialStorage('categories', INITIAL_CATEGORIES)
  );

  const [products, setProducts] = useState<Product[]>(() =>
    getInitialStorage('products', INITIAL_PRODUCTS)
  );

  const [orders, setOrders] = useState<Order[]>(() =>
    getInitialStorage('orders', [
      {
        id: 'ord-1082',
        customerId: 'cust-emerald-01',
        customerName: 'Rohan Sharma',
        customerPhone: '+91 98200 11223',
        apartmentId: 'apt-emerald-heights',
        apartmentName: 'Emerald Heights Residences',
        deliveryAddress: 'Flat 402, Tower B, Emerald Heights Residences',
        storeId: 'store-freshmart',
        storeName: 'FreshMart Supermarket',
        deliveryPartnerId: 'delivery-agent-01',
        deliveryPartnerName: 'Raju Kumar (Super Express Courier)',
        deliveryPartnerPhone: '+91 98765 43210',
        status: 'out_for_delivery',
        paymentMethod: 'ONLINE',
        paymentStatus: 'paid',
        transactionId: 'TXN-94820194',
        subtotal: 108,
        deliveryFee: 0,
        handlingFee: 5,
        totalAmount: 113,
        itemCount: 3,
        deliveryOtp: '4821',
        items: [
          {
            id: 'item-1',
            orderId: 'ord-1082',
            productId: 'prod-fm-01',
            name: 'Fresh Farm Tomatoes (Hybrid)',
            imageUrl: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=500&q=80',
            unit: '1 kg',
            unitPrice: 34,
            mrp: 45,
            quantity: 1,
            totalPrice: 34,
          },
          {
            id: 'item-2',
            orderId: 'ord-1082',
            productId: 'prod-fm-04',
            name: 'Amul Taaza Homogenised Toned Milk',
            imageUrl: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=500&q=80',
            unit: '500 ml pouch',
            unitPrice: 27,
            mrp: 28,
            quantity: 2,
            totalPrice: 54,
          },
          {
            id: 'item-3',
            orderId: 'ord-1082',
            productId: 'prod-fm-09',
            name: "Lay's India's Magic Masala Potato Chips",
            imageUrl: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?auto=format&fit=crop&w=500&q=80',
            unit: '50 g',
            unitPrice: 20,
            mrp: 20,
            quantity: 1,
            totalPrice: 20,
          },
        ],
        createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        updatedAt: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
      },
    ])
  );

  const [subscriptions, setSubscriptions] = useState<Subscription[]>(() =>
    getInitialStorage('subscriptions', [
      {
        id: 'sub-fm-2026',
        storeId: 'store-freshmart',
        storeName: 'FreshMart Supermarket',
        ownerId: 'owner-freshmart-01',
        amount: 199,
        periodMonth: 'November 2026',
        startDate: '2026-11-01T00:00:00Z',
        endDate: '2026-12-01T23:59:59Z',
        status: 'active',
        paymentId: 'pay-sub-991',
        createdAt: '2026-11-01T09:00:00Z',
      },
      {
        id: 'sub-gv-2026',
        storeId: 'store-greenvalley',
        storeName: 'GreenValley Daily Express',
        ownerId: 'owner-greenvalley-02',
        amount: 199,
        periodMonth: 'November 2026',
        startDate: '2026-10-28T00:00:00Z',
        endDate: '2026-11-28T23:59:59Z',
        status: 'active',
        paymentId: 'pay-sub-992',
        createdAt: '2026-10-28T10:00:00Z',
      },
      {
        id: 'sub-qm-2026',
        storeId: 'store-quickmart',
        storeName: 'QuickMart Superstore',
        ownerId: 'owner-quickmart-03',
        amount: 199,
        periodMonth: 'October 2026',
        startDate: '2026-10-12T00:00:00Z',
        endDate: '2026-11-12T23:59:59Z',
        status: 'active',
        paymentId: 'pay-sub-990',
        createdAt: '2026-10-12T11:00:00Z',
      },
    ])
  );

  const [deliveryPartners, setDeliveryPartners] = useState<DeliveryPartner[]>(() =>
    getInitialStorage('deliveryPartners', INITIAL_DELIVERY_PARTNERS)
  );

  const [notifications, setNotifications] = useState<NotificationItem[]>(() =>
    getInitialStorage('notifications', [
      {
        id: 'notif-1',
        recipientId: 'cust-emerald-01',
        title: 'Order Out for Delivery 🚀',
        message: 'Raju Kumar is on his way to Tower B, Flat 402 with your groceries!',
        type: 'order_status',
        relatedId: 'ord-1082',
        isRead: false,
        createdAt: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
      },
      {
        id: 'notif-2',
        recipientId: 'store-freshmart',
        title: 'Welcome to Super Express!',
        message: 'Your supermarket is exclusively serving Emerald Heights Residences.',
        type: 'subscription',
        isRead: true,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      },
    ])
  );

  const [payments, setPayments] = useState<PaymentRecord[]>(() =>
    getInitialStorage('payments', [
      {
        id: 'pay-sub-991',
        storeId: 'store-freshmart',
        type: 'subscription',
        amount: 199,
        currency: 'INR',
        status: 'verified',
        method: 'UPI',
        transactionReference: 'UPI-RRR-948102',
        paidAt: '2026-11-01T09:05:00Z',
        createdAt: '2026-11-01T09:00:00Z',
      },
      {
        id: 'pay-ord-1082',
        orderId: 'ord-1082',
        type: 'order',
        amount: 113,
        currency: 'INR',
        status: 'verified',
        method: 'UPI',
        transactionReference: 'TXN-94820194',
        paidAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
      },
    ])
  );

  const [cart, setCart] = useState<CartItem[]>(() => getInitialStorage('cart', []));

  // Save changes to storage
  useEffect(() => { setStorage('role', role); }, [role]);
  useEffect(() => { setStorage('currentUser', currentUser); }, [currentUser]);
  useEffect(() => { setStorage('ownerUser', ownerUser); }, [ownerUser]);
  useEffect(() => { setStorage('apartments', apartments); }, [apartments]);
  useEffect(() => { setStorage('stores', stores); }, [stores]);
  useEffect(() => { setStorage('categories', categories); }, [categories]);
  useEffect(() => { setStorage('products', products); }, [products]);
  useEffect(() => { setStorage('orders', orders); }, [orders]);
  useEffect(() => { setStorage('subscriptions', subscriptions); }, [subscriptions]);
  useEffect(() => { setStorage('deliveryPartners', deliveryPartners); }, [deliveryPartners]);
  useEffect(() => { setStorage('notifications', notifications); }, [notifications]);
  useEffect(() => { setStorage('payments', payments); }, [payments]);
  useEffect(() => { setStorage('cart', cart); }, [cart]);

  // Real-time synchronization of orders across tabs and devices
  useEffect(() => {
    // 1. BroadcastChannel for instant zero-latency same-browser sync
    let channel: BroadcastChannel | null = null;
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      channel = new BroadcastChannel('superexpress-orders');
      channel.onmessage = (event) => {
        if (event.data?.type === 'NEW_ORDER' && event.data.order) {
          const incomingOrder = event.data.order as Order;
          setOrders((prev) => {
            if (prev.some((o) => o.id === incomingOrder.id)) return prev;
            return [incomingOrder, ...prev];
          });
        } else if (event.data?.type === 'UPDATE_STATUS' && event.data.orderId) {
          setOrders((prev) =>
            prev.map((o) =>
              o.id === event.data.orderId ? { ...o, status: event.data.status } : o
            )
          );
        }
      };
    }

    // 2. Real-time Firebase Firestore live listener (unified mode)
    let unsubscribeFirestore: (() => void) | null = null;
    if (appMode === 'unified') {
      try {
        unsubscribeFirestore = onSnapshot(
          collection(db, 'orders'),
          (snapshot) => {
            if (!snapshot.empty) {
              const firestoreOrders: Order[] = [];
              snapshot.forEach((docSnap) => {
                const data = docSnap.data() as Order;
                if (data && data.id) {
                  firestoreOrders.push(data);
                }
              });

              setOrders((prev) => {
                const orderMap = new Map<string, Order>();
                prev.forEach((o) => orderMap.set(o.id, o));
                firestoreOrders.forEach((o) => {
                  const existing = orderMap.get(o.id);
                  if (
                    !existing ||
                    (o.updatedAt && (!existing.updatedAt || o.updatedAt >= existing.updatedAt))
                  ) {
                    orderMap.set(o.id, {
                      ...existing,
                      ...o,
                      items: o.items || existing?.items || [],
                    });
                  }
                });
                return Array.from(orderMap.values()).sort(
                  (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                );
              });
            }
          },
          (error) => {
            console.warn('Firestore live order listener notice:', error.message);
          }
        );
      } catch (err) {
        console.warn('Firestore onSnapshot setup warning:', err);
      }
    }

    return () => {
      if (channel) channel.close();
      if (unsubscribeFirestore) unsubscribeFirestore();
    };
  }, [appMode]);

  // Customer App Firebase Authentication & Role-Scoped Firestore Sync
  useEffect(() => {
    if (appMode !== 'customer') return;

    let unsubApartments: (() => void) | null = null;
    let unsubStores: (() => void) | null = null;
    let unsubProducts: (() => void) | null = null;
    let unsubOrders: (() => void) | null = null;

    const cleanupListeners = () => {
      unsubApartments?.();
      unsubStores?.();
      unsubProducts?.();
      unsubOrders?.();
      unsubApartments = null;
      unsubStores = null;
      unsubProducts = null;
      unsubOrders = null;
    };

    const unsubAuth = onAuthStateChanged(auth, async (fbUser) => {
      cleanupListeners();

      if (!fbUser) {
        setCustomerFirebaseUser(null);
        setCustomerAuthLoading(false);
        return;
      }

      setCustomerAuthLoading(true);
      try {
        const userDocRef = doc(db, 'users', fbUser.uid);
        const snap = await getDoc(userDocRef);

        if (snap.exists()) {
          const profileData = snap.data() as UserProfile;
          if (profileData.role && profileData.role !== 'customer') {
            await signOut(auth);
            setCustomerFirebaseUser(null);
            setCustomerAuthError(
              `This account is registered as "${profileData.role}". Please sign in with a Customer account.`
            );
            setCustomerAuthLoading(false);
            return;
          }

          setCurrentUser({
            id: fbUser.uid,
            name: profileData.name || fbUser.displayName || 'Customer',
            phone: profileData.phone || '+91 90000 00000',
            email: profileData.email || fbUser.email || '',
            role: 'customer',
            apartmentId: profileData.apartmentId || INITIAL_APARTMENTS[0].id,
            apartmentName:
              apartments.find((a) => a.id === profileData.apartmentId)?.name ||
              INITIAL_APARTMENTS[0].name,
            flatNumber: profileData.flatNumber || '101',
            block: profileData.block || 'Tower A',
            isVerified: profileData.isVerified ?? true,
            createdAt: profileData.createdAt || new Date().toISOString(),
          });
        } else {
          const defaultApt = apartments[0] || INITIAL_APARTMENTS[0];
          const now = new Date().toISOString();
          const newDoc = {
            id: fbUser.uid,
            phone: fbUser.phoneNumber || '+91 90000 00000',
            name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Super Express Customer',
            email: fbUser.email || '',
            role: 'customer' as const,
            apartmentId: defaultApt.id,
            flatNumber: '101',
            block: 'Tower A',
            isVerified: true,
            createdAt: now,
            updatedAt: now,
          };
          await setDoc(userDocRef, newDoc);
          setCurrentUser({
            ...newDoc,
            apartmentName: defaultApt.name,
          });
        }

        setCustomerFirebaseUser(fbUser);
        setCustomerAuthError(null);

        // Live sync public/customer-readable Firestore collections
        unsubApartments = onSnapshot(
          collection(db, 'apartments'),
          (snapshot) => {
            if (!snapshot.empty) {
              const liveApts = snapshot.docs.map((d) => d.data() as Apartment).filter((a) => a?.id);
              if (liveApts.length > 0) {
                setApartments((prev) => {
                  const map = new Map<string, Apartment>();
                  prev.forEach((a) => map.set(a.id, a));
                  liveApts.forEach((a) => map.set(a.id, a));
                  return Array.from(map.values());
                });
              }
            }
          },
          (err) => console.warn('Apartments listener notice:', err.message)
        );

        unsubStores = onSnapshot(
          collection(db, 'stores'),
          (snapshot) => {
            if (!snapshot.empty) {
              const liveStores = snapshot.docs.map((d) => d.data() as Store).filter((s) => s?.id);
              if (liveStores.length > 0) {
                setStores((prev) => {
                  const map = new Map<string, Store>();
                  prev.forEach((s) => map.set(s.id, s));
                  liveStores.forEach((s) => map.set(s.id, s));
                  return Array.from(map.values());
                });
              }
            }
          },
          (err) => console.warn('Stores listener notice:', err.message)
        );

        unsubProducts = onSnapshot(
          collection(db, 'products'),
          (snapshot) => {
            if (!snapshot.empty) {
              const liveProducts = snapshot.docs
                .map((d) => d.data() as Product)
                .filter((p) => p?.id);
              if (liveProducts.length > 0) {
                setProducts((prev) => {
                  const map = new Map<string, Product>();
                  prev.forEach((p) => map.set(p.id, p));
                  liveProducts.forEach((p) => map.set(p.id, p));
                  return Array.from(map.values());
                });
              }
            }
          },
          (err) => console.warn('Products listener notice:', err.message)
        );

        const customerOrdersQuery = query(
          collection(db, 'orders'),
          where('customerId', '==', fbUser.uid)
        );
        unsubOrders = onSnapshot(
          customerOrdersQuery,
          (snapshot) => {
            const liveOrders = snapshot.docs.map((d) => d.data() as Order).filter((o) => o?.id);
            setOrders((prev) => {
              const orderMap = new Map<string, Order>();
              prev.filter((o) => o.customerId === fbUser.uid).forEach((o) => orderMap.set(o.id, o));
              liveOrders.forEach((o) => {
                const existing = orderMap.get(o.id);
                if (
                  !existing ||
                  (o.updatedAt && (!existing.updatedAt || o.updatedAt >= existing.updatedAt))
                ) {
                  orderMap.set(o.id, {
                    ...existing,
                    ...o,
                    items: o.items || existing?.items || [],
                  });
                }
              });
              return Array.from(orderMap.values()).sort(
                (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
              );
            });
          },
          (err) => console.warn('Customer orders listener notice:', err.message)
        );
      } catch (err: any) {
        console.warn('Customer auth profile sync notice:', err?.message || err);
        setCustomerFirebaseUser(fbUser);
      } finally {
        setCustomerAuthLoading(false);
      }
    });

    return () => {
      cleanupListeners();
      unsubAuth();
    };
  }, [appMode]);

  // Determine active apartment
  const activeApartment = apartments.find((a) => a.id === currentUser.apartmentId) || apartments[0] || null;

  // Single-supermarket-per-apartment constraint:
  // Customers MUST only see and buy from the supermarket assigned to their apartment!
  const activeStore = stores.find((s) => s.apartmentId === activeApartment?.id && s.status === 'active') || null;

  // The logged-in owner's assigned supermarket
  const ownerStore = stores.find((s) => s.ownerId === ownerUser?.id) || null;

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const setRole = (newRole: UserRole) => {
    setRoleState(newRole);
    // Switch active demo persona to match role cleanly
    if (newRole === 'customer') {
      setCurrentUser((prev) => ({
        ...prev,
        id: 'cust-emerald-01',
        name: 'Rohan Sharma',
        role: 'customer',
        apartmentId: 'apt-emerald-heights',
        apartmentName: 'Emerald Heights Residences',
        flatNumber: '402',
        block: 'Tower B',
        isVerified: true,
      }));
    } else if (newRole === 'store_owner') {
      setCurrentUser((prev) => ({
        ...prev,
        id: 'owner-freshmart-01',
        name: 'Suresh Kumar (FreshMart)',
        role: 'store_owner',
        apartmentId: 'apt-emerald-heights',
        storeId: 'store-freshmart',
        isVerified: true,
      }));
    } else if (newRole === 'delivery_partner') {
      setCurrentUser((prev) => ({
        ...prev,
        id: 'delivery-agent-01',
        name: 'Raju Kumar (Super Express Courier)',
        role: 'delivery_partner',
        apartmentId: 'apt-emerald-heights',
        isVerified: true,
      }));
    } else if (newRole === 'admin') {
      setCurrentUser((prev) => ({
        ...prev,
        id: 'admin-super-express',
        name: 'Super Express Platform Admin',
        role: 'admin',
        isVerified: true,
      }));
    }
  };

  const selectApartment = (apartmentId: string) => {
    const apt = apartments.find((a) => a.id === apartmentId);
    if (!apt) return;
    setCurrentUser((prev) => ({
      ...prev,
      apartmentId: apt.id,
      apartmentName: apt.name,
      flatNumber: prev.flatNumber || '101',
      block: prev.block || 'Tower A',
    }));
    // If apartment changes, clear cart because items must be from assigned supermarket only!
    setCart([]);
  };

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const addNotification = (item: Omit<NotificationItem, 'id' | 'createdAt' | 'isRead'>) => {
    const newNotif: NotificationItem = {
      ...item,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  // Create an order strictly verifying store & apartment
  const createOrder = async (data: {
    paymentMethod: PaymentMethod;
    deliveryAddress: string;
    flatNumber: string;
    block: string;
    notes?: string;
  }): Promise<Order> => {
    if (!activeApartment || !activeStore) {
      throw new Error('No active store assigned to this apartment!');
    }
    if (cart.length === 0) {
      throw new Error('Cart is empty.');
    }

    const subtotal = cartTotal;
    const deliveryFee = subtotal >= 199 ? 0 : 25;
    const handlingFee = 5;
    const totalAmount = subtotal + deliveryFee + handlingFee;
    const orderId = `ord-${Date.now().toString().slice(-4)}`;
    const randomOtp = Math.floor(1000 + Math.random() * 9000).toString();

    const orderItems = cart.map((c, idx) => ({
      id: `item-${orderId}-${idx}`,
      orderId,
      productId: c.product.id,
      name: c.product.name,
      imageUrl: c.product.imageUrl,
      unit: c.product.unit,
      unitPrice: c.product.price,
      mrp: c.product.mrp,
      quantity: c.quantity,
      totalPrice: c.product.price * c.quantity,
    }));

    const effectiveCustomerId =
      appMode === 'customer' && auth.currentUser ? auth.currentUser.uid : currentUser.id;

    const newOrder: Order = {
      id: orderId,
      customerId: effectiveCustomerId,
      customerName: currentUser.name,
      customerPhone: currentUser.phone,
      apartmentId: activeApartment.id,
      apartmentName: activeApartment.name,
      deliveryAddress: `${data.block}, Flat ${data.flatNumber}, ${activeApartment.name}, ${activeApartment.address}`,
      storeId: activeStore.id,
      storeName: activeStore.name,
      status: 'placed',
      paymentMethod: data.paymentMethod,
      paymentStatus: data.paymentMethod === 'ONLINE' ? 'pending' : 'pending',
      subtotal,
      deliveryFee,
      handlingFee,
      totalAmount,
      itemCount: cartCount,
      deliveryOtp: randomOtp,
      items: orderItems,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Update state
    setOrders((prev) => [newOrder, ...prev]);
    clearCart();

    // Trigger notification to store owner
    addNotification({
      recipientId: activeStore.ownerId,
      title: `⚡ New Order #${orderId}`,
      message: `Received order worth ₹${totalAmount} from Flat ${data.flatNumber}, ${data.block}`,
      type: 'order_status',
      relatedId: orderId,
    });

    // Sync to Firestore non-blocking
    try {
      await setDoc(doc(db, 'orders', orderId), {
        id: orderId,
        customerId: effectiveCustomerId,
        customerName: currentUser.name,
        customerPhone: currentUser.phone,
        apartmentId: activeApartment.id,
        apartmentName: activeApartment.name,
        deliveryAddress: newOrder.deliveryAddress,
        storeId: activeStore.id,
        storeName: activeStore.name,
        status: newOrder.status,
        paymentMethod: newOrder.paymentMethod,
        paymentStatus: newOrder.paymentStatus,
        subtotal: newOrder.subtotal,
        deliveryFee: newOrder.deliveryFee,
        handlingFee: newOrder.handlingFee,
        totalAmount: newOrder.totalAmount,
        itemCount: newOrder.itemCount,
        deliveryOtp: newOrder.deliveryOtp,
        items: newOrder.items || [],
        createdAt: newOrder.createdAt,
        updatedAt: newOrder.updatedAt,
      });

      // Broadcast instant event across local tabs
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        const channel = new BroadcastChannel('superexpress-orders');
        channel.postMessage({ type: 'NEW_ORDER', order: newOrder });
        channel.close();
      }
    } catch (err) {
      console.warn('Firestore write warning:', err);
    }

    return newOrder;
  };

  const verifyOnlinePayment = async (
    orderId: string,
    method: 'UPI' | 'CARD' | 'NETBANKING'
  ): Promise<boolean> => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder) return false;

    const txnId = `TXN-${Math.floor(10000000 + Math.random() * 90000000)}`;
    const paymentRecord: PaymentRecord = {
      id: `pay-${Date.now()}`,
      orderId,
      type: 'order',
      amount: targetOrder.totalAmount,
      currency: 'INR',
      status: 'verified',
      method,
      transactionReference: txnId,
      paidAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    setPayments((prev) => [paymentRecord, ...prev]);

    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              paymentStatus: 'paid',
              transactionId: txnId,
              status: o.status === 'placed' ? 'accepted' : o.status,
              updatedAt: new Date().toISOString(),
            }
          : o
      )
    );

    addNotification({
      recipientId: targetOrder.customerId,
      title: 'Payment Successful! ✅',
      message: `₹${targetOrder.totalAmount} paid via ${method} (${txnId}). Store is preparing your order.`,
      type: 'order_status',
      relatedId: orderId,
    });

    try {
      await updateDoc(doc(db, 'orders', orderId), {
        paymentStatus: 'paid',
        transactionId: txnId,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      console.warn('Firestore payment status sync warning:', err);
    }

    return true;
  };

  const updateOrderStatus = async (
    orderId: string,
    status: OrderStatus,
    deliveryPartnerId?: string
  ) => {
    let assignedPartner = deliveryPartners.find((p) => p.id === deliveryPartnerId);
    if (!assignedPartner && status === 'out_for_delivery') {
      assignedPartner = deliveryPartners[0];
    }

    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== orderId) return o;
        return {
          ...o,
          status,
          deliveryPartnerId: assignedPartner ? assignedPartner.id : o.deliveryPartnerId,
          deliveryPartnerName: assignedPartner ? assignedPartner.name : o.deliveryPartnerName,
          deliveryPartnerPhone: assignedPartner ? assignedPartner.phone : o.deliveryPartnerPhone,
          updatedAt: new Date().toISOString(),
        };
      })
    );

    const order = orders.find((o) => o.id === orderId);
    if (order) {
      const statusTitles: Record<OrderStatus, string> = {
        placed: 'Order Received',
        accepted: 'Order Accepted by Store 👨‍🍳',
        packing: 'Order is Being Packed 🛍️',
        out_for_delivery: 'Out for Delivery 🛵',
        delivered: 'Delivered Successfully! 🎉',
        rejected: 'Order Rejected by Store ❌',
        cancelled: 'Order Cancelled',
      };

      addNotification({
        recipientId: order.customerId,
        title: statusTitles[status] || 'Order Status Updated',
        message:
          status === 'out_for_delivery'
            ? `Your order is on the way! Share OTP ${order.deliveryOtp} with delivery partner on arrival.`
            : `Order #${order.id} is now ${status.replace(/_/g, ' ')}.`,
        type: 'order_status',
        relatedId: orderId,
      });
    }

    try {
      await updateDoc(doc(db, 'orders', orderId), {
        status,
        ...(assignedPartner ? {
          deliveryPartnerId: assignedPartner.id,
          deliveryPartnerName: assignedPartner.name,
          deliveryPartnerPhone: assignedPartner.phone,
        } : {}),
        updatedAt: new Date().toISOString(),
      });

      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        const channel = new BroadcastChannel('superexpress-orders');
        channel.postMessage({ type: 'UPDATE_STATUS', orderId, status });
        channel.close();
      }
    } catch (err) {
      console.warn('Firestore status update warning:', err);
    }
  };

  const assignDeliveryPartner = async (orderId: string, partnerId: string) => {
    const partner = deliveryPartners.find((p) => p.id === partnerId);
    if (!partner) return;

    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              deliveryPartnerId: partner.id,
              deliveryPartnerName: partner.name,
              deliveryPartnerPhone: partner.phone,
              status: o.status === 'packing' ? 'out_for_delivery' : o.status,
              updatedAt: new Date().toISOString(),
            }
          : o
      )
    );

    addNotification({
      recipientId: partner.id,
      title: 'New Delivery Assigned 📦',
      message: `Pick up Order #${orderId} from store and deliver to apartment.`,
      type: 'order_status',
      relatedId: orderId,
    });
  };

  const verifyDeliveryOtp = async (orderId: string, otp: string): Promise<boolean> => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return false;
    if (order.deliveryOtp.trim() !== otp.trim()) {
      return false;
    }

    await updateOrderStatus(orderId, 'delivered');
    return true;
  };

  // Restrict barcode lookup strictly to logged-in owner's store inventory
  const findProductByBarcode = (storeId: string, rawBarcode: string): Product | undefined => {
    const code = rawBarcode.trim();
    if (!code || !storeId) return undefined;
    return products.find(
      (p) =>
        p.storeId === storeId &&
        ((p.barcode && p.barcode.trim() === code) ||
          (Array.isArray(p.barcodeAliases) && p.barcodeAliases.some((a) => a.trim() === code)))
    );
  };

  // Prevent duplicate barcodes & aliases within the same store
  const checkBarcodeDuplicate = (
    storeId: string,
    rawCodes: string[],
    excludeProductId?: string
  ): { barcode: string; existingProduct: Product } | null => {
    const cleanCodes = Array.from(new Set(rawCodes.map((c) => c.trim()).filter(Boolean)));
    if (cleanCodes.length === 0) return null;

    const storeProducts = products.filter((p) => p.storeId === storeId && p.id !== excludeProductId);
    for (const code of cleanCodes) {
      const existing = storeProducts.find(
        (p) =>
          (p.barcode && p.barcode.trim() === code) ||
          (Array.isArray(p.barcodeAliases) && p.barcodeAliases.some((a) => a.trim() === code))
      );
      if (existing) {
        return { barcode: code, existingProduct: existing };
      }
    }
    return null;
  };

  // Product Catalog Management
  const addProduct = async (productData: Omit<Product, 'id' | 'createdAt'>) => {
    const normalizedBarcode = productData.barcode?.trim() || undefined;
    const normalizedAliases = Array.from(
      new Set(
        (productData.barcodeAliases || [])
          .map((a) => a.trim())
          .filter((a) => Boolean(a) && a !== normalizedBarcode)
      )
    );

    const allCodes = [
      ...(normalizedBarcode ? [normalizedBarcode] : []),
      ...normalizedAliases,
    ];
    const dup = checkBarcodeDuplicate(productData.storeId, allCodes);
    if (dup) {
      throw new Error(
        `Duplicate barcode "${dup.barcode}" already assigned to "${dup.existingProduct.name}" in your store.`
      );
    }

    const id = `prod-${Date.now()}`;
    const newProduct: Product = {
      ...productData,
      ...(normalizedBarcode ? { barcode: normalizedBarcode } : {}),
      ...(normalizedAliases.length > 0 ? { barcodeAliases: normalizedAliases } : {}),
      id,
      createdAt: new Date().toISOString(),
    };
    setProducts((prev) => [newProduct, ...prev]);

    try {
      await setDoc(doc(db, 'products', id), newProduct);
    } catch (err) {
      console.warn('Firestore add product warning:', err);
    }
  };

  const updateProduct = async (productId: string, updates: Partial<Product>) => {
    const current = products.find((p) => p.id === productId);
    if (!current) return;

    const nextBarcode =
      updates.barcode !== undefined ? updates.barcode.trim() || undefined : current.barcode;
    const nextAliases =
      updates.barcodeAliases !== undefined
        ? Array.from(
            new Set(
              updates.barcodeAliases
                .map((a) => a.trim())
                .filter((a) => Boolean(a) && a !== nextBarcode)
            )
          )
        : current.barcodeAliases || [];

    const allCodes = [...(nextBarcode ? [nextBarcode] : []), ...nextAliases];
    const dup = checkBarcodeDuplicate(current.storeId, allCodes, productId);
    if (dup) {
      throw new Error(
        `Duplicate barcode "${dup.barcode}" already assigned to "${dup.existingProduct.name}" in your store.`
      );
    }

    const cleanUpdates: Partial<Product> = {
      ...updates,
      barcode: nextBarcode || '',
      barcodeAliases: nextAliases,
      updatedAt: new Date().toISOString(),
    };

    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, ...cleanUpdates } : p))
    );

    try {
      await updateDoc(doc(db, 'products', productId), cleanUpdates);
    } catch (err) {
      console.warn('Firestore update product warning:', err);
    }
  };

  const deleteProduct = async (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    try {
      await deleteDoc(doc(db, 'products', productId));
    } catch (err) {
      console.warn('Firestore delete product warning:', err);
    }
  };

  const toggleProductStock = async (productId: string) => {
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;
    const newInStock = !prod.inStock;
    await updateProduct(productId, { inStock: newInStock });
  };

  // POS Billing Checkout: Saves POS order & payment first, then safely decrements store stock
  const completePosSale = async (data: {
    storeId: string;
    items: { productId: string; quantity: number }[];
    discountAmount?: number;
    paymentMethod: PosPaymentMethod;
    splitPaymentDetails?: SplitPaymentDetails;
    customerName?: string;
    customerPhone?: string;
  }): Promise<{ order: Order; payment: PaymentRecord }> => {
    const targetStore = stores.find((s) => s.id === data.storeId);
    if (!targetStore) {
      throw new Error('Store not found.');
    }
    if (!data.items || data.items.length === 0) {
      throw new Error('POS billing cart is empty.');
    }

    // Validate all line items belong to owner's store and have enough stock
    const resolvedItems = data.items.map((entry, idx) => {
      const prod = products.find((p) => p.id === entry.productId && p.storeId === data.storeId);
      if (!prod) {
        throw new Error(`Product ${entry.productId} does not belong to your store.`);
      }
      if (entry.quantity <= 0) {
        throw new Error(`Invalid quantity for "${prod.name}".`);
      }
      if (entry.quantity > prod.stockCount) {
        throw new Error(
          `Insufficient stock for "${prod.name}". Available: ${prod.stockCount}, Requested: ${entry.quantity}.`
        );
      }
      return { prod, quantity: entry.quantity, idx };
    });

    const subtotal = resolvedItems.reduce(
      (sum, item) => sum + item.prod.price * item.quantity,
      0
    );
    const discountAmount = Math.max(0, Math.min(subtotal, Number(data.discountAmount || 0)));
    const totalAmount = Math.max(0, Number((subtotal - discountAmount).toFixed(2)));
    const totalCount = resolvedItems.reduce((sum, item) => sum + item.quantity, 0);

    // Validate split payment sum before processing
    if (data.paymentMethod === 'SPLIT') {
      const split = data.splitPaymentDetails || { cash: 0, upi: 0, card: 0 };
      const splitTotal = Number((split.cash + split.upi + split.card).toFixed(2));
      if (Math.abs(splitTotal - totalAmount) > 0.01) {
        throw new Error(
          `Split payment total (₹${splitTotal}) must exactly match Grand Total (₹${totalAmount}).`
        );
      }
    }

    const now = new Date().toISOString();
    const orderId = `POS-${Date.now().toString().slice(-6)}`;
    const payId = `pay-pos-${Date.now()}`;
    const txnRef = `POS-${data.paymentMethod}-${Math.floor(100000 + Math.random() * 900000)}`;

    const orderItems = resolvedItems.map(({ prod, quantity, idx }) => ({
      id: `item-${orderId}-${idx}`,
      orderId,
      productId: prod.id,
      name: prod.name,
      imageUrl: prod.imageUrl,
      unit: prod.unit,
      unitPrice: prod.price,
      mrp: prod.mrp,
      quantity,
      totalPrice: prod.price * quantity,
    }));

    const posOrder: Order = {
      id: orderId,
      orderType: 'POS',
      customerId: 'pos-walkin-customer',
      customerName: data.customerName?.trim() || 'Walk-in Customer',
      customerPhone: data.customerPhone?.trim() || 'Counter Sale',
      apartmentId: targetStore.apartmentId || 'pos-counter',
      apartmentName: targetStore.apartmentName || targetStore.name,
      deliveryAddress: 'In-Store POS Billing Counter',
      storeId: targetStore.id,
      storeName: targetStore.name,
      status: 'delivered',
      paymentMethod: data.paymentMethod,
      paymentStatus: 'paid',
      ...(data.splitPaymentDetails ? { splitPaymentDetails: data.splitPaymentDetails } : {}),
      ...(discountAmount > 0 ? { discountAmount } : {}),
      transactionId: txnRef,
      subtotal,
      deliveryFee: 0,
      handlingFee: 0,
      totalAmount,
      itemCount: totalCount,
      deliveryOtp: '0000',
      items: orderItems,
      createdAt: now,
      updatedAt: now,
    };

    const paymentRecord: PaymentRecord = {
      id: payId,
      orderId,
      storeId: targetStore.id,
      type: 'pos_sale',
      amount: totalAmount,
      currency: 'INR',
      status: 'verified',
      method: data.paymentMethod,
      ...(data.splitPaymentDetails ? { splitPaymentDetails: data.splitPaymentDetails } : {}),
      transactionReference: txnRef,
      paidAt: now,
      createdAt: now,
    };

    // 1. Persist POS Order & Payment first (payment confirmed)
    setOrders((prev) => [posOrder, ...prev]);
    setPayments((prev) => [paymentRecord, ...prev]);

    try {
      await setDoc(doc(db, 'orders', orderId), posOrder);
      await setDoc(doc(db, 'payments', payId), paymentRecord);
    } catch (err) {
      console.warn('Firestore POS order/payment sync warning:', err);
    }

    // 2. Safely decrement inventory ONLY AFTER payment is recorded
    const qtyByProductId = new Map<string, number>();
    resolvedItems.forEach(({ prod, quantity }) => {
      qtyByProductId.set(prod.id, (qtyByProductId.get(prod.id) || 0) + quantity);
    });

    setProducts((prev) =>
      prev.map((p) => {
        const deduct = qtyByProductId.get(p.id);
        if (!deduct) return p;
        const nextStock = Math.max(0, p.stockCount - deduct);
        return {
          ...p,
          stockCount: nextStock,
          inStock: nextStock > 0 ? p.inStock : false,
          updatedAt: now,
        };
      })
    );

    // Sync atomic stock decrements to Firestore products collection
    for (const [prodId, deduct] of qtyByProductId.entries()) {
      const prodRef = doc(db, 'products', prodId);
      try {
        await runTransaction(db, async (tx) => {
          const snap = await tx.get(prodRef);
          if (!snap.exists()) return;
          const currentStock = Number(snap.data().stockCount ?? 0);
          const nextStock = Math.max(0, currentStock - deduct);
          tx.update(prodRef, {
            stockCount: nextStock,
            inStock: nextStock > 0,
            updatedAt: now,
          });
        });
      } catch (err) {
        console.warn(`Firestore stock decrement warning for ${prodId}:`, err);
      }
    }

    return { order: posOrder, payment: paymentRecord };
  };

  // ₹199 Monthly Subscription Payment
  const paySubscription = async (storeId: string, paymentMethod: 'UPI' | 'CARD') => {
    const store = stores.find((s) => s.id === storeId);
    if (!store) return;

    const subId = `sub-${Date.now()}`;
    const payId = `pay-sub-${Date.now()}`;
    const nextMonth = new Date();
    nextMonth.setDate(nextMonth.getDate() + 30);

    const paymentRecord: PaymentRecord = {
      id: payId,
      storeId,
      type: 'subscription',
      amount: 199,
      currency: 'INR',
      status: 'verified',
      method: paymentMethod,
      transactionReference: `UPI-SUB-${Math.floor(100000 + Math.random() * 900000)}`,
      paidAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    const newSub: Subscription = {
      id: subId,
      storeId,
      storeName: store.name,
      ownerId: store.ownerId,
      amount: 199,
      periodMonth: new Date().toLocaleString('default', { month: 'long', year: 'numeric' }),
      startDate: new Date().toISOString(),
      endDate: nextMonth.toISOString(),
      status: 'active',
      paymentId: payId,
      createdAt: new Date().toISOString(),
    };

    setPayments((prev) => [paymentRecord, ...prev]);
    setSubscriptions((prev) => [newSub, ...prev]);

    setStores((prev) =>
      prev.map((s) =>
        s.id === storeId
          ? {
              ...s,
              subscriptionStatus: 'active',
              subscriptionExpiresAt: nextMonth.toISOString(),
              status: s.status === 'suspended' ? 'active' : s.status,
            }
          : s
      )
    );

    addNotification({
      recipientId: store.ownerId,
      title: '₹199 Subscription Renewed! 🌟',
      message: `Your supermarket exclusive delivery rights are active until ${nextMonth.toLocaleDateString()}.`,
      type: 'subscription',
      relatedId: subId,
    });
  };

  // Admin Apartment Management & Single-Store Enforcement
  const addApartment = async (aptData: Omit<Apartment, 'id' | 'createdAt'>) => {
    const id = `apt-${Date.now()}`;
    const newApt: Apartment = {
      ...aptData,
      id,
      createdAt: new Date().toISOString(),
    };
    setApartments((prev) => [newApt, ...prev]);

    try {
      await setDoc(doc(db, 'apartments', id), newApt);
    } catch (err) {
      console.warn('Firestore add apartment warning:', err);
    }
  };

  // STRICT SINGLE-STORE-PER-APARTMENT ENFORCEMENT
  const assignStoreToApartment = async (apartmentId: string, storeId: string) => {
    const targetApt = apartments.find((a) => a.id === apartmentId);
    const targetStore = stores.find((s) => s.id === storeId);
    if (!targetApt || !targetStore) return;

    // 1. Unassign any other store currently assigned to this apartment
    const updatedStores = stores.map((s) => {
      if (s.id === storeId) {
        return {
          ...s,
          apartmentId,
          apartmentName: targetApt.name,
          status: 'active' as const,
        };
      }
      if (s.apartmentId === apartmentId && s.id !== storeId) {
        return {
          ...s,
          apartmentId: '',
          apartmentName: 'Unassigned',
          status: 'inactive' as const,
        };
      }
      return s;
    });

    const updatedApts = apartments.map((a) => {
      if (a.id === apartmentId) {
        return {
          ...a,
          activeStoreId: storeId,
          activeStoreName: targetStore.name,
        };
      }
      return a;
    });

    setStores(updatedStores);
    setApartments(updatedApts);

    addNotification({
      recipientId: targetStore.ownerId,
      title: 'Apartment Territory Assigned! 🏬',
      message: `You are now the exclusive supermarket for ${targetApt.name}.`,
      type: 'alert',
    });
  };

  const updateStoreStatus = async (storeId: string, status: Store['status']) => {
    setStores((prev) =>
      prev.map((s) => (s.id === storeId ? { ...s, status } : s))
    );
  };

  // Owner Authentication & Registration
  const registerOwner = async (name: string, phone: string, email?: string): Promise<UserProfile> => {
    const ownerId = `owner-${Date.now()}`;
    const newOwner: UserProfile = {
      id: ownerId,
      name,
      phone,
      email: email || '',
      role: 'store_owner',
      isVerified: true,
      createdAt: new Date().toISOString(),
    };
    setOwnerUserState(newOwner);
    try {
      await setDoc(doc(db, 'users', ownerId), newOwner);
    } catch (err) {
      console.warn('Firestore register owner warning:', err);
    }
    return newOwner;
  };

  const loginOwner = async (phone: string): Promise<UserProfile | null> => {
    const cleanPhone = phone.replace(/[\s-]/g, '');
    const foundStore = stores.find(
      (s) =>
        s.ownerPhone.replace(/[\s-]/g, '').includes(cleanPhone) ||
        cleanPhone.includes(s.ownerPhone.replace(/[\s-]/g, ''))
    );

    if (foundStore) {
      const existingOwner: UserProfile = {
        id: foundStore.ownerId,
        name: foundStore.ownerName,
        phone: foundStore.ownerPhone,
        email: foundStore.ownerEmail || '',
        role: 'store_owner',
        storeId: foundStore.id,
        isVerified: true,
        createdAt: foundStore.createdAt,
      };
      setOwnerUserState(existingOwner);
      return existingOwner;
    }

    const newOwner: UserProfile = {
      id: `owner-${Date.now()}`,
      name: 'Store Partner',
      phone,
      role: 'store_owner',
      isVerified: true,
      createdAt: new Date().toISOString(),
    };
    setOwnerUserState(newOwner);
    return newOwner;
  };

  const logoutOwner = () => {
    setOwnerUserState(null);
  };

  // Create Supermarket Application (Owner submits -> status: pending_approval)
  const createStoreApplication = async (data: {
    name: string;
    ownerName: string;
    ownerPhone: string;
    ownerEmail?: string;
    address: string;
    apartmentId: string;
    logoUrl?: string;
    description?: string;
    openingTime: string;
    closingTime: string;
  }): Promise<Store> => {
    const storeId = `store-${Date.now()}`;
    const targetApt = apartments.find((a) => a.id === data.apartmentId);
    const ownerId = ownerUser?.id || `owner-${Date.now()}`;

    const newStore: Store = {
      id: storeId,
      name: data.name,
      ownerId,
      ownerName: data.ownerName,
      ownerPhone: data.ownerPhone,
      ownerEmail: data.ownerEmail,
      apartmentId: data.apartmentId,
      apartmentName: targetApt?.name || 'Selected Apartment',
      address: data.address,
      description: data.description || 'Dedicated grocery supermarket',
      logoUrl:
        data.logoUrl ||
        'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=500&q=80',
      status: 'pending_approval',
      monthlyFee: 199,
      subscriptionStatus: 'pending',
      subscriptionExpiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      openingTime: data.openingTime,
      closingTime: data.closingTime,
      deliveryTimeMinutes: 12,
      minOrderAmount: 99,
      rating: 5.0,
      totalOrders: 0,
      deliveryBoys: [
        {
          id: `db-${Date.now()}-1`,
          name: `${data.name} Rider 1`,
          phone: data.ownerPhone,
          active: true,
          totalDeliveries: 0,
        },
      ],
      createdAt: new Date().toISOString(),
      appliedAt: new Date().toISOString(),
    };

    setStores((prev) => [newStore, ...prev]);

    if (ownerUser) {
      setOwnerUserState((prev) => (prev ? { ...prev, storeId } : null));
    }

    addNotification({
      recipientId: 'admin-super-express',
      title: 'New Supermarket Application 🏬',
      message: `${data.name} submitted an application for ${targetApt?.name}. Review in Admin Dashboard.`,
      type: 'alert',
      relatedId: storeId,
    });

    try {
      await setDoc(doc(db, 'stores', storeId), {
        id: storeId,
        name: newStore.name,
        ownerId: newStore.ownerId,
        ownerName: newStore.ownerName,
        ownerPhone: newStore.ownerPhone,
        ownerEmail: newStore.ownerEmail || '',
        address: newStore.address,
        logoUrl: newStore.logoUrl,
        description: newStore.description,
        apartmentId: newStore.apartmentId,
        apartmentName: newStore.apartmentName,
        status: newStore.status,
        monthlyFee: newStore.monthlyFee,
        subscriptionStatus: newStore.subscriptionStatus,
        subscriptionExpiresAt: newStore.subscriptionExpiresAt,
        openingTime: newStore.openingTime,
        closingTime: newStore.closingTime,
        deliveryTimeMinutes: newStore.deliveryTimeMinutes,
        minOrderAmount: newStore.minOrderAmount,
        createdAt: newStore.createdAt,
      });
    } catch (err) {
      console.warn('Firestore store app warning:', err);
    }

    return newStore;
  };

  // Admin Approval: Strictly enforce single supermarket per apartment
  const approveStoreApplication = async (
    storeId: string
  ): Promise<{ success: boolean; message?: string }> => {
    const targetStore = stores.find((s) => s.id === storeId);
    if (!targetStore) return { success: false, message: 'Store application not found' };

    // Prevent multiple active stores from being assigned to the same apartment!
    const existingActiveStore = stores.find(
      (s) => s.apartmentId === targetStore.apartmentId && s.status === 'active' && s.id !== storeId
    );

    if (existingActiveStore) {
      return {
        success: false,
        message: `Apartment already has an active supermarket: "${existingActiveStore.name}". Under single-store rules, each apartment can only have one active supermarket. Please suspend or reassign the existing store before approving.`,
      };
    }

    const nextMonth = new Date();
    nextMonth.setDate(nextMonth.getDate() + 30);

    const updatedStores = stores.map((s) =>
      s.id === storeId
        ? {
            ...s,
            status: 'active' as const,
            subscriptionStatus: 'active' as const,
            subscriptionExpiresAt: nextMonth.toISOString(),
          }
        : s
    );

    const updatedApts = apartments.map((a) =>
      a.id === targetStore.apartmentId
        ? { ...a, activeStoreId: storeId, activeStoreName: targetStore.name }
        : a
    );

    setStores(updatedStores);
    setApartments(updatedApts);

    addNotification({
      recipientId: targetStore.ownerId,
      title: 'Supermarket Approved! 🎉',
      message: `Your supermarket "${targetStore.name}" is now the active exclusive grocery store for ${targetStore.apartmentName}.`,
      type: 'alert',
      relatedId: storeId,
    });

    try {
      await updateDoc(doc(db, 'stores', storeId), {
        status: 'active',
        subscriptionStatus: 'active',
        subscriptionExpiresAt: nextMonth.toISOString(),
      });
      await updateDoc(doc(db, 'apartments', targetStore.apartmentId), {
        activeStoreId: storeId,
        activeStoreName: targetStore.name,
      });
    } catch (err) {
      console.warn('Firestore approval sync warning:', err);
    }

    return { success: true };
  };

  const rejectStoreApplication = async (storeId: string, reason: string) => {
    const targetStore = stores.find((s) => s.id === storeId);
    if (!targetStore) return;

    setStores((prev) =>
      prev.map((s) =>
        s.id === storeId
          ? { ...s, status: 'rejected' as const, rejectionReason: reason }
          : s
      )
    );

    addNotification({
      recipientId: targetStore.ownerId,
      title: 'Supermarket Application Rejected ❌',
      message: `Application for "${targetStore.name}" was not approved: ${reason}`,
      type: 'alert',
      relatedId: storeId,
    });
  };

  const addDeliveryBoy = async (storeId: string, name: string, phone: string) => {
    const newBoy = {
      id: `boy-${Date.now()}`,
      name,
      phone,
      active: true,
      totalDeliveries: 0,
    };
    setStores((prev) =>
      prev.map((s) =>
        s.id === storeId ? { ...s, deliveryBoys: [...(s.deliveryBoys || []), newBoy] } : s
      )
    );
  };

  const toggleDeliveryBoy = async (storeId: string, boyId: string) => {
    setStores((prev) =>
      prev.map((s) =>
        s.id === storeId
          ? {
              ...s,
              deliveryBoys: (s.deliveryBoys || []).map((b) =>
                b.id === boyId ? { ...b, active: !b.active } : b
              ),
            }
          : s
      )
    );
  };

  const toggleStoreAvailability = async (storeId: string) => {
    setStores((prev) =>
      prev.map((s) => {
        if (s.id !== storeId) return s;
        const newStatus = s.status === 'active' ? 'inactive' : 'active';
        return { ...s, status: newStatus };
      })
    );
  };

  // Customer Firebase Auth Actions
  const clearCustomerAuthError = () => setCustomerAuthError(null);

  const loginCustomerWithEmail = async (email: string, password: string) => {
    setCustomerAuthError(null);
    const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
    const snap = await getDoc(doc(db, 'users', cred.user.uid));
    if (snap.exists() && snap.data()?.role && snap.data().role !== 'customer') {
      const foundRole = snap.data().role;
      await signOut(auth);
      throw new Error(
        `This account is registered as "${foundRole}". Only Customer accounts can log into Super Express Customer App.`
      );
    }
  };

  const registerCustomerWithEmail = async (data: {
    name: string;
    email: string;
    password: string;
    phone: string;
    apartmentId: string;
    block: string;
    flatNumber: string;
  }) => {
    setCustomerAuthError(null);
    const cred = await createUserWithEmailAndPassword(auth, data.email.trim(), data.password);
    await updateProfile(cred.user, { displayName: data.name.trim() });

    const now = new Date().toISOString();
    const apt = apartments.find((a) => a.id === data.apartmentId) || apartments[0];
    const firestoreUserDoc = {
      id: cred.user.uid,
      phone: data.phone.trim().slice(0, 20),
      name: data.name.trim().slice(0, 100),
      email: data.email.trim().slice(0, 120),
      role: 'customer' as const,
      apartmentId: apt?.id || data.apartmentId,
      flatNumber: data.flatNumber.trim().slice(0, 50),
      block: data.block.trim().slice(0, 50),
      isVerified: true,
      createdAt: now,
      updatedAt: now,
    };

    await setDoc(doc(db, 'users', cred.user.uid), firestoreUserDoc);
    setCurrentUser({
      ...firestoreUserDoc,
      apartmentName: apt?.name || '',
    });
  };

  const loginCustomerWithGoogle = async () => {
    setCustomerAuthError(null);
    const user = await signInWithGoogleForFirebase();
    const snap = await getDoc(doc(db, 'users', user.uid));
    if (snap.exists() && snap.data()?.role && snap.data().role !== 'customer') {
      const foundRole = snap.data().role;
      await signOut(auth);
      throw new Error(
        `This account is registered as "${foundRole}". Only Customer accounts can log into Super Express Customer App.`
      );
    }
  };

  const logoutCustomer = async () => {
    await signOut(auth);
    setCustomerFirebaseUser(null);
    setCart([]);
  };

  const updateCustomerProfile = async (updates: {
    name?: string;
    phone?: string;
    apartmentId?: string;
    block?: string;
    flatNumber?: string;
  }) => {
    const nextApt = updates.apartmentId
      ? apartments.find((a) => a.id === updates.apartmentId)
      : activeApartment;

    setCurrentUser((prev) => ({
      ...prev,
      ...(updates.name !== undefined ? { name: updates.name } : {}),
      ...(updates.phone !== undefined ? { phone: updates.phone } : {}),
      ...(updates.apartmentId !== undefined ? { apartmentId: updates.apartmentId } : {}),
      ...(nextApt ? { apartmentName: nextApt.name } : {}),
      ...(updates.block !== undefined ? { block: updates.block } : {}),
      ...(updates.flatNumber !== undefined ? { flatNumber: updates.flatNumber } : {}),
    }));

    if (auth.currentUser) {
      const now = new Date().toISOString();
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const cleanPatch: Record<string, unknown> = { updatedAt: now };
      if (updates.name !== undefined) cleanPatch.name = updates.name.trim().slice(0, 100);
      if (updates.phone !== undefined) cleanPatch.phone = updates.phone.trim().slice(0, 20);
      if (updates.apartmentId !== undefined) cleanPatch.apartmentId = updates.apartmentId;
      if (updates.block !== undefined) cleanPatch.block = updates.block.trim().slice(0, 50);
      if (updates.flatNumber !== undefined)
        cleanPatch.flatNumber = updates.flatNumber.trim().slice(0, 50);
      try {
        await updateDoc(userRef, cleanPatch);
      } catch (err) {
        console.warn('Firestore customer profile update warning:', err);
      }
    }
  };

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        currentUser,
        setCurrentUser,
        apartments,
        stores,
        categories,
        products,
        orders,
        subscriptions,
        deliveryPartners,
        notifications,
        payments,
        cart,
        cartTotal,
        cartCount,
        activeApartment,
        activeStore,
        ownerUser,
        ownerStore,
        registerOwner,
        loginOwner,
        logoutOwner,
        createStoreApplication,
        approveStoreApplication,
        rejectStoreApplication,
        addDeliveryBoy,
        toggleDeliveryBoy,
        toggleStoreAvailability,
        selectApartment,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        createOrder,
        verifyOnlinePayment,
        updateOrderStatus,
        assignDeliveryPartner,
        verifyDeliveryOtp,
        addProduct,
        updateProduct,
        deleteProduct,
        toggleProductStock,
        findProductByBarcode,
        checkBarcodeDuplicate,
        completePosSale,
        paySubscription,
        addApartment,
        assignStoreToApartment,
        updateStoreStatus,
        markNotificationAsRead,
        addNotification,
        appMode,
        customerAuthLoading,
        customerFirebaseUser,
        customerAuthError,
        clearCustomerAuthError,
        loginCustomerWithEmail,
        registerCustomerWithEmail,
        loginCustomerWithGoogle,
        logoutCustomer,
        updateCustomerProfile,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used within AppProvider');
  }
  return ctx;
};
