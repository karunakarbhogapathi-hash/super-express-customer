import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const OPEN_FOOD_FACTS_ENDPOINT = 'https://world.openfoodfacts.org/api/v2/product';
const OPEN_FOOD_FACTS_FIELDS = 'product_name,brands,categories,image_front_url,quantity';
const OPEN_FOOD_FACTS_USER_AGENT = 'SuperExpress/1.0 (karunakar.bhogapathi@gmail.com)';
const CACHE_TTL_MS = 15 * 60 * 1000;
const MAX_CACHE_ENTRIES = 500;

interface CachedLookup {
  expiresAt: number;
  payload: Record<string, unknown>;
}

const offCache = new Map<string, CachedLookup>();
const offInFlight = new Map<string, Promise<{ httpCode: number; body: Record<string, unknown> }>>();

function normalizeBarcode(raw: string): string {
  return raw.replace(/[\u0000-\u001F\u007F\s-]+/g, '').trim();
}

function setCachedLookup(barcode: string, payload: Record<string, unknown>): void {
  if (offCache.size >= MAX_CACHE_ENTRIES) {
    const oldestKey = offCache.keys().next().value;
    if (oldestKey) {
      offCache.delete(oldestKey);
    }
  }
  offCache.set(barcode, {
    expiresAt: Date.now() + CACHE_TTL_MS,
    payload,
  });
}

async function fetchOpenFoodFactsServer(
  barcode: string
): Promise<{ httpCode: number; body: Record<string, unknown> }> {
  const cached = offCache.get(barcode);
  if (cached && cached.expiresAt > Date.now()) {
    return {
      httpCode: 200,
      body: { ...cached.payload, fromServerCache: true },
    };
  }

  const existing = offInFlight.get(barcode);
  if (existing) {
    return existing;
  }

  const promise = (async (): Promise<{ httpCode: number; body: Record<string, unknown> }> => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12000);
    const url = `${OPEN_FOOD_FACTS_ENDPOINT}/${encodeURIComponent(
      barcode
    )}.json?fields=${OPEN_FOOD_FACTS_FIELDS}`;

    let response: Response;
    try {
      response = await fetch(url, {
        method: 'GET',
        headers: {
          'User-Agent': OPEN_FOOD_FACTS_USER_AGENT,
          Accept: 'application/json',
        },
        signal: controller.signal,
      });
    } catch (err: unknown) {
      clearTimeout(timeoutId);
      const isAbort = err instanceof Error && err.name === 'AbortError';
      if (isAbort) {
        return {
          httpCode: 504,
          body: {
            error: 'timeout',
            message: 'Open Food Facts lookup timed out. Please enter details manually.',
          },
        };
      }
      return {
        httpCode: 502,
        body: {
          error: 'network_error',
          message:
            'Connection error while contacting Open Food Facts. Please check internet connection or enter details manually.',
        },
      };
    } finally {
      clearTimeout(timeoutId);
    }

    let rawText = '';
    try {
      rawText = await response.text();
    } catch {
      return {
        httpCode: 502,
        body: {
          error: 'network_error',
          upstreamHttpStatus: response.status,
          message: 'Failed to read response from Open Food Facts. Please enter details manually.',
        },
      };
    }

    let parsed: Record<string, unknown> | null = null;
    if (rawText.trim()) {
      try {
        parsed = JSON.parse(rawText) as Record<string, unknown>;
      } catch {
        parsed = null;
      }
    }

    if (response.status === 404 || (parsed && parsed.status === 0)) {
      const notFoundBody: Record<string, unknown> = {
        code: barcode,
        status: 0,
        status_verbose:
          (parsed && typeof parsed.status_verbose === 'string' && parsed.status_verbose) ||
          'product not found',
        upstreamHttpStatus: response.status,
        product: null,
      };
      setCachedLookup(barcode, notFoundBody);
      return { httpCode: 200, body: notFoundBody };
    }

    if (!response.ok) {
      return {
        httpCode: 502,
        body: {
          error: 'http_error',
          upstreamHttpStatus: response.status,
          message: `Open Food Facts returned HTTP ${response.status}. Please enter details manually.`,
        },
      };
    }

    if (!parsed) {
      return {
        httpCode: 502,
        body: {
          error: 'invalid_json',
          upstreamHttpStatus: response.status,
          message: 'Invalid JSON response from Open Food Facts. Please enter details manually.',
        },
      };
    }

    const okBody: Record<string, unknown> = {
      ...parsed,
      upstreamHttpStatus: response.status,
    };
    setCachedLookup(barcode, okBody);
    return { httpCode: 200, body: okBody };
  })();

  offInFlight.set(barcode, promise);
  try {
    return await promise;
  } finally {
    offInFlight.delete(barcode);
  }
}

async function startServer() {
  const app = express();

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok' });
  });

  app.get('/api/openfoodfacts/:barcode', async (req, res) => {
    const normalized = normalizeBarcode(req.params.barcode || '');
    if (!/^\d{6,14}$/.test(normalized)) {
      res.status(400).json({
        error: 'invalid_barcode',
        status: 0,
        message: 'Invalid barcode format. Enter a 6–14 digit barcode or fill details manually.',
      });
      return;
    }

    const result = await fetchOpenFoodFactsServer(normalized);
    res.status(result.httpCode).json(result.body);
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distDir)) {
      app.use(express.static(distDir));
      app.get('*', (req, res, next) => {
        if (req.path.startsWith('/api/')) {
          next();
          return;
        }
        res.sendFile(path.join(distDir, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Super Express server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start Super Express server:', err);
  process.exit(1);
});
