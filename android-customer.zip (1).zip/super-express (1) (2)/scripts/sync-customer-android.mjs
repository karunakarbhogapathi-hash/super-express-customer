import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const rootDir = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const customerCapConfig = path.join(rootDir, 'capacitor.customer.config.json');
const activeCapConfig = path.join(rootDir, 'capacitor.config.json');
const distCustomer = path.join(rootDir, 'dist-customer');

if (!fs.existsSync(customerCapConfig)) {
  console.error('Missing capacitor.customer.config.json');
  process.exit(1);
}

if (!fs.existsSync(path.join(distCustomer, 'index.html'))) {
  console.log('dist-customer/index.html not found, running build:customer first...');
  execSync('npm run build:customer', { cwd: rootDir, stdio: 'inherit' });
}

try {
  fs.copyFileSync(customerCapConfig, activeCapConfig);
  execSync('npx cap sync android', { cwd: rootDir, stdio: 'inherit' });
} finally {
  if (fs.existsSync(activeCapConfig)) {
    fs.unlinkSync(activeCapConfig);
  }
}
